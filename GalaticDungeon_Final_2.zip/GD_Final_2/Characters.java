import javafx.scene.text.Text;

	 
public class Characters {
	private int x;
	private int y;
	private int health;
	private Text hptext;
	  
	  //setters and getters
	public void setX(int t){
		x = t;
	}
	public int getX(){
		return x;
	}
	public void setY(int t){
		y = t;
	}
	public int getY(){
	    return y;
	}
	public void setHealth(int t){
		  health=t;
	}
	public int getHealth(){
	    return health;
	 }
	public Text getHptext() {
		return hptext;
	}
	public void setHptext(Text hptext) {
		this.hptext = hptext;
	}

}
