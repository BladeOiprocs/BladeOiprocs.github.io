from pathlib import Path

## Import from project library
from salac.labels import Annotation
from salac.ldc_atc0 import creat_mapping_table

########################################################################
# Conversions from LDC ATC0 transcripts

def ldcatc2stm_(src_file: str, dst_file: str) -> bool:
    """Convert a LDC ATC0 file to STM."""
    try:
        raw_text = Annotation.read_file_to_text(filename=src_file)
        compiled_mapping = creat_mapping_table()
        all_text = Annotation.from_ldc_atc0_text(
            file_text=raw_text,
            filename=src_file[:-4],  # Drop the extension
            need_proc=True,
            compiled_mapping=compiled_mapping)
        stm_text = all_text.to_stm_text()
        all_text.write_text_to_file(filename=dst_file,
                                    file_text=stm_text)
        return True
    except Exception as e:
        print("Not able to run toml2stm.")
        return False


def ldcatc2stm_dir_(src_folder: str, dst_folder: str) -> bool:
    """Convert multiple LDC ATC0 files to STM."""
    try:
        compiled_mapping = creat_mapping_table()
        src_dir = Path(src_folder)
        dst_dir = Path(dst_folder)
        dst_dir.mkdir(exist_ok=True)
        src_files = src_dir.glob("*/**/transcripts/*.txt")
        for src_file in src_files:
            print(f'{src_file = }-----------------------------------------')
            dst_file = dst_dir / src_file.with_suffix('.stm').name
            print(f'{dst_file = }=========================================')
            src_name = str(src_file)
            raw_text = Annotation.read_file_to_text(filename=src_name)
            basefilename = Path(src_file).stem
            all_text = Annotation.from_ldc_atc0_text(
                file_text=raw_text,
                filename=basefilename,
                need_proc=True,
                compiled_mapping=compiled_mapping
            )
            stm_text = all_text.to_stm_text()
            all_text.write_text_to_file(filename=str(dst_file),
                                        file_text=stm_text)
        return True
    except Exception as e:
        print("Not able to finish ldcatc2stm_dir_.")
        return False


def ldcatc2vtt_(src_file: str, dst_file: str) -> bool:
    """Convert a LDC ATC0 file to VTT."""
    try:
        raw_text = Annotation.read_file_to_text(filename=src_file)
        compiled_mapping = creat_mapping_table()
        all_text = Annotation.from_ldc_atc0_text(
            file_text=raw_text,
            need_proc=True,
            compiled_mapping=compiled_mapping)
        vtt_text = all_text.to_vtt_text()
        all_text.write_text_to_file(filename=dst_file,
                                    file_text=vtt_text)
        return True
    except Exception as e:
        print("Not able to run toml2vtt.")
        return False


def ldcatc2vtt_dir_(src_folder: str, dst_folder: str) -> bool:
    """Convert multiple LDC ATC0 files to VTT."""
    try:
        compiled_mapping = creat_mapping_table()
        src_dir = Path(src_folder)
        dst_dir = Path(dst_folder)
        dst_dir.mkdir(exist_ok=True)
        src_files = src_dir.glob("*/**/transcripts/*.txt")
        for src_file in src_files:
            print(f'{src_file = }-----------------------------------------')
            dst_file = dst_dir / src_file.with_suffix('.vtt').name
            print(f'{dst_file = }=========================================')
            raw_text = Annotation.read_file_to_text(filename=str(src_file))
            all_text = Annotation.from_ldc_atc0_text(
                file_text=raw_text,
                need_proc=True,
                compiled_mapping=compiled_mapping)
            vtt_text = all_text.to_vtt_text()
            all_text.write_text_to_file(filename=str(dst_file),
                                        file_text=vtt_text)
        return True
    except Exception as e:
        print("Not able to finish ldcatc2vtt_dir_.")
        return False


########################################################################
# Conversions from MLL, the multi-layer labels

def mll2json_(src_file: str, dst_file: str, ref_file: str = None) -> bool:
    """Convert a MLL file to JSON."""
    try:
        raw_text = Annotation.read_file_to_text(filename=src_file)
        if ref_file is None:
            all_text = Annotation.from_mll_text(file_text=raw_text)
        else:
            mll_format = Annotation._mll_format(ref_file)
            all_text = Annotation.from_mll_text(file_text=raw_text,
                                                mll_format=mll_format)
        json_text = all_text.to_json_text()
        all_text.write_text_to_file(filename=dst_file,
                                    file_text=json_text)
        return True
    except Exception as e:
        print("Not able to run mll2json.")
        print(e)
        return False


def mll2textgrid_(src_file: str, dst_file: str, ref_file: str = None) -> bool:
    """Convert a MLL file to TextGrid."""
    try:
        raw_text = Annotation.read_file_to_text(filename=src_file)
        if ref_file is None:
            all_text = Annotation.from_mll_text(file_text=raw_text)
        else:
            mll_format = Annotation._mll_format(ref_file)
            all_text = Annotation.from_mll_text(file_text=raw_text,
                                                mll_format=mll_format)
        all_text.add_silence()
        textgrid_text = all_text.to_textgrid_text()
        all_text.write_text_to_file(filename=dst_file,
                                    file_text=textgrid_text)
        return True
    except Exception as e:
        print("Not able to run mll2textgrid.")
        print(e)
        return False


def mll2vtt_(src_file: str, dst_file: str, ref_file: str = None) -> bool:
    """Convert a MLL file to VTT."""
    try:
        raw_text = Annotation.read_file_to_text(filename=src_file)
        if ref_file is None:
            all_text = Annotation.from_mll_text(file_text=raw_text)
        else:
            mll_format = Annotation._mll_format(ref_file)
            all_text = Annotation.from_mll_text(file_text=raw_text,
                                                mll_format=mll_format)
        all_text.remove_silence()
        vtt_text = all_text.to_vtt_text()
        all_text.write_text_to_file(filename=dst_file,
                                    file_text=vtt_text)
        return True
    except Exception as e:
        print("Not able to run mll2vtt.")
        print(e)
        return False


########################################################################
# Conversions from TextGrid files

def textgrid2json_(src_file: str, dst_file: str) -> bool:
    """Convert a TextGrid file to JSON."""
    try:
        raw_text = Annotation.read_file_to_text(filename=src_file)
        all_text = Annotation.from_textgrid_text(file_text=raw_text)
        json_text = all_text.to_json_text()
        all_text.write_text_to_file(filename=dst_file,
                                    file_text=json_text)
        return True
    except Exception as e:
        print("Not able to run textgrid2json.")
        print(e)
        return False


def textgrid2mll_(src_file: str, dst_file: str, ref_file: str = None) -> bool:
    """Convert a TextGrid file to MLL."""
    try:
        raw_text = Annotation.read_file_to_text(filename=src_file)
        all_text = Annotation.from_textgrid_text(file_text=raw_text)
        if ref_file is None:
            mll_text = all_text.to_mll_text()
        else:
            mll_format = all_text._mll_format(ref_file)
            mll_text = all_text.to_mll_text(mll_format)
        all_text.write_text_to_file(filename=dst_file,
                                    file_text=mll_text)
        return True
    except Exception as e:
        print("Not able to run textgrid2mll.")
        print(e)
        return False


def textgrid2vtt_(src_file: str, dst_file: str) -> bool:
    """Convert a TextGrid file to VTT."""
    try:
        raw_text = Annotation.read_file_to_text(filename=src_file)
        all_text = Annotation.from_textgrid_text(file_text=raw_text)
        all_text.remove_silence()
        vtt_text = all_text.to_vtt_text()
        all_text.write_text_to_file(filename=dst_file,
                                    file_text=vtt_text)
        return True
    except Exception as e:
        print("Not able to run textgrid2vtt.")
        print(e)
        return False


def textgrid2txt_dir_(src_folder: str, dst_folder: str) -> bool:
    """Convert multiple TextGrid files to transcript text files."""
    try:
        src_dir = Path(src_folder)
        dst_dir = Path(dst_folder)
        dst_dir.mkdir(exist_ok=True)
        src_files = src_dir.glob("*/*.*")
        print(f'{src_files = }')
        for src_file in src_files:
            print(f'{src_file = }-----------------------------------------')
            dst_file = dst_dir / src_file.with_suffix('.txt').name
            print(f'{dst_file = }=========================================')
            src_name = str(src_file)
            raw_text = Annotation.read_file_to_text(filename=src_name)
            all_text = Annotation.from_textgrid_text(file_text=raw_text)
            all_text.remove_silence()
            transcript_text = all_text.to_transcript_text()
            all_text.write_text_to_file(filename=str(dst_file),
                                        file_text=transcript_text)
        return True
    except Exception as e:
        print("Not able to finish textgrid2txt_dir_.")
        return False


########################################################################
# Conversions from VTT

def vtt2mll_(src_file: str, dst_file: str, ref_file: str = None) -> bool:
    """Convert a VTT file to MLL."""
    try:
        raw_text = Annotation.read_file_to_text(filename=src_file)
        all_text = Annotation.from_vtt_srt_text(file_text=raw_text)
        if ref_file is None:
            mll_text = all_text.to_mll_text()
        else:
            mll_format = all_text._mll_format(ref_file)
            mll_text = all_text.to_mll_text(mll_format)
        all_text.write_text_to_file(filename=dst_file,
                                    file_text=mll_text)
        return True
    except Exception as e:
        # Will add code as needed later
        return False


def vtt2textgrid_(src_file: str, dst_file: str) -> bool:
    """Convert a VTT file to TextGrid."""
    try:
        raw_text = Annotation.read_file_to_text(filename=src_file)
        all_text = Annotation.from_vtt_srt_text(file_text=raw_text)
        all_text.add_silence()
        textgrid_text = all_text.to_textgrid_text()
        all_text.write_text_to_file(filename=dst_file,
                                    file_text=textgrid_text)
        return True
    except Exception as e:
        # Will add code as needed later
        return False


def vtt2textgrid_dir_(src_folder: str, dst_folder: str) -> bool:
    """Convert multiple VTT files to TextGrid."""
    try:
        src_dir = Path(src_folder)
        dst_dir = Path(dst_folder)
        dst_dir.mkdir(exist_ok=True)
        src_files = src_dir.glob("*.vtt")
        for src_file in src_files:
            print(f'{src_file = }-----------------------------------------')
            dst_file = dst_dir / src_file.with_suffix('.textgrid').name
            print(f'{dst_file = }=========================================')
            raw_text = Annotation.read_file_to_text(filename=str(src_file))
            all_text = Annotation.from_vtt_srt_text( file_text=raw_text)
            all_text.add_silence(average_overlap=True)
            textgrid_text = all_text.to_textgrid_text()
            all_text.write_text_to_file(filename=str(dst_file),
                                        file_text=textgrid_text)
        return True
    except Exception as e:
        print("Not able to finish vtt2textgrid_dir_.")
        return False


########################################################################
# Other recipes

def merge2vtts_(src_file1: str, src_file2: str, time_offset: int,
                dst_file: str) -> bool:
    """Merge two VTT files into a single one with a given time_offset."""
    try:
        raw_text = Annotation.read_file_to_text(filename=src_file1)
        text1 = Annotation.from_vtt_srt_text(file_text=raw_text)
        raw_text = Annotation.read_file_to_text(filename=src_file2)
        text2 = Annotation.from_vtt_srt_text(file_text=raw_text)
        text1.add_text_timeline(text2, time_offset)
        vtt_text = text1.to_vtt_text()
        text1.write_text_to_file(filename=dst_file,
                                 file_text=vtt_text)
        return True
    except Exception as e:
        # Will add code as needed later
        return False
