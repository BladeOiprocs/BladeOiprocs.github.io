import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import javafx.scene.image.Image;

public class levelOne {
	
	Image lvlOneArray[][] = new Image[22][22];
	private char matrix[][] = new char[22][22];
	
	
	public levelOne() {
		generateLevel();
		levelLoader();
	}

	public Image[][] getArray() {
		return lvlOneArray;
	}
	
	public char[][] getMatrix(){
		return matrix;
	}
	
	public void setMatrix(char[][] inputMatrix){
		matrix = inputMatrix;
	}

	public void lvlOne() {

		try {
			Scanner s = new Scanner(new File("LevelOne.txt"));

			int row  = 0;

			while(row < 20) {
				String line = s.nextLine();
				char[] columnsOfLine = line.toCharArray();
				for (int i = 0; i < columnsOfLine.length; i++) {
					char newChar = columnsOfLine[i]; 
					matrix[row][i] = newChar;
				}
				row++;
			}
			s.close();

		} catch (IOException i) {
			System.out.println("Problems loading file");

		}
	}

	public void levelLoader() {
		//Set images to array
		for(int i = 0; i < 22; i++) {
			for(int j = 0; j < 22; j++) {
				if (matrix[i][j] == 'W') {
					lvlOneArray[i][j] = new Image("file:Wall.png");
				}else if (matrix[i][j] == 'P') {
					lvlOneArray[i][j] = new Image("file:RedPlanet.png");
				}else 
					lvlOneArray[i][j] = new Image("file:Wall.png");
				}
			}
		}

	public void generateLevel() {
		for(int i = 0; i < 22; i++) {
			for(int j = 0; j < 22; j++) {
				int z = randomFrom(0,3);
				if(z == 1) {
					matrix[i][j] = 'W';
				}else {
					matrix[i][j] = 'P';
				}
        		if((i == 0) || (j == 0)) {
        			matrix[i][j] = 'U';
        		}
        		if((i == 3) && (j == 3)) {
        			matrix[i][j] = 'P';
        		}
        		if((i == 21) || (j == 21)) {
        			matrix[i][j] = 'U';
        		}
			}
		}
	}
	
	public int randomFrom (int low, int high) {

		int randNum = 0;

		// (int) is casting since Math.random() return a double and randNum is an int
		randNum = (int) (Math.random()*(high-low) + low);

		return randNum;
	}
	
	}
	
	

