
public class powerUp {

	private int powerX;
	private int powerY;
	private boolean flag;
	
	powerUp(){
		setPowerX((int)(Math.random()*(20-2+1)+2));
		setPowerY((int)(Math.random()*(20-2+1)+2));
		flag = true;
	}
	



	public int getPowerX() {
		return powerX;
	}


	public void setPowerX(int powerX) {
		this.powerX = powerX;
	}


	public int getPowerY() {
		return powerY;
	}


	public void setPowerY(int powerY) {
		this.powerY = powerY;
	}




	public boolean getFlag() {
		return flag;
	}




	public void setFlag(boolean flag) {
		this.flag = flag;
	}	
}