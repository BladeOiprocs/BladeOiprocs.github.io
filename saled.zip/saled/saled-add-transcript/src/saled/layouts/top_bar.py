""" Top Bar Layout
  File for the top bar component objects. This includes the title, file select,
  action buttons, and placeholder global timestamps.
"""

import glob

from dash import html, dcc
import dash_mantine_components as dmc
from dash_iconify import DashIconify

DIR_CONTENTS = None
layout = None

transcript_section = dmc.MenuDropdown([
    dcc.Upload(
        dmc.Button('Upload Transcript'),
        id="upload-transcript"
    ),
    dmc.MenuItem('Save Transcript',
                 id="save-transcript"),
    dmc.Menu(
        [
            dmc.MenuTarget(dmc.MenuItem("Export Transcript")),
            dmc.MenuDropdown(
                [
                    dmc.MenuItem("Export MLL",
                                 id="export-mll",
                                 n_clicks=0),
                    dmc.MenuItem("Export VTT",
                                 id="export-vtt",
                                 n_clicks=0),
                    dmc.MenuItem("Export TextGrid",
                                 id="export-textgrid",
                                 n_clicks=0),
                    dmc.MenuItem("Export JSON",
                                 id="export-json",
                                 n_clicks=0),
                ],
            ),
        ],
        trigger="hover",
    ),
])


def set_contents(current_directory):
    global DIR_CONTENTS
    global layout

    # Checks path for all currently-supported audio formats.
    # DIR_CONTENTS = glob.glob(DATA_PATH_NAME + "/*.mp3") + glob.glob(
    #     DATA_PATH_NAME + "/*.wav"
    # )

    DIR_CONTENTS = glob.glob(str(current_directory) + "*/*.mp3")
    # print(f'{DIR_CONTENTS = }')

    if not DIR_CONTENTS:
        raise ValueError("No audio files.")

    layout = html.Div(
        [
            dmc.Group(
                [
                    dmc.Title("SaLED", order=2, m="md"),
                    dmc.Select(
                        placeholder="Select File",
                        id="file-selector",
                        data=[
                            {"label": file, "value": file}
                            for file in sorted(DIR_CONTENTS, reverse=True)
                        ],
                        value=(
                            DIR_CONTENTS[0]
                            if DIR_CONTENTS
                            else "Warning: Empty Directory"
                        ),
                        m="md",
                        w="25%",
                    ),
                    dmc.Menu(
                        [
                            dmc.MenuTarget(dmc.Button("Transcript")),
                            transcript_section,
                        ],
                    ),
                    dmc.Group(
                        [
                            dmc.Text(
                                "00:00:00.000",
                                id="global-time",
                                size="lg",
                                p="md",
                            ),
                        ],
                        gap=0,
                    ),
                ],
                id="title-bar",
            ),
            dcc.Graph(
                id="global-waveform",
                style={"height": "10vh"},
                config={"displaylogo": False,
                        "modeBarButtonsToAdd": ["select2d"]},
            ),
        ]
    )
