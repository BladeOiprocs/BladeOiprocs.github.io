
public class projectile {
	
	private int xVelo;
	private int yVelo;
	private int xPos;
	private int yPos;
	private boolean inMotion;
	
	
	public projectile(){
		setxVelo(0);
		setyVelo(0);
		setxPos(0);
		setyPos(0);
		setInMotion(false);
	}


	public int getxVelo() {
		return xVelo;
	}


	public void setxVelo(int xVelo) {
		this.xVelo = xVelo;
	}


	public int getyVelo() {
		return yVelo;
	}


	public void setyVelo(int yVelo) {
		this.yVelo = yVelo;
	}


	public int getxPos() {
		return xPos;
	}


	public void setxPos(int xPos) {
		this.xPos = xPos;
	}


	public int getyPos() {
		return yPos;
	}


	public void setyPos(int yPos) {
		this.yPos = yPos;
	}


	public boolean isInMotion() {
		return inMotion;
	}


	public void setInMotion(boolean inMotion) {
		this.inMotion = inMotion;
	}
}