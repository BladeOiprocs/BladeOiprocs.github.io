from dash import Output, Input, ctx, callback, State
from dash.exceptions import PreventUpdate
from dash import _dash_renderer
import dash_mantine_components as dmc

import plotly.express as px
import pandas as pd
from librosa.feature import melspectrogram
from librosa import power_to_db
import numpy as np

import base64

import saled.utils.audio as atool
import saled.utils.fileIO as fio

## Import from our SALAC project
from salac.labels import Annotation

_dash_renderer._set_react_version("18.2.0")


def get_callbacks(app):
    """
    This function contains all the server-side callbacks for the main app.
    """

    # alternating colors
    colors = ['#DE00FE', '#FDE93D', '#9FFE00']  # '#FE5F00''#FE0020'

    @callback(
        Output("sampled-audio", "data"),
        Output("audio-length", "data"),
        Input("file-selector", "value"),
    )
    def update_sampled_audio(audio_file):
        """
        This function updates the audio stored on the client side when a new
        file is selected.

        Parameters:
        FILE (str): The file path selected in the menu.

        Returns:
        ndarray: A Numpy array containing sampled points from the original
                        waveform.
        """
        if audio_file is None:
            raise PreventUpdate
        sample_audio, length = atool.envelope_sample(fio.load_audio(audio_file))
        return sample_audio, length

    @callback(
        Output("sampled-transcription", "data"),
        Input("save-transcript", "n_clicks"),
        Input("upload-transcript", "contents"),
        State("upload-transcript", "filename"),
        State("card-area", "children"),
        State("sampled-transcription", "data"),
    )
    def update_transcription(_,
                             transcript_contents,
                             filename,
                             transcript_ui,
                             transcript_save):
        """
        This function updates the transcript stored on the client side
        when a new file is selected.

        Parameters:
        FILE (str): The file path selected in the menu.

        Returns:
        str: the Annotation represented as json text
        """

        if ctx.triggered_id == "save-transcript":
            sample_transcription = update_transcript(transcript_ui,
                                                     transcript_save)
        else:
            if transcript_contents is None:
                raise PreventUpdate

            # decode base 64
            transcript_contents = transcript_contents.split(',', 1)[1]
            transcript_contents = base64.b64decode(transcript_contents)
            transcript_contents = transcript_contents.decode()

            sample_transcription = fio.load_transcription(filename,
                                                          transcript_contents)
        return sample_transcription.to_json_text()

    # helper function to split up things
    # dynamically finds fields
    def update_transcript(transcript_ui, transcript_save):
        transcript = Annotation.from_json_text(transcript_save)
        for component in transcript_ui:

            if component.get('type') == 'Paper':
                paper_cue = component['props']['children']

                for group_field in paper_cue:
                    text_input = group_field['props']['children'][1]['props']

                    cue_info = text_input['id'].split("-")[1:]
                    data = transcript.cues[int(cue_info.pop(0))].labels

                    while cue_info:
                        if cue_info[0].isdecimal():
                            cue_info[0] = int(cue_info[0])
                        if len(cue_info) == 1:
                            data[cue_info.pop(0)] = text_input['value']
                        else:
                            data = data[cue_info.pop(0)]

        return transcript

    @callback(
        Output("global-waveform", "figure"),
        Input("sampled-audio", "data")
    )
    def plot_global_waveform(sampled):
        """
        This function plots the waveform of the entire selected audio file.

        Parameters:
        sampled (ndarray): A Numpy array containing sampled waveform values.

        Returns:
        Figure: A Ploty Figure object of the resulting waveform plot.
        """

        # check for null
        if not sampled:
            raise PreventUpdate

        df = pd.DataFrame(sampled)
        graph = px.line(df, x=df.index, y=0, render_mode="webgl")
        graph.update_layout(
            showlegend=False,
            margin=dict(b=0, l=0, r=0, t=0),
            dragmode="select",
            selectdirection="h",
            activeselection={"opacity": 1},
            newselection=dict(
                line=dict(
                    color="Crimson",
                    width=3,
                    dash="solid",
                )
            ),
        )
        graph.update_xaxes(visible=False, fixedrange=True)
        graph.update_yaxes(visible=False, fixedrange=True)

        return graph

    @callback(
        Output("global-time", "children"),
        Input("audio-length", "data"),
    )
    def plot_global_time(length):
        """
        This function updated the time of the global waveform.

        Parameters:
        sampled (ndarray): A Numpy array containing sampled waveform values.

        Returns:
        Test: the time of the audio file.
        """

        length /= 100.0
        print(f"length = {length} seconds")

        time_ms = int(length % 1 * 1000)
        time_seconds = int(length % 60)
        time_minutes = int((length / 60) % 60)
        time_hours = int((length / 3600) % 60)

        length = (f"{time_hours:02d}:{time_minutes:02d}:"
                  + f"{time_seconds:02d}.{time_ms:03d}")

        return length

    @callback(
        Output("local-waveform", "figure"),
        Input("sampled-audio", "data"),
        Input("global-waveform", "selectedData"),
        State("sampled-transcription", "data"),
    )
    def plot_local_waveform(sampled, selection, transcription):
        """
        This function updates the local waveform.

        Parameters:
        sampled (ndarray): A Numpy array containing sampled waveform values.
        selection (dict): A dictionary containing Plotly selection information.

        Returns:
        Figure: A Plotly Figure object of the waveform plot.
        """

        if selection is not None and "range" in selection.keys():
            left_bound = int(selection["range"]["x"][0])
            right_bound = int(selection["range"]["x"][1])
        else:
            left_bound = 0
            right_bound = len(sampled)

        # check for negative to prevent errors
        if left_bound < 0:
            left_bound = 0

        # slice data so we only graph what we need
        sampled = sampled[left_bound:right_bound]

        df = pd.DataFrame(sampled)

        graph = px.line(df, x=0, y=(df.index + left_bound), render_mode="webgl")
        graph.update_xaxes(visible=False, fixedrange=True)
        graph.update_yaxes(
            autorange="reversed",
            visible=False,
            autorangeoptions=dict(clipmin=left_bound, clipmax=right_bound),
            fixedrange=True,
        )
        graph.update_layout(showlegend=False,
                            margin=dict(b=0, l=0, r=0, t=0),
                            hovermode="y unified",
        )

        # add lines
        if transcription:
            transcript = Annotation.from_json_text(transcription)
            my_cues = transcript.get_cues(left_bound * 10, right_bound * 10)
            count = 0
            for cue in my_cues:
                bgn_time = cue.bgn_time / 10
                end_time = cue.end_time / 10
                graph.add_hrect(
                    y0=bgn_time,
                    y1=end_time,
                    line_width=1,
                    fillcolor=colors[count],
                    opacity=0.4
                )
                count = (count + 1) % len(colors)

        return graph

    @callback(
        Output("spectrogram", "figure"),
        Input("enable-spectogram", "checked"),
        Input("global-waveform", "selectedData"),
        Input("file-selector", "value"),
        prevent_initial_call=True,
        running=[
            (
                Output("spectrogram", "loading_state"),
                {"is_loading": True},
                {"is_loading": False},
            )
        ],
    )
    def update_spectrogram(enabled, selection, audio_file):
        """
        This function updates the spectrogram display independently of the
        local waveform. This function uses the raw file and not any sampled
        data.

        Parameters:
        enabled: bool switch to determine if enabled
        selection (dict): A dictionary containing Plotly selection information.
        FILE (str): The path of the raw audio file.

        Returns:
        Figure: A Plotly Figure object containing a heatmap of the spectrogram
                        image.
        """
        print(enabled)
        if enabled:
            print("calc")
            sample_audio = fio.load_audio(audio_file)

            if selection is not None and "range" in selection.keys():
                left_bound = selection["range"]["x"][0] * 160
                right_bound = selection["range"]["x"][1] * 160
            else:
                left_bound = 0
                right_bound = sample_audio.size

            spec = melspectrogram(
                y=sample_audio[int(left_bound): int(right_bound)],
                sr=16000,
                n_mels=128,
                fmax=4000,
            )
            spec_dB = power_to_db(spec, ref=np.max)
            fig = px.imshow(
                np.flip(np.rot90(spec_dB), 0),
                aspect="auto",
                color_continuous_scale="Greys",
            )
            fig.update_coloraxes(showscale=False)
            fig.update_xaxes(visible=False, fixedrange=True)
            fig.update_yaxes(visible=False, fixedrange=True)
            fig.update_layout(
                showlegend=False,
                margin=dict(b=0, l=0, r=0, t=0),
            )
        else:
            fig = {}
        return fig

    @callback(
        Output("local-beginning", "children"),
        Output("local-end", "children"),
        Input("global-waveform", "selectedData"),
        Input("audio-length", "data"),
    )
    def update_side_labels(selection, audio_length):
        """
        This function updates timestamp labels alongside the local plots.

        Parameters:
        selection (dict): A dictionary containing Plotly selection information.
        _: Dumped file path. (Required to update timestamps when new file is
                selected.)
        sample_audio (ndarray): Stored sampled audio needed for measurement.

        Returns:
        str: The beginning timestamp as a formatted string.
        str: The end timestamp as a formatted string.
        """
        if selection is not None and "range" in selection.keys():
            left_bound = selection["range"]["x"][0] * 0.01
            right_bound = selection["range"]["x"][1] * 0.01
        else:
            left_bound = 0
            right_bound = audio_length * 0.01

        left_ms = int(left_bound % 1 * 1000)
        left_seconds = int(left_bound % 60)
        left_minutes = int((left_bound / 60) % 60)
        left_hours = int((left_bound / 3600) % 60)

        begin = (f"{left_hours:02d}:{left_minutes:02d}:"
                 + f"{left_seconds:02d}.{left_ms:03d}")

        right_ms = int(right_bound % 1 * 1000)
        right_seconds = int(right_bound % 60)
        right_minutes = int((right_bound / 60) % 60)
        right_hours = int((right_bound / 3600) % 60)

        end = (f"{right_hours:02d}:{right_minutes:02d}:"
               + f"{right_seconds:02d}.{right_ms:03d}")

        return begin, end

    @callback(
        Output("card-area", "children"),
        Input("sampled-transcription", "data"),
        Input("global-waveform", "selectedData"),
        prevent_initial_call=True,
    )
    def display_transcription(transcript, selection):
        """
        This function updates transcript display

        Parameters:
        transcript (str): A json string version of the transcript
        selection (dict): A dictionary containing Plotly selection information.

        Returns:
        Array[dmc.Paper]: Dash components displaying the transcript
        """
        if not transcript:
            raise PreventUpdate

        my_annotation = Annotation.from_json_text(transcript)

        # get selection
        if selection is not None and "range" in selection.keys():
            left_bound = selection["range"]["x"][0] * 10
            right_bound = selection["range"]["x"][1] * 10
        else:
            left_bound = 0
            right_bound = my_annotation.max_time

        # get cues in selection
        my_cues = my_annotation.get_cues(left_bound, right_bound)

        # print(my_cues)
        index_count = my_annotation.cues.index(my_cues[0])
        color_count = 0
        result = []
        last_time = left_bound - 10

        # display each cue in selection
        for cue in my_cues:
            # add space before
            if last_time != cue.bgn_time:
                size = (((cue.bgn_time - last_time) /
                        (right_bound - left_bound)) * 82)
                result.append(dmc.Space(h=f"{size}vh"))
            last_time = cue.end_time

            # extract layers
            labels = []
            if cue.labels:
                labels.append(dmc.Group(
                    [
                        dmc.Text(f"Text:", c="blue"),
                        dmc.TextInput(
                            cue.labels[0],
                            id=f"cue-{index_count}-0",
                            w="80%",
                            spellCheck=True,
                        ),
                    ]
                ))
                if len(cue.labels) > 1:
                    for key, text in cue.labels[1].items():
                        labels.append(dmc.Group(
                            [
                                dmc.Text(f"{key}:", c="red"),
                                dmc.TextInput(
                                    text,
                                    id=f"cue-{index_count}-1-{key}",
                                    w="80%",
                                    spellCheck=True,
                                ),
                            ]
                        ))

            # add cue
            size = (cue.length / (right_bound - left_bound)) * 82
            result.append(dmc.Paper(
                children=labels,
                shadow="xs",
                radius="md",
                # m="md",
                h=f"{size}vh",
                mih=f"{len(labels) * 2.25 + 0.75}em",
                withBorder=True,
                p="3px",
                style={
                    "border-color": colors[color_count],
                    "border-width": "3px",
                }
            ))
            index_count += 1
            color_count = (color_count + 1) % len(colors)

        return result

    @callback(
        Output("download-file", "data"),
        State("sampled-transcription", "data"),
        State("upload-transcript", "filename"),
        Input("export-mll", "n_clicks"),
        Input("export-vtt", "n_clicks"),
        Input("export-textgrid", "n_clicks"),
        Input("export-json", "n_clicks"),
        prevent_initial_call=True,
    )
    def export_transcript(transcript, name, _mll, _vtt, _textgrid, _json):
        """
        This function exports/downloads the transcript to the client

        Parameters:
        transcript (str): A json string version of the transcript
        name (str): The file name of the original transcript
        all other parameters are n_clicks of each button

        Returns:
        dict: A dictionary containing the download contents and name
        """
        # determine which button was clicked
        data_type = ctx.triggered_id.split("export-", 1)[1]

        # get name
        name = name.rsplit(".", 1)[0]
        name += "." + data_type

        # get annotation
        my_annotation = Annotation.from_json_text(transcript)

        # convert
        if data_type == "mll":
            content = my_annotation.to_mll_text()
        elif data_type == "vtt":
            content = my_annotation.to_vtt_text()
        elif data_type == "textgrid":
            content = my_annotation.to_textgrid_text()
        else:
            content = transcript  # it's already in json string format

        return dict(content=content, filename=name)

    @callback(
        Input("local-waveform", "clickData"),
    )
    def detect_click(click_data):
        print(click_data['points'][0]['y'])
