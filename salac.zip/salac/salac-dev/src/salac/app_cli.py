## Import from third-party library
import typer

## Import from project library
from salac import __version__
import salac.recipes as rcp

app = typer.Typer()


########################################################################
# Print out the version: salac --version

# Print the version of the project
def print_version(value: bool):
    if value:
        typer.echo(f"Version of SaLAC: {__version__}")
        raise typer.Exit()

# Add the version option.
@app.callback()
def callback(version: bool = typer.Option(
        None, "--version", callback=print_version, is_eager=True)):
    pass


########################################################################
# Conversion from LDC ATC0 transcripts

# Example: run in the atc0_comp/atc0_bos/data/transcripts folder
# salac ldcatc2stm log_f1_1.txt same
@app.command()
def ldcatc2stm(src_file: str, dst_file: str):
    """Convert a LDC ATC0 transcript file to STM."""
    if dst_file == "same":
        dst_file = src_file[:-3] + "stm"
    if rcp.ldcatc2stm_(src_file, dst_file):
        typer.echo(f'Conversion saved to {dst_file}')


# Example: run in the parent folder of the atc0_comp folder
# salac ldcatc2stm-dir atc0_comp "atc0_comp/atc0_prepared/asr_stm"
@app.command()
def ldcatc2stm_dir(src_dir: str, dst_dir: str):
    """Convert multiple LDC ATC0 transcript files to STM."""
    if rcp.ldcatc2stm_dir_(src_dir, dst_dir):
        typer.echo(f'Conversion saved to {dst_dir}')


# Example: run in the atc0_comp/atc0_bos/data/transcripts folder
# salac ldcatc2vtt log_f1_1.txt log_f1_1_new.vtt
# salac ldcatc2vtt log_lw_2.txt same
@app.command()
def ldcatc2vtt(src_file: str, dst_file: str):
    """Convert a LDC ATC0 transcript file to VTT."""
    if dst_file == "same":
        dst_file = src_file[:-3] + "vtt"
    if rcp.ldcatc2vtt_(src_file, dst_file):
        typer.echo(f'Conversion saved to {dst_file}')


# Example: run in the parent folder of the atc0_comp folder
# salac ldcatc2vtt-dir atc0_comp "atc0_comp/salai_atc0/asr_vtt"
@app.command()
def ldcatc2vtt_dir(src_dir: str, dst_dir: str):
    """Convert multiple LDC ATC0 transcript files to VTT."""
    if rcp.ldcatc2vtt_dir_(src_dir, dst_dir):
        typer.echo(f'Conversion saved to {dst_dir}')


########################################################################
# Conversion from MLL files

# Example:
# salac toml2json old-toml-file.toml new-json-file.json
@app.command()
def mll2json(src_file: str, dst_file: str, ref_file: str = None):
    """Convert a MLL file to JSON."""
    if dst_file == "same":
        dst_file = src_file[:-3] + "json"
    if rcp.mll2json_(src_file, dst_file, ref_file):
        typer.echo(f'Conversion saved to {dst_file}')


# Example:
# salac toml2textgrid old-toml-file.toml new-textGrid-file.TextGrid
@app.command()
def mll2textgrid(src_file: str, dst_file: str, ref_file: str = None):
    """Convert a MLL file to TextGrid."""
    if dst_file == "same":
        dst_file = src_file[:-3] + "textgrid"
    if rcp.mll2textgrid_(src_file, dst_file, ref_file):
        typer.echo(f'Conversion saved to {dst_file}')


# Example:
# salac toml2vtt old-toml-file.toml new-vtt-file.vtt
@app.command()
def mll2vtt(src_file: str, dst_file: str, ref_file: str = None):
    """Convert a MLL file to VTT."""
    if dst_file == "same":
        dst_file = src_file[:-3] + "vtt"
    if rcp.mll2vtt_(src_file, dst_file, ref_file):
        typer.echo(f'Conversion saved to {dst_file}')


########################################################################
# Conversion from TextGrid files

# Example:
# salac textgrid2json FOIA_LC2_12Z-14Z_7-24-23-clip.TextGrid a-new.json
@app.command()
def textgrid2json(src_file: str, dst_file: str):
    """Convert a TextGrid file to JSON."""
    if dst_file == "same":
        dst_file = src_file[:-8] + "json"
    if rcp.textgrid2json_(src_file, dst_file):
        typer.echo(f'Conversion saved to {dst_file}')


# Example:
# salac textgrid2toml FOIA_LC2_12Z-14Z_7-24-23-clip.TextGrid a-new.toml
@app.command()
def textgrid2mll(src_file: str, dst_file: str, ref_file: str = None):
    """Convert a TextGrid file to MLL."""
    if dst_file == "same":
        dst_file = src_file[:-8] + "mll"
    if rcp.textgrid2mll_(src_file, dst_file, ref_file):
        typer.echo(f'Conversion saved to {dst_file}')


# Example: run in the parent folder of the textgrid-raw-2024-06-04 folder
# salac textgrid2txt-dir textgrid-raw-2024-06-04 textgrid-raw-2024-06-04-txt
@app.command()
def textgrid2txt_dir(src_dir: str, dst_dir: str):
    """Convert multiple TextGrid transcript files to text files."""
    if rcp.textgrid2txt_dir_(src_dir, dst_dir):
        typer.echo(f'Conversion saved to {dst_dir}')


# Example:
# salac textgrid2vtt FOIA_LC2_12Z-14Z_7-24-23-clip.TextGrid a-new.vtt
@app.command()
def textgrid2vtt(src_file: str, dst_file: str):
    """Convert a TextGrid file to VTT."""
    if dst_file == "same":
        dst_file = src_file[:-8] + "vtt"
    if rcp.textgrid2vtt_(src_file, dst_file):
        typer.echo(f'Conversion saved to {dst_file}')


########################################################################
# Conversion from VTT files

# Example:
# salac vtt2mll FOIA_LC2_12Z-14Z_7-24-23-clip.VTT same
@app.command()
def vtt2mll(src_file: str, dst_file: str, ref_file: str = None):
    """Convert a VTT file to MLL."""
    if dst_file == "same":
        dst_file = src_file[:-3] + "mll"
    if rcp.vtt2mll_(src_file, dst_file, ref_file):
        typer.echo(f'Conversion saved to {dst_file}')


# Example:
# salac vtt2textgrid FOIA_LC2_12Z-14Z_7-24-23-clip.VTT same
@app.command()
def vtt2textgrid(src_file: str, dst_file: str):
    """Convert a VTT file to TextGrid."""
    if dst_file == "same":
        dst_file = src_file[:-3] + "TextGrid"
    if rcp.vtt2textgrid_(src_file, dst_file):
        typer.echo(f'Conversion saved to {dst_file}')


# Example: run in the parent folder of the VTT files, say
#  atc0_comp/salai_atc0
# salac vtt2textgrid-dir asr_vtt asr_textgrid
@app.command()
def vtt2textgrid_dir(src_dir: str, dst_dir: str):
    """Convert multiple VTT files to TextGrid."""
    if rcp.vtt2textgrid_dir_(src_dir, dst_dir):
        typer.echo(f'Conversion saved to {dst_dir}')


########################################################################
# Merge two VTT files

# Example:
# salac merge2vtts old1.vtt old2.vtt 120000 new.vtt
@app.command()
def merge2vtts(src_file1: str, src_file2: str, time_offset: int,
               dst_file: str):
    """Merge two VTT files into a single one with a given time_offset."""

    if rcp.merge2vtts_(src_file1, src_file2, time_offset, dst_file):
        typer.echo(f'Merged VTT saved to {dst_file}')


if __name__ == "__main__":
    app()
