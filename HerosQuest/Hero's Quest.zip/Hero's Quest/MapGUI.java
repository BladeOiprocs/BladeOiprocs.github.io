import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class MapGUI extends Pane {

	private Map map = new Map();
	private Pane pane = new Pane();
	public Rectangle[][] tiles = new Rectangle[20][20];
	private int refX, refY;
	private Line[] lines = new Line[44];
	
	
	public MapGUI() { //displays all the tiles and color codes them appropriately
		for (int i = 0; i < 20; i++) {
			for (int j = 0; j < 20; j++) {
				tiles[i][j] = new Rectangle();
				tiles[i][j].setWidth(40);
				tiles[i][j].setHeight(40);
				tiles[i][j].setLayoutY(25+(j*40));
				tiles[i][j].setLayoutX(25+(i*40));
				getPane().getChildren().add(tiles[i][j]);
				if (getMap().gameMap[i][j].tileName == "Plains") {
					tiles[i][j].setFill(Color.LIMEGREEN);
				}else if(getMap().gameMap[i][j].tileName == "Forest") {
					tiles[i][j].setFill(Color.DARKGREEN);
				}else if(getMap().gameMap[i][j].tileName == "Mountain") {
					tiles[i][j].setFill(Color.PERU);
				}else if(getMap().gameMap[i][j].tileName == "Desert") {
					tiles[i][j].setFill(Color.BEIGE);
				}else if(getMap().gameMap[i][j].tileName == "Water") {
					tiles[i][j].setFill(Color.LIGHTBLUE);
				}else if(getMap().gameMap[i][j].tileName == "Floor") {
					tiles[i][j].setFill(Color.GREY);
				}else if(getMap().gameMap[i][j].tileName == "Wall") {
					tiles[i][j].setFill(Color.DARKGREY);
				}else {
					tiles[i][j].setFill(Color.BLACK);
				}
			}
		}
		for (int j = 0; j < 21; j++) {
			lines[j] = new Line();
			lines[j].setStroke(Color.BLACK);
			lines[j].setLayoutX(25+40*j);
			lines[j].setStartY(25);
			lines[j].setEndY(825);
			getPane().getChildren().add(lines[j]);
		}
		for (int j = 22; j < 43; j++) {
			lines[j] = new Line();
			lines[j].setStroke(Color.BLACK);
			lines[j].setLayoutY(25+40*(j-22));
			lines[j].setStartX(25);
			lines[j].setEndX(825);
			getPane().getChildren().add(lines[j]);
		}
		
		
	}

	public Pane getPane() {
		return pane;
	}

	public void setPane(Pane pane) {
		this.pane = pane;
	}

	public Map getMap() {
		return map;
	}

	public void setMap(Map map) {
		this.map = map;
	}

	
}