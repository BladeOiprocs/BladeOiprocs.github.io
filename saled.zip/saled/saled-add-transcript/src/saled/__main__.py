from saled import app

def main():
    app.app.run(debug=True)

if __name__ == "__main__":
    main()