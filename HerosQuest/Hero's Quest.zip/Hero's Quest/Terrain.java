public class Terrain {
	public String tileName;
	public int moveCost;
	public int tilex;
	public int tiley;
	public Terrain(int type) {
		if (type == 0) {	
			tileName =  "Plains";
			moveCost = 1;
		}else if (type == 1) {
			tileName =  "Forest";
			moveCost = 2;
		}else if (type == 2) {
			tileName =  "Mountain";
			moveCost = 3;
		}else if (type == 3) {
			tileName =  "Desert";
			moveCost = 2;
		}else if (type == 4) {
			tileName =  "Water";
			moveCost = 2;
		}else if (type == 5) {
			tileName =  "Floor";
			moveCost = 1;
		}else if (type == 6) {
			tileName =  "Wall";
			moveCost = 1;
		}else {
			tileName = "Null";
			moveCost = 0;
		}
	}
	
	
	public int getTileX() {
		return tilex;
	}


	public void setTileX(int currentX) {
		this.tilex = currentX;
	}


	public int getTileY() {
		return tiley;
	}


	public void setTileY(int currentY) {
		this.tiley = currentY;
	}
}