import re
from pathlib import Path


def preprocess_ldc_atc0_text(text: str):
    # Replace multiple spaces with a single space
    text = re.sub(r' {2,}', ' ', text)

    # Replace (QUOTE XXX) with 'XXX
    text = re.sub(r'\(quote ([a-z]*)\)', r"'\1", text)

    # Multiple replacements
    text = re.sub(r'\(unintelligible\)', ' <unk> ', text)
    text = re.sub(r'\(laughter\)', ' <laughter> ', text)
    text = re.sub(r'(<unk>)([a-z])', r'\1 \2', text)
    text = re.sub(r'([a-z])(<unk>)', r'\1 \2', text)

    # Replace square brackets with perenthesis
    text = text.replace('[', '(').replace(']', ')')
    # Remove content within parentheses
    text = re.sub(r'\([^)]*\)', '', text)
    # Remove unmatched opening parenthesis and its content
    text = re.sub(r'\([^)]*$', '', text)

    return text


def link_acronyms(text: str):
    # Add spaces at two ends of the string to easy subsequent replacement
    text = f" {text} "

    # First set of sed replacements
    text = re.sub(r'i l s', '|i_l_s|', text)
    text = re.sub(r'd m e', '|d_m_e|', text)
    text = re.sub(r't w a', '|t_w_a|', text)
    text = re.sub(r'v f r', '|v_f_r|', text)
    text = re.sub(r't c a', '|t_c_a|', text)
    text = re.sub(r'd c u', '|d_c_u|', text)
    text = re.sub(r'a t c', '|a_t_c|', text)
    text = re.sub(r' u s ', ' |u_s| ', text)

    # Second set of sed replacements
    text = re.sub(r' ([a-z]) ([a-z]) ', r' \1_\2 ', text)
    text = re.sub(r' ([a-z]) ([a-z])$', r' \1_\2', text)
    text = re.sub(r'^([a-z]) ([a-z]) ', r'\1_\2 ', text)
    text = re.sub(r'^([a-z]) ([a-z])$', r'\1_\2', text)
    text = re.sub(r'_([a-z]) ([a-z]) ', r'_\1_\2 ', text)
    text = re.sub(r'_([a-z]) ([a-z])$', r'_\1_\2', text)
    text = re.sub(r'_([a-z]) ([a-z])_', r'_\1_\2_', text)
    text = re.sub(r' ([a-z]) ([a-z])_', r' \1_\2_', text)

    # Third set of sed replacements (repeating the same as the second)
    text = re.sub(r' ([a-z]) ([a-z]) ', r' \1_\2 ', text)
    text = re.sub(r' ([a-z]) ([a-z])$', r' \1_\2', text)
    text = re.sub(r'^([a-z]) ([a-z]) ', r'\1_\2 ', text)
    text = re.sub(r'^([a-z]) ([a-z])$', r'\1_\2', text)
    text = re.sub(r'_([a-z]) ([a-z]) ', r'_\1_\2 ', text)
    text = re.sub(r'_([a-z]) ([a-z])$', r'_\1_\2', text)
    text = re.sub(r'_([a-z]) ([a-z])_', r'_\1_\2_', text)
    text = re.sub(r' ([a-z]) ([a-z])_', r' \1_\2_', text)

    # Strip |
    text = text.replace('|', '')

    return text.strip()


def creat_mapping_table():
    current_dir = Path(__file__).parent
    table_dir = current_dir / "mapping_tables"
    files = table_dir.glob("*.txt")

    mapping_table = []
    for filepath in files:
        with filepath.open('r', encoding='utf-8') as fd:
            mapping = [
                tuple(line.strip().split("\t"))
                for line in fd
                if (len(line.strip()) > 0 and line[0] != "#")
            ]

            # check that tuples are binary,
            for tpl in mapping:
                if len(tpl) != 2:
                    raise Exception(f"Wrong tuple: {str(tpl)} in {filepath}")

            # mapping_table.entend(mapping)
            mapping_table = mapping_table + mapping

    # precompile the regular expressions,
    compiled_mapping = [
        tuple((re.compile(" " + orig + " "), " " + new + " ")) # extra spaces
        for orig, new in mapping_table
    ]

    return compiled_mapping


def map_transcripts(text: str, compiled_mapping):
    line_ = " " + text.strip() + " "  # adding spaces,
    for regexp, replace in compiled_mapping:
        # Execute twice ensure that consecutive patterns are fully replaced.
        line_ = regexp.sub(replace, line_)
        line_ = regexp.sub(replace, line_)

    return line_[1:-1]  # removing spaces,


def postprocess_ldc_atc0_text(text: str):

    # Add spaces at two ends of the string to easy subsequent typo correction
    text = f" {text} "

    # Remove space between a letter and ' and another letter
    text = re.sub(r'([a-z]) \'([a-z])', r"\1'\2", text)
    # Replace ` with '
    text = re.sub(r'`', "'", text)

    # Correct typos
    text = text.replace(' kil0 ', ' kilo ')
    text = text.replace(' 0h ', ' oh ')
    text = text.replace(' y0u ', ' you ')
    text = text.replace(" 8'll ", " i'll ")

    # Replace a space followed by two or more / and another space with a space
    text = re.sub(r' ///* ', ' ', text)
    # Replace a dangling hyphen with a space
    text = text.replace(' - ', ' ')
    # Replaces complex alphanumeric tokens with `<unk>`
    text = re.sub(r' [a-z0-9\-\.]*[0-9][a-z0-9\-\.]* ', ' <unk> ', text)

    # Remove extra spaces in between and strip spaces at the two ends.
    text = re.sub(r' +', ' ', text).strip()

    return text


def process_ldc_atc0_transcripts(text: str, compiled_mapping):
    text = preprocess_ldc_atc0_text(text)
    text = link_acronyms(text)
    text = map_transcripts(text, compiled_mapping)
    text = postprocess_ldc_atc0_text(text)
    return text
