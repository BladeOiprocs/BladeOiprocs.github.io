import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;

import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;

import javafx.scene.layout.Pane;

import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;


public class mapGUI extends Application {
	private Image[][] image;
	private char[][] matrix = new char[22][22];
	private puzzleLevels puzzle = new puzzleLevels(matrix);
	private boolean moveCase = false;
	private int enemyCount = 0;
	private int level = 1;
	private Enemy[] enemies = new Enemy[15];
	private ImageView[] enemyNode = new ImageView[15];
	private boolean[] oldState = new boolean[15];
	private int[] eH = new int[15];
	private Text[] eHealth = new Text[15];
	private projectile player1Beam = new projectile();
	private projectile player2Beam = new projectile();
	private Node projectileView = new ImageView("file:enemy.png");
	private Node projectile2View = new ImageView("file:enemy.png");
	private powerUp[] boosters = new powerUp[3];
	private Node powerUpImage1= new ImageView("file:powerup1.png");
	private Node powerUpImage2= new ImageView("file:powerup2.png");
	private Node powerUpImage3= new ImageView("file:powerup3.png");
	private Scene how, choose;
	private Pane howTo, mkChoice;
	private Button hHow, hChoose, hPlay, cHow, cChoose, cPlay, p1A, p2A, p1B, p2B, p1C, p2C, p1D, p2D;
	private Image img1, img2, img3, img4;
	private ImageView imgV1, imgV2, imgV3, imgV4;
	private boolean gameStart = false;
	
	
	public char[][] getMatrix() {
		return matrix;
	}
	public Image[][] getArray(){
		return image;
	}
	
	private BorderPane background = new BorderPane();
	private Timeline timeline = new Timeline();
	private GridPane lvlOne;
	private Scene scene1;
	private levelOne lvl = new levelOne();


	private Player playerOne = new Player();
	private String p1Img = "file:player.png";
	private Node player1 =  new ImageView();
	private int pH = playerOne.getHealth();
	private Text pHealth = new Text(pH + "");

	
	private Player playerTwo = new Player();
	private String p2Img = "file:player2.png";
	private Node player2 =  new ImageView();
	private int pH2 = playerTwo.getHealth();
	private Text pHealth2 = new Text(pH2 + "");
	
	private boolean gameFailed;
	private Stage ps;
	public mapGUI() {
		
		
		lvlOne = new GridPane();
		lvlOne.setVgap(0);
		lvlOne.setHgap(0);
		for(int i = 0; i < 22; i++) {
			for(int j = 0; j < 22; j++) {
				lvlOne.add(new ImageView(lvl.getArray()[i][j]),i,j);
			}
		}
		
		player1 =  new ImageView(p1Img);
		player2 =  new ImageView(p2Img);
		
		playerTwo.setX(4);
		
		lvlOne.add(pHealth, 3,3);
		lvlOne.add(pHealth2, 3,4);
		
		boosters[0] = new powerUp();
		boosters[1] = new powerUp();
		boosters[2] = new powerUp();
		
		initalizePowers();
		
		lvlOne.add(powerUpImage1, boosters[0].getPowerX(), boosters[0].getPowerY());
		lvlOne.add(powerUpImage2, boosters[1].getPowerX(), boosters[1].getPowerY());
		lvlOne.add(powerUpImage3, boosters[2].getPowerX(), boosters[2].getPowerY());
		
		generateEnemies(1);
		enemyCount = 1;
		for(int c = 0; c < 15; c++) {	
			oldState[c] = enemies[c].getAlive();
		}
		background.setCenter(lvlOne);
		scene1 = new Scene(background, 880,880);
		movePlayerOnKeyPress(scene1);
		timeline.setCycleCount(Timeline.INDEFINITE);
		KeyFrame keyframe = new KeyFrame(Duration.millis(100), action -> {
			if(gameStart == true) {
				updateMap();
				gameStart = false;
			}
			updatePosition();
			updateLife();
			updateProjectiles();
		
			if(ps!=null && playerOne.getHealth()<=0 && playerTwo.getHealth()<=0 && gameFailed==false)
				
				{
				gameFailed=true;
				GameOver ac = new GameOver();
				try {
					ac.start(new Stage());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				ps.hide();
				}
			
			checkPowerups(playerOne);
			checkPowerups(playerTwo);
			if (enemyCount == 0) {
				System.out.print( "Congratulations! You cleared Level " + level + ".\n");
				level = level +1;
				if (level % 3 == 0) {
					lvl.setMatrix(puzzle.puzzle());
				} else {
					lvl.generateLevel();
				}
				generateEnemies(level);
				updateMap();
				initalizePowers();
				enemyCount = level;
			}
			for(int b = 0; b < 15; b++) {
				if ((enemies[b].getAlive() != false)) {
					enemies[b].enemyAILoop(playerOne, playerTwo, lvl.getMatrix());
				}
			}
		});

		timeline.getKeyFrames().add(keyframe);

		timeline.play();

	}


	private void movePlayerOnKeyPress(Scene scene) {
		scene.setOnKeyPressed(new EventHandler<KeyEvent>() {
			@Override public void handle(KeyEvent event) {
				switch (event.getCode()) {
				case UP:
					movePlayerUp(playerOne);
					updatePosition();
					break;
				case RIGHT:
					movePlayerRight(playerOne);
					updatePosition();
					break;
				case DOWN:
					movePlayerDown(playerOne);
					updatePosition();
					break;
				case LEFT:
					movePlayerLeft(playerOne);
					updatePosition();
					break;
				case M:
					doPlayerAttack(playerOne, playerTwo, 1);
					updateMap();
					break;
				case W:
					movePlayerUp(playerTwo);
					updatePosition();
					break;
				case D:
					movePlayerRight(playerTwo);
					updatePosition();
					break;
				case S:
					movePlayerDown(playerTwo);
					updatePosition();
					break;
				case A:
					movePlayerLeft(playerTwo);
					updatePosition();
					break;
				case V:
					doPlayerAttack(playerTwo, playerOne, 2);
					updateMap();
					break;
				case SHIFT:
					playerOne.setDirection(playerOne.getDirection() + 1);
					if (playerOne.getDirection() > 4) {
						playerOne.setDirection(1);
					}
					System.out.print(playerOne.getDirection());
					break;
				case Z:
					playerTwo.setDirection(playerTwo.getDirection() + 1);
					if (playerTwo.getDirection() > 4) {
						playerTwo.setDirection(1);
					}
					break;
				default:
					break;
				}
			}
		});
	}
	
	
	public void updatePosition() {
		GridPane.setRowIndex(player1, playerOne.getY());
		GridPane.setColumnIndex(player1, playerOne.getX());
		GridPane.setRowIndex(pHealth, playerOne.getY());
		GridPane.setColumnIndex(pHealth, playerOne.getX());
		
		GridPane.setRowIndex(player2, playerTwo.getY());
		GridPane.setColumnIndex(player2, playerTwo.getX());
		GridPane.setRowIndex(pHealth2, playerTwo.getY());
		GridPane.setColumnIndex(pHealth2, playerTwo.getX());

		for(int b = 0; b < 15; b++) {	
			if(enemies[b].getAlive() == true) {
				GridPane.setRowIndex(enemyNode[b], enemies[b].getY());
				GridPane.setColumnIndex(enemyNode[b], enemies[b].getX());
				GridPane.setRowIndex(eHealth[b], enemies[b].getY());
				GridPane.setColumnIndex(eHealth[b], enemies[b].getX());
			}
		}
	}
	
	public void updateProjectiles() {
		if(player1Beam.isInMotion() == true) {
			player1Beam.setxPos(player1Beam.getxPos() + player1Beam.getxVelo());
			player1Beam.setyPos(player1Beam.getyPos() + player1Beam.getyVelo());
			projectileView = new ImageView("file:Enemy.png");
			lvlOne.add(projectileView, player1Beam.getxPos(), player1Beam.getyPos());
			checkHit(player1Beam);
			updateMap();
		}
		if(player2Beam.isInMotion() == true) {
			player2Beam.setxPos(player2Beam.getxPos() + player2Beam.getxVelo());
			player2Beam.setyPos(player2Beam.getyPos() + player2Beam.getyVelo());
			projectile2View = new ImageView("file:Enemy.png");
			lvlOne.add(projectileView, player1Beam.getxPos(), player2Beam.getyPos());
			checkHit(player2Beam);
			updateMap();
		}
	}
	
	public void updateMap() {
		lvl.levelLoader();
		for(int i = 0; i < 22; i++) {
			for(int j = 0; j < 22; j++) {
				lvlOne.add(new ImageView(lvl.getArray()[i][j]),i,j);
			}
		}
		player1 =  new ImageView(p1Img);
		player2 =  new ImageView(p2Img);
		pH = playerOne.getHealth();
		pHealth = new Text(pH + "");
		pH2 = playerTwo.getHealth();
		pHealth2 = new Text(pH2 + "");
		for(int b = 0; b < 15; b++) {
			if(enemies[b].getAlive() == true) {
				if (enemies[b].getClass() == Enemy.class) {
					enemyNode[b] =  new ImageView("file:Enemy.png");
				} else {
					enemyNode[b] =  new ImageView("file:Enemy2.png");
				}
				lvlOne.add(enemyNode[b], enemies[b].getX(), enemies[b].getY());
				eH[b] = enemies[b].getHealth();
				eHealth[b] = new Text(eH[b] + "");
				lvlOne.add(eHealth[b], enemies[b].getY(),enemies[b].getX());
			}
		}
		if (boosters[0].getFlag() == true) {
			powerUpImage1= new ImageView("file:powerup1.png");
			lvlOne.add(powerUpImage1,boosters[0].getPowerX(),boosters[0].getPowerY());
		}
		if (boosters[1].getFlag() == true) {
			powerUpImage2= new ImageView("file:powerup2.png");
			lvlOne.add(powerUpImage2,boosters[1].getPowerX(),boosters[1].getPowerY());	
		}
		if (boosters[2].getFlag() == true) {
			powerUpImage3= new ImageView("file:powerup3.png");
			lvlOne.add(powerUpImage3,boosters[2].getPowerX(),boosters[2].getPowerY());
		}

		
		lvlOne.add(player1, playerOne.getX(), playerOne.getY());
		lvlOne.add(player2, playerTwo.getX(), playerTwo.getY());
		lvlOne.add(pHealth, playerOne.getX(), playerOne.getY());
		lvlOne.add(pHealth2 ,playerTwo.getX(), playerTwo.getY());
	}
	
	public void updateLife() {
		for(int c = 0; c < 15; c++) {
			if(enemies[c].getHealth() <= 0) {
				enemies[c].setAlive(false);
				enemies[c].setX(100);
				enemies[c].setY(100);
			}
			if ((oldState[c] == true)) {	
				if ((enemies[c].getAlive() != oldState[c])) {
				enemyCount = enemyCount - 1;
				lvlOne.getChildren().remove(enemyNode[c]);
				lvlOne.getChildren().remove(eHealth[c]);
				}
			}
				oldState[c] = enemies[c].getAlive();
		}
	}
	
	public void movePlayerUp(Player pX) {
		char[][] field = lvl.getMatrix();
		if (field[pX.getX()][pX.getY()-1]== 'P') {
			moveCase = true;
		} else {
			moveCase = false;
		}
		for(int u = 0; u < 15; u++) {
			if ((pX.getX() == enemies[u].getX()) && (pX.getY()-1 == enemies[u].getY())){
				moveCase = false;
			}
		}
		if (moveCase == true) {
			pX.setY(pX.getY() - 1);
		}
	}

	public void movePlayerRight(Player pX) {
		char[][] field = lvl.getMatrix();
		if (field[pX.getX()+1][pX.getY()]== 'P') {
			moveCase = true;
		} else {
			moveCase = false;
		}
		for(int u = 0; u < 15; u++) {
			if ((pX.getX()+1 == enemies[u].getX()) && (pX.getY() == enemies[u].getY())){
				moveCase = false;
			}
		}
		
		if (moveCase == true) {
			pX.setX(pX.getX() + 1);
		}
	}
	
	public void movePlayerDown(Player pX) {
		char[][] field = lvl.getMatrix();
		if (field[pX.getX()][pX.getY()+1]== 'P') {
			moveCase = true;
		} else {
			moveCase = false;
		}
		for(int u = 0; u < 15; u++) {
			if ((pX.getX() == enemies[u].getX()) && (pX.getY()+1 == enemies[u].getY())){
				moveCase = false;
			}
		}
		
		if (moveCase == true) {
			pX.setY(pX.getY() + 1);
		}
	}
	
	public void movePlayerLeft(Player pX) {
		char[][] field = lvl.getMatrix();
		if (field[pX.getX()-1][pX.getY()]== 'P') {
			moveCase = true;
		} else {
			moveCase = false;
		}
		for(int u = 0; u < 15; u++) {
			if ((pX.getX()-1 == enemies[u].getX()) && (pX.getY() == enemies[u].getY())){
				moveCase = false;
			}
		}
		
		if (moveCase == true) {
			pX.setX(pX.getX() - 1);
		}
	}
	
	
	public void checkHit(projectile pX) {
		if (lvl.getMatrix()[pX.getxPos()][pX.getyPos()] == 'W') {
			lvl.getMatrix()[pX.getxPos()][pX.getyPos()] = 'P';
			projectileStop(pX);
		}else if (lvl.getMatrix()[pX.getxPos()][pX.getyPos()] == 'U') {
			projectileStop(pX);
		}
		for(int c = 0; c < 15; c++) {
			if ((pX.getxPos() == enemies[c].getX()) && (pX.getyPos() == enemies[c].getY())) {
				enemies[c].setHealth(enemies[c].getHealth() - 1);
				System.out.print(enemies[c].getHealth() + "\n");
				projectileStop(pX);
			}
		}
	}
	
	public void destroyHere(int xPos, int yPos) {
		for(int c = 0; c < 15; c++) {
			if ((xPos == enemies[c].getX()) && (yPos == enemies[c].getY())) {
				enemies[c].setHealth( enemies[c].getHealth() - 1);
				System.out.print(enemies[c].getHealth() + "\n");
			}
		}
		if (lvl.getMatrix()[xPos][yPos] == 'W') {
			lvl.getMatrix()[xPos][yPos] = 'P';
		}
		updateMap();
	}
	
	public void projectileStop(projectile pX) {
		pX.setInMotion(false);
		lvlOne.getChildren().remove(projectileView);
		pX.setxPos(50);
		pX.setyPos(50);
	}
	
	public void generateEnemies(int currLevel){
		if(currLevel > 15) {
			currLevel = 15;
		}
		for(int l = 0; l < 15; l++) {
			//flip a coin
			if ((Math.random()) < .5) {
				enemies[l] = new Enemy();
			} else {
				enemies[l] = new Enemy2();
			}
		}
		for(int k = 0; k < currLevel; k++) {
			enemies[k].setX((int)(Math.random()*(20-2+1)+2));
			enemies[k].setY((int)(Math.random()*(20-2+1)+2));
			while (lvl.getMatrix()[enemies[k].getX()][enemies[k].getY()] != 'P'){
				enemies[k].setX((int)(Math.random()*(20-2+1)+2));
				enemies[k].setY((int)(Math.random()*(20-2+1)+2));
			}
			if (enemies[k].getClass() == Enemy.class) {
				enemyNode[k] =  new ImageView("file:Enemy.png");
			} else {
				enemyNode[k] =  new ImageView("file:Enemy2.png");
			}
			
			eH[k] = enemies[k].getHealth();
			eHealth[k] = new Text(eH[k] + "");
			lvlOne.add(enemyNode[k], enemies[k].getX(), enemies[k].getY());
			lvlOne.add(eHealth[k], enemies[k].getX(), enemies[k].getY());
			enemies[k].setAlive(true);
		}

	}
	public void initalizePowers() {
		for (int z = 0; z < 3; z++) {
			while (lvl.getMatrix()[boosters[z].getPowerX()][boosters[z].getPowerY()] != 'P') {
				boosters[z].setPowerX((int) (Math.random()*(20-2+1)+2));
				boosters[z].setPowerY((int) (Math.random()*(20-2+1)+2));
				boosters[z].setFlag(true);
			}	
		}	
	}
	
	public void doPlayerAttack(Player pX, Player ally, int playerNum) {
		if (pX.getType() == 2) {
			playerAttack2(pX, pX.getDirection());
		}else if (pX.getType() == 3 ) {
			playerAttack3(pX, pX.getDirection());
		}else if (pX.getType() == 4 ) {
			playerAttack4(pX, ally);
		} else if ((pX.getType() == 1 ) && (playerNum == 1)) {
			playerAttack(pX, pX.getDirection());
		} else if ((pX.getType() == 1 ) && (playerNum == 2)) {
			playerAttack2(pX, pX.getDirection());
		} else {
			
		}
	}

	
	public void playerAttack(Player pX, int direction) {
		player1Beam = new projectile();
		player1Beam.setxPos(pX.getX());
		player1Beam.setyPos(pX.getY());
		if (direction == 1) {
			player1Beam.setyVelo(-1);
		} else if (direction == 2) {
			player1Beam.setxVelo(1);
		} else if (direction == 3) {
			player1Beam.setyVelo(1);
		} else if (direction == 4) {
			player1Beam.setxVelo(-1);
		}
		player1Beam.setInMotion(true);
		lvlOne.add(projectileView, player1Beam.getxPos(), player1Beam.getyPos());
	}
	
	public void player2Attack(Player pX, int direction) {
		player2Beam = new projectile();
		player2Beam.setxPos(pX.getX());
		player2Beam.setyPos(pX.getY());
		if (direction == 1) {
			player2Beam.setyVelo(-1);
		} else if (direction == 2) {
			player2Beam.setxVelo(1);
		} else if (direction == 3) {
			player2Beam.setyVelo(1);
		} else if (direction == 4) {
			player2Beam.setxVelo(-1);
		}
		player2Beam.setInMotion(true);
		lvlOne.add(projectile2View, player2Beam.getxPos(), player2Beam.getyPos());
	}
	
	public void playerAttack2(Player pX, int direction) {
		if (direction == 1) {
			for(int i = 0; i < 2; i++) {
				destroyHere(pX.getX()-1,pX.getY()-1);
				destroyHere(pX.getX(),pX.getY()-1);
				destroyHere(pX.getX()+1,pX.getY()-1);
			}
		} else if (direction == 2) {
			for(int i = 0; i < 2; i++) {
				destroyHere(pX.getX()+1,pX.getY()-1);
				destroyHere(pX.getX()+1,pX.getY());
				destroyHere(pX.getX()+1,pX.getY()+1);
			}
		} else if (direction == 3) {
			for(int i = 0; i < 2; i++) {
				destroyHere(pX.getX()-1,pX.getY()+1);
				destroyHere(pX.getX(),pX.getY()+1);
				destroyHere(pX.getX()+1,pX.getY()+1);
			}
		} else if (direction == 4) {
			for(int i = 0; i < 2; i++) {
				destroyHere(pX.getX()-1,pX.getY()-1);
				destroyHere(pX.getX()-1,pX.getY());
				destroyHere(pX.getX()-1,pX.getY()+1);
			}
		}
	}
	
	
	public void playerAttack3(Player pX, int direction) {
		if (direction == 1) {
			for(int i = 0; i < 3; i++) {
				destroyHere(pX.getX(),pX.getY()-1);
				destroyHere(pX.getX(),pX.getY()-2);
			}
		} else if (direction == 2) {
			for(int i = 0; i < 3; i++) {
				destroyHere(pX.getX()+1,pX.getY());
				destroyHere(pX.getX()+2,pX.getY());
			}
		} else if (direction == 3) {
			for(int i = 0; i < 3; i++) {
				destroyHere(pX.getX(),pX.getY()+1);
				destroyHere(pX.getX(),pX.getY()+2);
			}
		} else if (direction == 4) {
			for(int i = 0; i < 3; i++) {
				destroyHere(pX.getX()-1,pX.getY());
				destroyHere(pX.getX()-2,pX.getY());
			}
		}
	}
	
	public void playerAttack4(Player pX, Player ally) {
			if ((pX.getX() - 1 == ally.getX()) && (pX.getY() == ally.getY())) {
				ally.setHealth(ally.getHealth() + 1);
			}
			if ((pX.getX() + 1 == ally.getX()) && (pX.getY() == ally.getY())) {
				ally.setHealth(ally.getHealth() + 1);
			}
			if ((pX.getX() == ally.getX()) && (pX.getY() - 1 == ally.getY())) {
				ally.setHealth(ally.getHealth() + 1);
			}
			if ((pX.getX() == ally.getX()) && (pX.getY() + 1 == ally.getY())) {
				ally.setHealth(ally.getHealth() + 1);
			}
			if(ally.getHealth() > 10) {
				ally.setHealth(10);
			}
		if (lvl.getMatrix()[pX.getX()-1][pX.getY()] == 'W') {
			lvl.getMatrix()[pX.getX()-1][pX.getY()] = 'P';
		}
		if (lvl.getMatrix()[pX.getX()+1][pX.getY()] == 'W') {
			lvl.getMatrix()[pX.getX()+1][pX.getY()] = 'P';
		}
		if (lvl.getMatrix()[pX.getX()][pX.getY()-1] == 'W') {
			lvl.getMatrix()[pX.getX()][pX.getY()-1] = 'P';
		}
		if (lvl.getMatrix()[pX.getX()][pX.getY()+1] == 'W') {
			lvl.getMatrix()[pX.getX()][pX.getY()+1] = 'P';
		}
	}
	
	private void checkPowerups(Player pX) {

		//powerup 1 super kill
		if ((pX.getX() == boosters[0].getPowerX()) && (pX.getY() ==  boosters[0].getPowerY())) {
			if(boosters[0].getFlag() == true){
			lvlOne.getChildren().remove(powerUpImage1);
			boosters[0].setFlag(false);
			System.out.println("You picked up the super kill powerup!");
			updateMap();
			}
		}


		//powerup2 health regen
		if ((pX.getX() == boosters[1].getPowerX()) && (pX.getY() ==  boosters[1].getPowerY())) {
			if(boosters[1].getFlag() == true){
			lvlOne.getChildren().remove(powerUpImage2);
			boosters[1].setFlag(false);
			System.out.println("You picked up the health powerup!");
			System.out.println("Your health has been regenerated.");
			updateMap();
			}
		}
		//powerup3 enemy health decreaser
		if ((pX.getX() == boosters[2].getPowerX()) && (pX.getY() ==  boosters[2].getPowerY())) {
			if(boosters[2].getFlag() == true){
			lvlOne.getChildren().remove(powerUpImage3);
			boosters[2].setFlag(false);
			for(int b = 0; b < 15; b++) {
				if(enemies[b].getAlive() == true) {
					enemies[b].setHealth(enemies[b].getHealth()/2);
				}
			}
				System.out.println("You picked up the bomb powerup!");
				System.out.println("Enemy health has been decreased to half.");
					updateMap();
			}
		}

	}

	public void start(Stage primaryStage) throws IOException{
		
		
		
		ps=primaryStage;
		gameFailed=false;
		
		primaryStage.setTitle("Galactic Dungeon");
		howTo = new Pane();
		Text hText = new Text("Player 1 movements include:\tPlayer 2 movements include:\nW key to move up\t\tUp arrow key to move up\nS key to move down\tDown arrow key to move down\nA key to move left\t\tLeft arrow key to move left\nD key to move right\t\tRight arrow key to move right\nR key to attack\t\t\tM key to attack\n\n"
				+ "The goal of this game is to make it as far as you can, each level \nwill become increasingly harder, no two levels will be the same.\n After reading this please select the 'Choose Avatar' button\nand select who you would like to be");
		hText.setLayoutX(50);
		hText.setLayoutY(50);
		hHow = new Button("How To Play");
		hHow.setLayoutX(0);
		hHow.setLayoutY(0);
		hChoose = new Button("Choose Avatar");
		hChoose.setLayoutX(150);
		hChoose.setLayoutY(0);
		hPlay = new Button("Enter Game");
		hPlay.setLayoutX(322);
		hPlay.setLayoutY(0);

		howTo.getChildren().addAll(hHow, hChoose, hPlay, hText);
		how = new Scene(howTo,400,300);

		mkChoice = new Pane();

		img1 = new Image("File:player.png");
		imgV1 = new ImageView();
		imgV1.setLayoutX(70);
		imgV1.setLayoutY(100);
		imgV1.setImage(img1);
		
		img2 = new Image("File:player2.png");
		imgV2 = new ImageView();
		imgV2.setLayoutX(270);
		imgV2.setLayoutY(100);
		imgV2.setImage(img2);

		img3 = new Image("File:player3.png");
		imgV3 = new ImageView();
		imgV3.setLayoutX(70);
		imgV3.setLayoutY(200);
		imgV3.setImage(img3);

		img4 = new Image("File:player4.png");
		imgV4 = new ImageView();
		imgV4.setLayoutX(270);
		imgV4.setLayoutY(200);
		imgV4.setImage(img4);

		Text cText = new Text("Please select which avatar each of you would like to use. Player\n"
							 +"one click the 'Player One' button to the right of your desired avatar.\n"
							 +"Player two click the 'Player Two' button to the right your desired avatar.");
		cText.setLayoutX(10);
		cText.setLayoutY(50);
		
		cHow = new Button("How To Play");
		cHow.setLayoutX(0);
		cHow.setLayoutY(0);
		cChoose = new Button("Choose Avatar");
		cChoose.setLayoutX(150);
		cChoose.setLayoutY(0);
		cPlay = new Button("Enter Game");
		cPlay.setLayoutX(322);
		cPlay.setLayoutY(0);
		
		p1A = new Button("Player One");
		p1A.setLayoutX(10);
		p1A.setLayoutY(150);
		p2A = new Button("Player Two");
		p2A.setLayoutX(90);
		p2A.setLayoutY(150);
		
		p1B = new Button("Player One");
		p1B.setLayoutX(210);
		p1B.setLayoutY(150);
		p2B = new Button("Player Two");
		p2B.setLayoutX(290);
		p2B.setLayoutY(150);
		
		p1C = new Button("Player One");
		p1C.setLayoutX(10);
		p1C.setLayoutY(250);
		p2C = new Button("Player Two");
		p2C.setLayoutX(90);
		p2C.setLayoutY(250);
		
		p1D = new Button("Player One");
		p1D.setLayoutX(210);
		p1D.setLayoutY(250);
		p2D = new Button("Player Two");
		p2D.setLayoutX(290);
		p2D.setLayoutY(250);
		
		
		mkChoice.getChildren().addAll(cText, imgV1, imgV2, imgV3, imgV4, cHow, cChoose, cPlay, p1A, p2A, p1B, p2B, p1C, p2C, p1D, p2D);
		choose = new Scene(mkChoice,400,300);
		hHow.setOnAction(e -> primaryStage.setScene(how));
		
		p1A.setOnAction(new EventHandler<ActionEvent>(){
			public void handle(ActionEvent t){
				p1Img = "file:player.png";
				playerOne.setType(1);
			}
		});
		p2A.setOnAction(new EventHandler<ActionEvent>(){
			public void handle(ActionEvent t){
				p2Img = "file:player.png";
				playerTwo.setType(1);
			}
		});
		p1B.setOnAction(new EventHandler<ActionEvent>(){
			public void handle(ActionEvent t){
				p1Img = "file:player2.png";
				playerOne.setType(2);
			}
		});
		p2B.setOnAction(new EventHandler<ActionEvent>(){
			public void handle(ActionEvent t){
				p2Img = "file:player2.png";
				playerTwo.setType(2);
			}
		});
		p1C.setOnAction(new EventHandler<ActionEvent>(){
			public void handle(ActionEvent t){
				p1Img = "file:player3.png";
				playerOne.setType(3);
			}
		});
		p2C.setOnAction(new EventHandler<ActionEvent>(){
			public void handle(ActionEvent t){
				p2Img = "file:player3.png";
				playerTwo.setType(3);
			}
		});
		p1D.setOnAction(new EventHandler<ActionEvent>(){
			public void handle(ActionEvent t){
				p1Img = "file:player4.png";
				playerOne.setType(4);
			}
		});
		p2D.setOnAction(new EventHandler<ActionEvent>(){
			public void handle(ActionEvent t){
				p2Img = "file:player4.png";
				playerTwo.setType(4);
			}
		});
		
		
		hChoose.setOnAction(new EventHandler<ActionEvent>(){
			public void handle(ActionEvent t){
				primaryStage.setScene(choose);
			}
		});
		cHow.setOnAction(new EventHandler<ActionEvent>(){
			public void handle(ActionEvent t){
				primaryStage.setScene(how);
			}
		});
		cPlay.setOnAction(new EventHandler<ActionEvent>(){
			public void handle(ActionEvent t){
				primaryStage.setScene(scene1);
				System.out.println("Made it to game");
				gameStart = true;
			}
		});
		hPlay.setOnAction(new EventHandler<ActionEvent>(){
			public void handle(ActionEvent t){
				primaryStage.setScene(scene1);
				System.out.println("Made it to game");
				gameStart = true;
			}
		});
		primaryStage.setScene(how);
		primaryStage.show();

	}

	public static void main(String[] args)
	{
		launch(args);
	}

}
