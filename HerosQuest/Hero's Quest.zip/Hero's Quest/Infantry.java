public class Infantry extends Unit {

	private boolean crossWater = true;
	private boolean crossMount = false;
	
	public Infantry() {
		super();
		
	}
	
	
}