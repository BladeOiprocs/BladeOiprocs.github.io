public class Flier extends Unit {

	private boolean crossWater = true;
	private boolean crossMount = true;
	private boolean mounted = true;
	
	public Flier() {
		super();
		
	}
	
	@Override
	public void dismount() {
		setUnitStat(7, getUnitStats(7) + 2); //Speed  + 2
		setUnitStat(10, getUnitStats(10) - 2);// Movement - 2
		mounted = false;
	}
	
	@Override
	public void mount() {
		setUnitStat(7, getUnitStats(7) - 2); //Speed  - 2
		setUnitStat(10, getUnitStats(10) + 2);// Movement + 2
		mounted = true;
	}
}