import re
from dataclasses import dataclass
from datetime import datetime, timezone

# The Cue class defines basic data structure of each cue in an annotation.
@dataclass
class Cue:
    begin_time: int
    end_time: int
    text: str

    @property
    def length(self):
        return self.end_time - self.begin_time

    def __str__(self):
        return "beg: " + str(self.begin_time) + "\nend: " + \
            str(self.end_time) + "\ntxt: " + self.text

    def add_time_offset(self, time_offset_in_ms: int):
        self.begin_time += time_offset_in_ms
        self.end_time += time_offset_in_ms


# The Annotation class defines the collection of cues of a single file.
class Annotation:
    def __init__(self, cues: list = [], has_silence: bool = None):
        self.cues = cues
        self.has_silence = has_silence

    # List of cues is sorted and the max time is at the end of cues
    @property
    def max_time(self):
        return self.cues[-1].end_time

    @classmethod
    def read_file_to_text(self, filename: str):
        with open(filename, 'r') as file:
            file_text = file.read()
            file.close()
        return file_text

    @classmethod
    def write_text_to_file(self, filename: str, file_text: str):
        with open(filename, 'w') as file:
            file.write(file_text)

    @classmethod
    def from_textgrid_text(cls, file_text: str):
        # Ref https://www.fon.hum.uva.nl/praat/manual/TextGrid_file_formats.html

        # regular expression to match all the fields related to cues.
        match_patten = '[ \t\n\r\f\v]("[^"]*"|[0-9.]+)[ \t\n\r\f\v]'
        fields = re.findall(match_patten, file_text)

        # Can only handle single tier TextGrid files now
        fields = fields[2:]  # ignore header
        fields = fields[3:]  # ignore file information
        fields = fields[5:]  # ignore interval information

        # Read in groups of 3 until the end of the file text
        # Inefficient implementation; ok with normal sized files.
        cues = []
        while len(fields) >= 3:
            begin_time = int(float(fields.pop(0)) * 1000)
            end_time = int(float(fields.pop(0)) * 1000)
            text = fields.pop(0).strip('"')
            cue = Cue(begin_time=begin_time, end_time=end_time, text=text)
            cues.append(cue)

        return Annotation(cues=cues, has_silence=True)

    @classmethod
    def from_vtt_srt_text(cls, file_text: str):
        text_list = file_text.split("\n")
        cues = []
        end_of_text_list = False
        while True:
            # Find the time line first
            while " --> " not in text_list[0]:
                text_list.pop(0)
                if len(text_list) == 0:
                    end_of_text_list = True
                    break
            if end_of_text_list:
                break

            times = text_list.pop(0)
            text = text_list.pop(0)
            begin_time, end_time = times.split(" --> ")
            begin_time = ts_to_ms(begin_time)
            end_time = ts_to_ms(end_time)
            text = text.strip("- ")
            cue = Cue(begin_time=begin_time, end_time=end_time, text=text)
            cues.append(cue)

        return Annotation(cues=cues, has_silence=False)

    def add_silence(self):
        # Check if silence is needed in the beginning
        if self.cues[0].begin_time != 0:
            self.cues.insert(0, Cue(begin_time=0,
                                    end_time=self.cues[0].begin_time,
                                    text="[Silence]"))

        i = 1   # Indix to insert a silence cue if needed
        # Check between each cue to see if end time and start time match up
        while i < len(self.cues):
            prev_end_time = self.cues[i - 1].end_time
            next_begin_time = self.cues[i].begin_time
            if prev_end_time < next_begin_time:
                # If they don't match, add silence cue
                self.cues.insert(i, Cue(begin_time=prev_end_time,
                                        end_time=next_begin_time,
                                        text="[Silence]"))
                i += 1
            elif prev_end_time > next_begin_time:
                print("Error: overlapping times between: ")
                print("Interval A:")
                print(self.cues[i - 1])
                print("Interval B:")
                print(self.cues[i])
                print("Cleaned up these issues manually in the original file")
            i += 1
        self.has_silence = True

    def remove_silence(self):
        # Ref: https://stackoverflow.com/questions/1157106/remove-all-occurrences-of-a-value-from-a-list
        self.cues = [cue for cue in self.cues if cue.text != "[Silence]"]
        self.has_silence = False

    def to_textgrid_text(self):
        if not self.has_silence:
            print("Error: cannot create TextGrid without silences!")
            return ""

        # self.sort()  # make sure it's sorted
        file_text =  'File type = \"ooTextFile\"\n'
        file_text += 'Object class = \"TextGrid\"\n'
        file_text += '\nxmin = 0\n'
        file_text += f'xmax = {self.max_time / 1000:.3f}\n'
        file_text += 'tiers? <exists>\n'

        file_text += 'size = 1\n'
        file_text += 'item []:\n'
        file_text += '    item [1]:\n'
        file_text += '        class = \"IntervalTier\"\n'
        file_text += '        name = \"text-label\"\n'
        file_text += '        xmin = 0\n'
        file_text += f'        xmax = {self.max_time / 1000:.3f}\n'
        file_text += f'        intervals: size = {len(self.cues)}\n'

        i = 1
        for cue in self.cues:
            file_text += f'        intervals [{i}]:\n'
            file_text += f'            xmin = {cue.begin_time/1000:.3f}\n'
            file_text += f'            xmax = {cue.end_time/1000:.3f}\n'
            file_text += f'            text = \"{cue.text}\"\n'
            i += 1

        return file_text

    def to_vtt_text(self):
        if self.has_silence:
            print("Note: there will be silences in the VTT file!")
            # Note that this is desired for some cases.

        # self.sort() # make sure it's sorted
        use_hour = self.max_time > 3600000 # include hour if more than 1 hour
        file_text = 'WEBVTT\n\n'
        for cue in self.cues:
            file_text += ms_to_ts(cue.begin_time, delimeter=".", hour=use_hour)
            file_text += ' --> '
            file_text += ms_to_ts(cue.end_time, delimeter=".", hour=use_hour)
            file_text += '\n'
            file_text += cue.text + '\n\n'

        return file_text

    def to_srt_text(self):
        if self.has_silence:
            print("Note: there will be silences in the SRT file!")
            # Note that this is desired for some cases.

        file_text = ''
        i = 1
        for cue in self.cues:
            file_text += str(i) + '\n'
            file_text += ms_to_ts(cue.begin_time, delimeter=",", hour=True)
            file_text += ' --> '
            file_text += ms_to_ts(cue.end_time, delimeter=",", hour=True)
            file_text += '\n'
            file_text += cue.text + '\n\n'

        return file_text

    def add_annotation(self, second_annotation, time_offset: int):
        for cue in second_annotation.cues:
            cue.add_time_offset(time_offset)
            self.cues.append(cue)


#######################################################
# Helper functions

# Convert ts (time string) to ms (milliseconds):
#     from 00:05.160 to 5160 (robust)
# Works for both VTT and SRT formats
def ts_to_ms(ts: str):
    ts = ts.replace(",", ".")
    hour_min_sec, milliseconds = ts.split(".")
    if len(hour_min_sec) == 5:
        hour_min_sec = f'00:{hour_min_sec}'
    time = datetime.strptime(hour_min_sec, "%H:%M:%S")
    time_in_sec = time.hour * 3600 + time.minute * 60 + time.second
    time_in_ms = time_in_sec * 1000 + int(f'{milliseconds:0<3}')
    return time_in_ms

# Convert milliscends to time string: from 5160 to 00:05.160
def ms_to_ts(milliseconds: int, delimeter: str = ".", hour: bool = True):
    time = datetime.fromtimestamp(milliseconds/1000, tz=timezone.utc)
    if hour:
        time_text = f'{time:%H:%M:%S}'
    else:
        time_text = f'{time:%M:%S}'
    ms_only = milliseconds % 1000
    time_text += f'{delimeter}{ms_only:03}'
    return time_text