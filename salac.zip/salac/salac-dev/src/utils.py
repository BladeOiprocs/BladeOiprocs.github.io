# These functions are not used for now in SaLAC.
# Will be saved for possible future applications.

# implementation of quick sort algorithm without function recursion
# hitting maximum recursion limit, so I created my own stack simulator
# used this for vanilla quick sort reference
# https://www.geeksforgeeks.org/quick-sort/
def quick_sort_cues(cue_array: []):
    if cue_array:
        interval_stack = [[0, len(cue_array) - 1]]
        while interval_stack:
            low, high = interval_stack.pop(0)
            if low < high:
                pivot = cue_array[high].begin_time
                swap_index = low  # subtract 1 because 1 is added later
                for search_index in range(low, high):
                    if cue_array[search_index].begin_time <= pivot:
                        # this is a cool python swapping technique
                        (cue_array[swap_index], cue_array[search_index]) = (
                        cue_array[search_index], cue_array[swap_index])
                        swap_index += 1
                (cue_array[swap_index], cue_array[high]) = (cue_array[high], cue_array[swap_index])
                interval_stack.append([low, swap_index - 1])
                interval_stack.append([swap_index + 1, high])


def find_interval_index(cue_array: [], interval: int):
    middle = 0
    if cue_array:
        upper = len(cue_array)
        lower = middle
        middle = lower + ((upper - lower) // 2)

        # binary search
        while (upper != lower and
               (cue_array[middle].begin_time < interval or cue_array[middle - 1].begin_time > interval)):
            if cue_array[middle].begin_time < interval:
                lower = middle + 1
            else:
                upper = middle - 1
            middle = lower + ((upper - lower) // 2)
    return middle

