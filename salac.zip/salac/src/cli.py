import typer
from salac import Annotation

app = typer.Typer()

# Example: python cli.py vtt2textgrid /mnt/c/zfoia/FOIA_clip/FOIA_LC2_12Z-14Z_7-24-23-clip.VTT same
@app.command()
def vtt2textgrid(src_file: str, dst_file: str):
    """Convert a VTT file to TextGrid."""
    if dst_file == "same":
        dst_file = src_file[:-3] + "TextGrid"

    raw_text = Annotation.read_file_to_text(filename=src_file)
    annotation = Annotation.from_vtt_srt_text(file_text=raw_text)
    annotation.add_silence()
    textgrid_text = annotation.to_textgrid_text()
    annotation.write_text_to_file(filename=dst_file,
                                  file_text=textgrid_text)
    typer.echo(f'Conversion saved to {dst_file}')

# Example: python cli.py textgrid2vtt /mnt/c/zfoia/FOIA_clip/FOIA_LC2_12Z-14Z_7-24-23-clip.TextGrid /mnt/c/zfoia/FOIA_clip/FOIA_LC2_12Z-14Z_7-24-23-clip-new.vtt
@app.command()
def textgrid2vtt(src_file: str, dst_file: str):
    """Convert a TextGrid file to VTT."""
    if dst_file == "same":
        dst_file = src_file[:-8] + "vtt"

    raw_text = Annotation.read_file_to_text(filename=src_file)
    annotation = Annotation.from_textgrid_text(file_text=raw_text)
    annotation.remove_silence()
    vtt_text = annotation.to_vtt_text()
    annotation.write_text_to_file(filename=dst_file,
                                  file_text=vtt_text)
    typer.echo(f'Conversion saved to {dst_file}')

# Example: python cli.py merge2vtts /mnt/c/zfoia/FOIA_clip/FOIA_LC2_12Z-14Z_7-24-23-clip.vtt /mnt/c/zfoia/FOIA_clip/FOIA_LC2_12Z-14Z_7-24-23-clip-new.vtt 120000 /mnt/c/zfoia/FOIA_clip/FOIA_LC2_12Z-14Z_7-24-23-clip-new-new.vtt
@app.command()
def merge2vtts(src_file1: str, src_file2: str, time_offset: int,
               dst_file: str):
    """Merge two VTT files into a single one with a given time_offset."""

    raw_text = Annotation.read_file_to_text(filename=src_file1)
    annotation1 = Annotation.from_vtt_srt_text(file_text=raw_text)
    raw_text = Annotation.read_file_to_text(filename=src_file2)
    annotation2 = Annotation.from_vtt_srt_text(file_text=raw_text)

    annotation1.add_annotation(annotation2, time_offset)
    vtt_text = annotation1.to_vtt_text()
    annotation1.write_text_to_file(filename=dst_file,
                                  file_text=vtt_text)

    typer.echo(f'Merge saved to {dst_file}')

if __name__ == "__main__":
    app()
