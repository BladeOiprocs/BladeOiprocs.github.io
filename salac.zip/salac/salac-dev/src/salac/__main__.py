from salac import app_cli

def main():
    app_cli.app()

if __name__ == "__main__":
    main()