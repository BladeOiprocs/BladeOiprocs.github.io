## Import from third-party library
import pytest

## Import from project library
from salac.labels import Annotation
from salac.ldc_atc0 import creat_mapping_table
from salac.labels import Cue

sample_annotation_no_silence = Annotation(
    [Cue(0,
         5160,
         ["Well, I don't wish to see it anymore, observed Phoebe.", {}]),
     Cue(5260,
         7120,
         ['It is certainly very like the old portrait.', {}])],
    False)

sample_annotation_bracket_silence = Annotation(
    [Cue(0,
         5160,
         ["Well, I don't wish to see it anymore, observed Phoebe.", {}]),
     Cue(5160,
         5260,
         ['[Silence]', {}]),
     Cue(5260,
         7120,
         ['It is certainly very like the old portrait.', {}])],
    True)

sample_annotation_empty_silence = Annotation(
    [Cue(0,
         5160,
         ["Well, I don't wish to see it anymore, observed Phoebe.", {}]),
     Cue(5160,
         5260,
         ['', {}]),
     Cue(5260,
         7120,
         ['It is certainly very like the old portrait.', {}])],
    True)

# Define contents of various files:
vtt_text = """WEBVTT

00:00.000 --> 00:05.160
Well, I don't wish to see it anymore, observed Phoebe.

00:05.260 --> 00:07.120
It is certainly very like the old portrait.

"""

srt_text = """1
00:00:00,000 --> 00:00:05,160
Well, I don't wish to see it anymore, observed Phoebe.

2
00:00:05,260 --> 00:00:07,120
It is certainly very like the old portrait.

"""

empty_sil_textgrid = """File type = "ooTextFile"
Object class = "TextGrid"

xmin = 0
xmax = 7.120
tiers? <exists>
size = 1
item []:
    item [1]:
        class = "IntervalTier"
        name = "text"
        xmin = 0
        xmax = 7.120
        intervals: size = 3
        intervals [1]:
            xmin = 0.000
            xmax = 5.160
            text = "Well, I don't wish to see it anymore, observed Phoebe."
        intervals [2]:
            xmin = 5.160
            xmax = 5.260
            text = ""
        intervals [3]:
            xmin = 5.260
            xmax = 7.120
            text = "It is certainly very like the old portrait."
"""

bracket_sil_textgrid = """File type = "ooTextFile"
Object class = "TextGrid"

xmin = 0
xmax = 7.120
tiers? <exists>
size = 1
item []:
    item [1]:
        class = "IntervalTier"
        name = "text"
        xmin = 0
        xmax = 7.120
        intervals: size = 3
        intervals [1]:
            xmin = 0.000
            xmax = 5.160
            text = "Well, I don't wish to see it anymore, observed Phoebe."
        intervals [2]:
            xmin = 5.160
            xmax = 5.260
            text = "[Silence]"
        intervals [3]:
            xmin = 5.260
            xmax = 7.120
            text = "It is certainly very like the old portrait."
"""


########################################################################
# test cases

# all these test how functions work internally
def test_vtt_import_():
    all_text = Annotation.from_vtt_srt_text(file_text=vtt_text)
    assert all_text.cues == sample_annotation_no_silence.cues


def test_textgrid_import_bracket_silence():
    all_text = Annotation.from_textgrid_text(file_text=bracket_sil_textgrid)
    assert all_text.cues == sample_annotation_bracket_silence.cues


def test_textgrid_import_empty_silence():
    all_text = Annotation.from_textgrid_text(file_text=empty_sil_textgrid)
    assert all_text.cues == sample_annotation_empty_silence.cues


def test_add_silence_():
    all_text = sample_annotation_no_silence
    all_text.add_silence()
    assert all_text.cues == sample_annotation_bracket_silence.cues


# these are actual conversion tests
def test_vtt2textgrid_():
    all_text = Annotation.from_vtt_srt_text(file_text=vtt_text)
    all_text.add_silence()
    assert all_text.to_textgrid_text() == bracket_sil_textgrid


def test_srt2textgrid_():
    all_text = Annotation.from_vtt_srt_text(file_text=srt_text)
    all_text.add_silence()
    assert all_text.to_textgrid_text() == bracket_sil_textgrid


def test_textgrid2vtt_empty_silence():
    all_text = Annotation.from_textgrid_text(file_text=empty_sil_textgrid)
    all_text.remove_silence()
    assert all_text.to_vtt_text() == vtt_text


def test_textgrid2vtt_bracket_silence():
    all_text = Annotation.from_textgrid_text(file_text=bracket_sil_textgrid)
    all_text.remove_silence()
    assert all_text.to_vtt_text() == vtt_text



ldc_atc0_text = """((TAPE-HEADER "26 JUNE 1991, 2012 TO 2212 UTC; TRANSCRIBER FR"))

((COMMENT
   "CONTAINS TWO CONTROLLER CHANGES AND SOME PILOT CHANGES"))

((FROM PAA6540) (NUM L02F1-1027)
 (TO F1-3)
 (TEXT SIXTY FIVE FORTY AH ONE NINETY OR GREATER TO AH I
   (QUOTE LL) RIPIT 1234A)
 (TIMES 12.15 15.59))

((FROM F1-3) (NUM L02F1-1028)
 (TO PAA6540)
 (TEXT CLIPPER SIXTY FIVE FORTY YOU (QUOTE LL) BE JOINING
   ABOUT THREE FROM RIPIT
   YOU CAN MAINTAIN AT OR ABOVE TWO THOUSAND NOW TIL ESTABLISHED)
 (TIMES 40.17 46.03))

"""

ldc_atc0_vtt_text = """WEBVTT

00:12.150 --> 00:15.590
sixty five forty ah one ninety or greater to ah i (quote ll) ripit 1234a

00:40.170 --> 00:46.030
clipper sixty five forty you (quote ll) be joining about three from ripit you can maintain at or above two thousand now til established

"""

processed_ldc_atc0_vtt_text = """WEBVTT

00:12.150 --> 00:15.590
sixty five forty ah one ninety or greater to ah i'll ripit <unk>

00:40.170 --> 00:46.030
clipper sixty five forty you'll be joining about three from ripit you can maintain at or above two thousand now til established

"""

ldc_atc0_stm_text = \
"""test 1 test_paa6540 12.150 15.590 sixty five forty ah one ninety or greater to ah i'll ripit <unk>
test 1 test_f1-3 40.170 46.030 clipper sixty five forty you'll be joining about three from ripit you can maintain at or above two thousand now til established
"""

def test_ldc_atc02vtt():
    all_text = Annotation.from_ldc_atc0_text(file_text=ldc_atc0_text,
                                             filename="test")
    assert all_text.to_vtt_text() == ldc_atc0_vtt_text

def test_ldc_atc02vtt_with_processing():
    compiled_mapping = creat_mapping_table()
    all_text = Annotation.from_ldc_atc0_text(
        file_text=ldc_atc0_text,
        filename="test",
        need_proc=True,
        compiled_mapping=compiled_mapping)
    assert all_text.to_vtt_text() == processed_ldc_atc0_vtt_text

def test_ldcatc2stm_():
    compiled_mapping = creat_mapping_table()
    all_text = Annotation.from_ldc_atc0_text(
        file_text=ldc_atc0_text,
        filename="test",
        need_proc=True,
        compiled_mapping=compiled_mapping)
    assert all_text.to_stm_text() == ldc_atc0_stm_text


# quick test to see if json is broken down and reconstructed properly
# we can make better tests when the object format stops changing
def test_json_conversion():
    json_text = sample_annotation_bracket_silence.to_json_text()
    all_text = Annotation.from_json_text(file_text=json_text)
    assert all_text.cues == sample_annotation_bracket_silence.cues
