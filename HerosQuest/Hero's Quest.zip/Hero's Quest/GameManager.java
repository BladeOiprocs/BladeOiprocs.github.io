import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.sun.prism.paint.Color;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Duration;

public class GameManager extends Application {
	private CombatManager combatMan = new CombatManager();
	private int gameLevel = 1;
	private int gameMap = 1;
	ConscriptionGUI conGUI = new ConscriptionGUI(gameLevel);
	UnitManager UnitManager = conGUI.getUnitManager();
	private int k = 1;
	private boolean moveOnFlag = false;
	private boolean victoryFlag = false;
	private boolean attackFlag = false;
	private boolean gameStart = false;
	private boolean playerTurn = false;
	private boolean enemyTurn = false;
	private boolean unitSelected = false;
	private boolean playerBegin = false;
	private boolean gameOn = false;
	private boolean gameOver = false;
	boolean backOne;
	private Timeline timeline, timeline2;
	private KeyFrame keyframe, keyframe2;
	private moveToken[] moveableTiles = new moveToken[400];
	private int movetileCount = 0;
	private MapGUI mapGUI = new MapGUI();
	private Pane map;
	private Button moveB, attackB, statusB, cancelB, cancelMove, cancelAttack, closeStatus, confirmMove, mountB , endTurnB;
	private Unit currentUnit;
	private Unit previousUnit;
	private Label currentLabel, currentLabelx;
	private int terrainCost;
	private int enemyNumber = 0;
	private Label jobLabel = new Label();
	private Label[] statLabel = new Label[11];
	private Label[] statNameLabel = new Label[11];
	
	public GameManager() throws IOException {
		
	}
	
	@Override
	public void start(Stage stage) throws Exception {
		stage.setScene(new Scene(conGUI.getPane(),640,640));
		stage.show();
		//create Main Character and Conscript Phase
		UnitManager.generateMC();
			conGUI.conscript(gameLevel);
			timeline = new Timeline();
			timeline.setCycleCount(Timeline.INDEFINITE);
			keyframe = new KeyFrame(Duration.millis(20), action -> {
				if (conGUI.getButtonFlag() == true) {
					conGUI.setButtonFlag(false);
					try {
						UnitManager.conscript(gameLevel);
					} catch (IOException e) {
						e.printStackTrace();
					}
					conGUI.setDisplay();
				if (conGUI.getConscriptions() == 9) {
						timeline.stop();
						stage.hide();
						gameStart = true;
					}
				}
			});
			timeline.getKeyFrames().add(keyframe);
			timeline.play();
			
			
			//Begin Map Gameplay
			timeline2 = new Timeline();
			timeline2.setCycleCount(Timeline.INDEFINITE);
			currentLabel = new Label("Selected Unit: ");
			currentLabel.setLayoutX(950);
			currentLabel.setLayoutY(50);
			currentLabelx = new Label(" ");
			currentLabelx.setLayoutX(1050);
			currentLabelx.setLayoutY(50);
			keyframe2 = new KeyFrame(Duration.millis(20), action -> {
				if (gameStart == true) {
					gameStart = false;
					playerTurn = true;
					playerBegin = true;
					gameOn = true;
					mapGUI.getMap().randomMap();
					stage.setScene(new Scene(mapGUI.getPane(),1250,850));
					stage.show();
					setupPlayer();
					initializeButtons();
					mapGUI.getPane().getChildren().add(currentLabel);
					mapGUI.getPane().getChildren().add(currentLabelx);
					try {
						UnitManager.generateEnemies((gameLevel*1 + gameMap*4 + 4), gameLevel, gameMap);
					} catch (IOException e) {
						e.printStackTrace();
					}
					setupEnemies();
				}
				if (playerBegin == true) { //Things that happen at the start of the player's turn
					turnStart();
					playerBegin = false;
				}
				if (gameOn == true) { // Things that happen during the flow of the game
					updatePlayerUnits();
					updateEnemyUnits();
				}
				if (unitSelected == true) { //displays the unit selected
					currentLabelx.setText(currentUnit.getUnitJob());
				}else{
					currentLabelx.setText("");
				}
				
				if (enemyTurn == true) { //moves and attacks with enemies on their turn
					moveEnemies();
					enemyTurn = false;
					playerBegin = true;
				}
				
				if ((moveOnFlag == true) && (gameOn == true)) { //increments the level and the map
					try {
						save();//saves the game after you complete a map, in case you want to reload
					} catch (IOException e) {
						e.printStackTrace();
					} 
					gameMap = gameMap + 1;
					if ((gameMap == 5) && (gameLevel < 4)){
						gameMap = 1;
						gameLevel = gameLevel +1;
					}else if ((gameMap == 5) && (gameLevel ==4)) {
						victoryFlag = true;
					}else {
					}
					gameStart = true;
				}
				
				if ((UnitManager.playerUnits[0].getAlive() == false) && (moveOnFlag == true)) { // gives user a game over for losing their Lord
					stage.hide();
					System.out.println("Your lord died! GAME OVER!");
					timeline.stop();
				}

			});
			timeline2.getKeyFrames().add(keyframe2);
			timeline2.play();

		
	}

	public static void main(String[] args) {
		launch(args);
	}
	
	public void setupPlayer() { //sets up the player units
		for (int j = 0; j < 3; j++) {
			for (int i = 0; i < 3; i++){
			UnitManager.playerUnits[(i*1 + j*3)].setTokenLabel();
			UnitManager.playerUnits[(i*1 + j*3)].getToken().setLayoutX((i*40) + 45);
			UnitManager.playerUnits[(i*1 + j*3)].setCurrentX((i));
			UnitManager.playerUnits[(i*1 + j*3)].getToken().setLayoutY((j*40) + 45);
			UnitManager.playerUnits[(i*1 + j*3)].setCurrentY((j));
			UnitManager.playerUnits[(i*1 + j*3)].getTokenLabel().setLayoutX((i*40) + 25);
			UnitManager.playerUnits[(i*1 + j*3)].getTokenLabel().setLayoutY((j*40) + 45);
			mapGUI.getPane().getChildren().add(UnitManager.playerUnits[(i*1 + j*3)].getToken());
			mapGUI.getPane().getChildren().add(UnitManager.playerUnits[(i*1 + j*3)].getTokenLabel());
			initializeTokens(i*1 + j*3);
			}
		}
	}
	
	public void setupEnemies() { //sets up the enemy units
		for (int k = 0; k < 9; k++) {
			int i = UnitManager.randomFrom(1,21); //random X value
			int j = 0;
			if (i < 10) {
				j = UnitManager.randomFrom(11,21); //random Y value
			}else {
				j = UnitManager.randomFrom(1,21); //random Y value
			}
			boolean enemyCheck = detectEnemyUnits(i,j);
			
			while (enemyCheck == true) { //validate that no unit already exists in said space
				i = UnitManager.randomFrom(0,21); //random X value
				j = 0;
				if (i < 10) {
					j = UnitManager.randomFrom(10,21); //random Y value
				}else {
					j = UnitManager.randomFrom(0,21); //random Y value
				}
				enemyCheck = detectEnemyUnits(i,j);
			}
			UnitManager.enemyUnits[k].setTokenLabel();
			UnitManager.enemyUnits[k].getToken().setLayoutX((i*40) + 5);
			UnitManager.enemyUnits[k].setCurrentX(i);
			UnitManager.enemyUnits[k].getToken().setLayoutY((j*40) + 5);
			UnitManager.enemyUnits[k].setCurrentY(j);
			UnitManager.enemyUnits[k].getTokenLabel().setLayoutX((i*40) - 15);
			UnitManager.enemyUnits[k].getTokenLabel().setLayoutY((j*40) + 5);
			mapGUI.getPane().getChildren().add(UnitManager.enemyUnits[k].getToken());
			mapGUI.getPane().getChildren().add(UnitManager.enemyUnits[k].getTokenLabel());
			UnitManager.enemyUnits[k].getToken().setFill(javafx.scene.paint.Color.RED);
			enemyNumber = enemyNumber + 1;
			initializeEnemyTokens(k);
		}
	}
	
	public boolean detectPlayerUnits(int x, int y) { //determines if a player has a unit in the space
		boolean unitThere = true;
		for (int i = 0; i < 9; i++) {
			int unitX = UnitManager.playerUnits[i].getCurrentX();
			int unitY = UnitManager.playerUnits[i].getCurrentY();
			if ((unitX == x) && (unitY == y)) {
				unitThere = true;
			}else {

			}
		}
		return unitThere;
	}
	
	public Unit findPlayerUnit(int x, int y) { //returns a unit in a particular place.
		Unit unitThere = new Unit();
		for (int i = 0; i < 9; i++) {
			int unitX = UnitManager.playerUnits[i].getCurrentX();
			int unitY = UnitManager.playerUnits[i].getCurrentY();
			if ((unitX == x) && (unitY == y)) {
				unitThere = UnitManager.playerUnits[i];
			}else {

			}
		}
		return unitThere;
	}
	
	public boolean detectEnemyUnits(int x, int y) { //determines if there is an enemy in a particular place
		boolean unitThere = false;
		for (int i = 0; i < enemyNumber; i++) {
			int unitX = UnitManager.enemyUnits[i].getCurrentX();
			int unitY = UnitManager.enemyUnits[i].getCurrentY();
			if ((unitX == x) && (unitY == y)) {
				unitThere = true;
			}else {
				unitThere = false;
			}
		}
		return unitThere;
	}
	
	public void initializeButtons() { //prepares all of the buttons in the GUI
		map = mapGUI.getPane();
		moveB = new Button("Move");
		attackB = new Button("Attack/Heal");
		statusB = new Button("Status");
		cancelB = new Button("Cancel");
		cancelAttack = new Button("Cancel Attack/Heal");
		cancelMove = new Button("Cancel Movement");
		confirmMove = new Button("Confirm Movement");
		closeStatus = new Button("Cancel Status");
		mountB = new Button("Mount/Dismount");
		endTurnB = new Button("End Turn");
		map.getChildren().add(moveB);
		moveB.setLayoutX(950);
		moveB.setLayoutY(250);
		map.getChildren().add(attackB);
		attackB.setLayoutX(950);
		attackB.setLayoutY(350);
		map.getChildren().add(statusB);
		statusB.setLayoutX(950);
		statusB.setLayoutY(450);
		map.getChildren().add(cancelB);
		cancelB.setLayoutX(950);
		cancelB.setLayoutY(550);
		mountB.setLayoutX(950);
		mountB.setLayoutY(650);
		cancelAttack.setLayoutX(950);
		cancelAttack.setLayoutY(550);
		cancelMove.setLayoutX(950);
		cancelMove.setLayoutY(550);
		confirmMove.setLayoutX(950);
		confirmMove.setLayoutY(650);
		closeStatus.setLayoutX(950);
		closeStatus.setLayoutY(550);
		endTurnB.setLayoutX(950);
		endTurnB.setLayoutY(750);
		map.getChildren().add(endTurnB);
		statNameLabel[2] = new Label("Current HP");
		statNameLabel[3] = new Label("Max HP");
		statNameLabel[4] = new Label("Attack");
		statNameLabel[5] = new Label("Magic Attack");
		statNameLabel[6] = new Label("Dexterity");
		statNameLabel[7] = new Label("Speed");
		statNameLabel[8] = new Label("Defense");
		statNameLabel[9] = new Label("Magic Defense");
		statNameLabel[10] = new Label("Movement");
		moveB.setOnAction(e -> { //movement button
			if ((currentUnit.getHasMove() == true) && currentUnit.getOwner().equals("Player")){
			map.getChildren().remove(moveB);
			map.getChildren().remove(attackB);
			map.getChildren().remove(statusB);
			map.getChildren().remove(cancelB);
			map.getChildren().add(cancelMove);
			map.getChildren().add(confirmMove);
			legalTiles(currentUnit);
			for (int i = 1; i < movetileCount; i++) {
				map.getChildren().add(moveableTiles[i].getToken());
			}
			}
		});
		attackB.setOnAction(e -> { //attack button
			if ((currentUnit.getHasAttack() == true) && currentUnit.getOwner().equals("Player")) {
			map.getChildren().remove(moveB);
			map.getChildren().remove(attackB);
			map.getChildren().remove(statusB);
			map.getChildren().remove(cancelB);
			map.getChildren().add(cancelAttack);
			attackFlag = true;
			}
		});
		endTurnB.setOnAction(e -> { //end turn button
			playerTurn = false;
			enemyTurn = true;
		});
		statusB.setOnAction(e -> { //status screen button
			map.getChildren().remove(moveB);
			map.getChildren().remove(attackB);
			map.getChildren().remove(statusB);
			map.getChildren().remove(cancelB);
			map.getChildren().add(closeStatus);
			map.getChildren().add(mountB);
			jobLabel = new Label(currentUnit.getUnitJob());
			jobLabel.setLayoutX(950);
			jobLabel.setLayoutY(100);
			map.getChildren().add(jobLabel);
			for (int i = 2; i < 10; i++) {
				statLabel[i] = new Label(Integer.toString(currentUnit.getUnitStats(i)));
				statLabel[i].setLayoutX(950);
				statLabel[i].setLayoutY(50*i + 50);
				statNameLabel[i].setLayoutX(1050);
				statNameLabel[i].setLayoutY(50*i + 50);
				map.getChildren().add(statLabel[i]);
				map.getChildren().add(statNameLabel[i]);
			}
		});
		mountB.setOnAction(e -> { //mounting button
			if ((currentUnit.getUnitType().equals("Flier")) || (currentUnit.getUnitType().equals("Mounted"))){
				if(currentUnit.getMounted() == false ) {
					currentUnit.mount();
				}else if (currentUnit.getMounted() == true ) {
					currentUnit.dismount();
				}else {
					
				}
			}
		});
		cancelB.setOnAction(e -> { //cancel button
			unitSelected = false;
		});
		cancelMove.setOnAction(e -> { //cancel movement button
			for (int z = 1; z < movetileCount + 1; z++) {
				if (moveableTiles[z].getMoveFlag() == true) {
					moveableTiles[z].getToken().setFill(javafx.scene.paint.Color.BLACK);
					moveableTiles[z].setMoveFlag(false);
					backOne = true;
				}
			}
			if (backOne == false) {
				map.getChildren().remove(cancelMove);
				map.getChildren().remove(confirmMove);
				map.getChildren().add(moveB);
				map.getChildren().add(attackB);
				map.getChildren().add(statusB);
				map.getChildren().add(cancelB);
				if (movetileCount > 0) {
					for (int z = 1; z < movetileCount + 1; z++) {
						map.getChildren().remove(moveableTiles[z].getToken());
					}
					movetileCount = 0;
				}else {
					backOne = false;
				}
			}
			
		});
		confirmMove.setOnAction(e -> { //confirm move button
			for (int z = 1; z < movetileCount + 1; z++) {
				if (moveableTiles[z].getMoveFlag() == true) {
					currentUnit.setCurrentX(moveableTiles[z].getPosX());
					currentUnit.setCurrentY(moveableTiles[z].getPosY());
					moveableTiles[z].setMoveFlag(false);
					currentUnit.setHasMove(false);
				}
			}
			map.getChildren().remove(cancelMove);
			map.getChildren().remove(confirmMove);
			map.getChildren().add(moveB);
			map.getChildren().add(attackB);
			map.getChildren().add(statusB);
			map.getChildren().add(cancelB);
			if (movetileCount > 0) {
				for (int z = 1; z < movetileCount + 1; z++) {
					map.getChildren().remove(moveableTiles[z].getToken());
				}
				movetileCount = 0;
			}
		});
		cancelAttack.setOnAction(e -> { //cancel attack button
			map.getChildren().remove(cancelAttack);
			map.getChildren().add(moveB);
			map.getChildren().add(attackB);
			map.getChildren().add(statusB);
			map.getChildren().add(cancelB);
			attackFlag = false;
		});
		closeStatus.setOnAction(e -> { //close status button
			map.getChildren().remove(closeStatus);
			map.getChildren().remove(jobLabel);
			for (int i = 2; i < 10; i++) {
				map.getChildren().remove(statLabel[i]);
				map.getChildren().remove(statNameLabel[i]);
			}
			map.getChildren().remove(mountB);
			map.getChildren().add(moveB);
			map.getChildren().add(attackB);
			map.getChildren().add(statusB);
			map.getChildren().add(cancelB);
		});
		}

	public void updatePlayerUnits() { //updates player units in the timeline
		for (int i = 0; i < 9; i++) {
			if ((UnitManager.playerUnits[i].getHasMove() == true) && (UnitManager.playerUnits[i].getHasAttack() == true)) {
				UnitManager.playerUnits[i].getToken().setFill(javafx.scene.paint.Color.CORNFLOWERBLUE);
			}else if ((UnitManager.playerUnits[i].getHasMove() == false) && (UnitManager.playerUnits[i].getHasAttack() == true)) {
				UnitManager.playerUnits[i].getToken().setFill(javafx.scene.paint.Color.AQUA);
			} else if ((UnitManager.playerUnits[i].getHasMove() == false) && (UnitManager.playerUnits[i].getHasAttack() == false)) {
				UnitManager.playerUnits[i].getToken().setFill(javafx.scene.paint.Color.DARKBLUE);
			} else {
				UnitManager.playerUnits[i].getToken().setFill(javafx.scene.paint.Color.WHITE);
			}
			UnitManager.playerUnits[i].getToken().setLayoutX( UnitManager.playerUnits[i].getCurrentX()*40 + 45);
			UnitManager.playerUnits[i].getToken().setLayoutY( UnitManager.playerUnits[i].getCurrentY()*40 + 45);
			UnitManager.playerUnits[i].getTokenLabel().setLayoutX( UnitManager.playerUnits[i].getCurrentX()*40 + 25);
			UnitManager.playerUnits[i].getTokenLabel().setLayoutY( UnitManager.playerUnits[i].getCurrentY()*40 + 45);
		}
		
	}
	
	public void updateEnemyUnits() {//updates enemy units in the timeline, and keeps track of how many have died
		int h = 0;
		for (int i = 0; i < enemyNumber; i++) {
			if (UnitManager.enemyUnits[i].getAlive() == false) {
				h = h+1;
			}
			if (h == enemyNumber) {
				moveOnFlag = true;
			}
			UnitManager.enemyUnits[i].getToken().setLayoutX( UnitManager.enemyUnits[i].getCurrentX()*40 + 5);
			UnitManager.enemyUnits[i].getToken().setLayoutY( UnitManager.enemyUnits[i].getCurrentY()*40 + 5);
			UnitManager.enemyUnits[i].getTokenLabel().setLayoutX( UnitManager.enemyUnits[i].getCurrentX()*40 - 25);
			UnitManager.enemyUnits[i].getTokenLabel().setLayoutY( UnitManager.enemyUnits[i].getCurrentY()*40 + 5);
		}
		
	}
	public void initializeTokens(int x) { //gets unit tokens ready for GUI
		UnitManager.playerUnits[x].getToken().setOnMouseClicked(e -> {
			try {
			previousUnit = currentUnit;
			currentUnit = UnitManager.playerUnits[x];
			if ((attackFlag == true) && (previousUnit.getUnitWeapon().equals("Stave"))) {
				combatMan.heal(previousUnit, currentUnit);
				if (previousUnit.getUnitStats(1) > 100) {
					UnitManager.levelUp(previousUnit);
					previousUnit.setUnitStat(1, previousUnit.getUnitStats(1) - 100);
				}
				attackFlag = false;
				map.getChildren().remove(cancelAttack);
				map.getChildren().add(moveB);
				map.getChildren().add(attackB);
				map.getChildren().add(statusB);
				map.getChildren().add(cancelB);
				previousUnit.setHasAttack(false);
			}else {
			}
			unitSelected = true;
			} catch (Exception f){
			f.printStackTrace();
			unitSelected = true;
			}
		});
	}
	
	public void initializeEnemyTokens(int x) { //gets enemy unit tokens ready for GUI
		UnitManager.enemyUnits[x].getToken().setOnMouseClicked(e -> {
			int distance = Math.abs(currentUnit.getCurrentX() - UnitManager.enemyUnits[x].getCurrentX()) + Math.abs(currentUnit.getCurrentY() - UnitManager.enemyUnits[x].getCurrentY());
			if ((attackFlag == true) && (currentUnit.getAttackRange() > 0) && (currentUnit.getAttackRange() < UnitManager.enemyUnits[x].getAttackRange()
					) && (distance <= currentUnit.getAttackRange())) {
				combatMan.combat(currentUnit, UnitManager.enemyUnits[x]);
				if (currentUnit.getUnitStats(1) > 100) {
					UnitManager.levelUp(currentUnit);
					currentUnit.setUnitStat(1, currentUnit.getUnitStats(1) - 100);
				}
				currentUnit.setHasAttack(false);
				unitSelected = false;
				attackFlag = false;
				currentUnit = new Unit();
				map.getChildren().remove(cancelAttack);
				map.getChildren().add(moveB);
				map.getChildren().add(attackB);
				map.getChildren().add(statusB);
				map.getChildren().add(cancelB);
			}else {
			currentUnit = UnitManager.enemyUnits[x];
			unitSelected = true;
			}
		});
	}
	
	public void turnStart() { //starts player's turn
		for (int i = 0; i < 9; i++) {
			if (UnitManager.playerUnits[i].getAlive() == true) {
				UnitManager.playerUnits[i].setHasMove(true);
				UnitManager.playerUnits[i].setHasAttack(true);
			}
		}
	}
	
	public void save() throws IOException { //saves the units values for use later
			File classData = new File("SaveData.xlsx");
			FileInputStream fis = new FileInputStream(classData);
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheetAt(0);
			
			Row row;
			Cell cell;
			CellReference cellRef;
			int unitReference = 1;
			cellRef = new CellReference("A" + unitReference);
			for (int v = 0; v < 9; v++) {
				row = sheet.getRow(cellRef.getRow());
				cell = row.getCell(cellRef.getCol());
				cell.setCellValue(UnitManager.playerUnits[v].getUnitJob());
				unitReference = unitReference +1 ;
			}
			unitReference = 1;
			cellRef = new CellReference("B" + unitReference);
			for (int v = 0; v < 9; v++) {
				row = sheet.getRow(cellRef.getRow());
				cell = row.getCell(cellRef.getCol());
				cell.setCellValue(UnitManager.playerUnits[v].getUnitStats(0));
				unitReference = unitReference +1 ;
			}
			unitReference = 1;
			for (int v = 0; v < 9; v++) {
				cellRef = new CellReference("C" + unitReference);
				row = sheet.getRow(cellRef.getRow());
				cell = row.getCell(cellRef.getCol());
				cell.setCellValue(UnitManager.playerUnits[v].getUnitStats(1));
				unitReference = unitReference +1 ;
			}
			unitReference = 1;
			for (int v = 0; v < 9; v++) {
				cellRef = new CellReference("D" + unitReference);
				row = sheet.getRow(cellRef.getRow());
				cell = row.getCell(cellRef.getCol());
				cell.setCellValue(UnitManager.playerUnits[v].getUnitStats(2));
				unitReference = unitReference +1 ;
			}
			unitReference = 1;
			for (int v = 0; v < 9; v++) {
				cellRef = new CellReference("E" + unitReference);
				row = sheet.getRow(cellRef.getRow());
				cell = row.getCell(cellRef.getCol());
				cell.setCellValue(UnitManager.playerUnits[v].getUnitStats(3));
				unitReference = unitReference +1 ;
			}
			unitReference = 1;
			for (int v = 0; v < 9; v++) {
				cellRef = new CellReference("F" + unitReference);
				row = sheet.getRow(cellRef.getRow());
				cell = row.getCell(cellRef.getCol());
				cell.setCellValue(UnitManager.playerUnits[v].getUnitStats(4));
				unitReference = unitReference +1 ;
			}
			unitReference = 1;
			for (int v = 0; v < 9; v++) {
				cellRef = new CellReference("G" + unitReference);
				row = sheet.getRow(cellRef.getRow());
				cell = row.getCell(cellRef.getCol());
				cell.setCellValue(UnitManager.playerUnits[v].getUnitStats(5));
				unitReference = unitReference +1 ;
			}
			unitReference = 1;
			for (int v = 0; v < 9; v++) {
				cellRef = new CellReference("H" + unitReference);
				row = sheet.getRow(cellRef.getRow());
				cell = row.getCell(cellRef.getCol());
				cell.setCellValue(UnitManager.playerUnits[v].getUnitStats(6));
				unitReference = unitReference +1 ;
			}
			unitReference = 1;
			for (int v = 0; v < 9; v++) {
				cellRef = new CellReference("I" + unitReference);
				row = sheet.getRow(cellRef.getRow());
				cell = row.getCell(cellRef.getCol());
				cell.setCellValue(UnitManager.playerUnits[v].getUnitStats(7));
				unitReference = unitReference +1 ;
			}
			unitReference = 1;
			for (int v = 0; v < 9; v++) {
				cellRef = new CellReference("J" + unitReference);
				row = sheet.getRow(cellRef.getRow());
				cell = row.getCell(cellRef.getCol());
				cell.setCellValue(UnitManager.playerUnits[v].getUnitStats(8));
				unitReference = unitReference +1 ;
			}
			unitReference = 1;
			for (int v = 0; v < 9; v++) {
				cellRef = new CellReference("K" + unitReference);
				row = sheet.getRow(cellRef.getRow());
				cell = row.getCell(cellRef.getCol());
				cell.setCellValue(UnitManager.playerUnits[v].getUnitStats(9));
				unitReference = unitReference +1 ;
			}
			unitReference = 1;
			for (int v = 0; v < 9; v++) {
				cellRef = new CellReference("L" + unitReference);
				row = sheet.getRow(cellRef.getRow());
				cell = row.getCell(cellRef.getCol());
				cell.setCellValue(UnitManager.playerUnits[v].getUnitStats(10));
				unitReference = unitReference +1 ;
			}
			unitReference = 1;
			cellRef = new CellReference("M" + unitReference);
			row = sheet.getRow(cellRef.getRow());
			cell = row.getCell(cellRef.getCol());
			cell.setCellValue(gameLevel);
			unitReference = unitReference +1 ;
			cell.setCellValue(gameMap);
	}
	
	
	public void legalTiles(Unit thisUnit) { //determines the legal tiles a unit can move on
		for (int i = 0; i < 20; i++) {
			for (int j = 0; j < 20; j++) {
				boolean playerUnit = detectPlayerUnits(i,j);
				boolean enemyUnit = detectEnemyUnits(i,j);
				if ((playerUnit == false) && (enemyUnit == false));{
					terrainCost = 0;
					if ((thisUnit.getCurrentX() > i) && (thisUnit.getCurrentY() > j)) { // Reference is to the up left of unit
						for (int y = j; y < thisUnit.getCurrentY(); y++) {
							if ((thisUnit.getUnitType().equals("Mounted")) && (mapGUI.getMap().gameMap[i][y].tileName.equals("Forest"))) {
								terrainCost = terrainCost + 3;
							} else if (thisUnit.getUnitType().equals("Flier")) {
								terrainCost = terrainCost + 1;
							} else {
								terrainCost = terrainCost + mapGUI.getMap().gameMap[i][y].moveCost;
							}
						} 	
						for (int x = i; x < thisUnit.getCurrentX(); x++) {
							if ((thisUnit.getUnitType().equals("Mounted")) && (mapGUI.getMap().gameMap[x][j].tileName.equals("Forest"))) {
								terrainCost = terrainCost + 3;
							} else if (thisUnit.getUnitType().equals("Flier")) {
								terrainCost = terrainCost + 1;
							} else {
								terrainCost = terrainCost + mapGUI.getMap().gameMap[x][j].moveCost;
							}
						}
						if (terrainCost <= thisUnit.getUnitStats(10)) {
							movetileCount = movetileCount + 1;
							moveableTiles[movetileCount] = new moveToken();
							moveableTiles[movetileCount].getToken().setLayoutX(i*40 + 45);
							moveableTiles[movetileCount].getToken().setLayoutY(j*40 + 45);
							moveableTiles[movetileCount].setPosX(i);
							moveableTiles[movetileCount].setPosY(j);
							
						}
					}else if ((thisUnit.getCurrentX() < i) && (thisUnit.getCurrentY() > j)) { // Reference is to the up right of unit
						for (int y = j; y < thisUnit.getCurrentY(); y++) {
							if ((thisUnit.getUnitType().equals("Mounted")) && (mapGUI.getMap().gameMap[i][y].tileName.equals("Forest"))) {
								terrainCost = terrainCost + 3;
							} else if (thisUnit.getUnitType().equals("Flier")){
								terrainCost = terrainCost + 1;
							} else {
								terrainCost = terrainCost + mapGUI.getMap().gameMap[i][y].moveCost;
							}
						} 
						for (int x = thisUnit.getCurrentX(); x < i; x++) {
							if ((thisUnit.getUnitType().equals("Mounted")) && (mapGUI.getMap().gameMap[x][j].tileName.equals("Forest"))) {
								terrainCost = terrainCost + 3;
							} else if (thisUnit.getUnitType().equals("Flier")) {
								terrainCost = terrainCost + 1;
							} else {
								terrainCost = terrainCost + mapGUI.getMap().gameMap[x][j].moveCost;
							}
						}
						if (terrainCost <= thisUnit.getUnitStats(10)) {
							movetileCount = movetileCount + 1;
							moveableTiles[movetileCount] = new moveToken();
							moveableTiles[movetileCount].getToken().setLayoutX(i*40 + 45);
							moveableTiles[movetileCount].getToken().setLayoutY(j*40 + 45);
							moveableTiles[movetileCount].setPosX(i);
							moveableTiles[movetileCount].setPosY(j);
						
						}
					}else if ((thisUnit.getCurrentX() < i) && (thisUnit.getCurrentY() < j)) { //Reference is to the down Right of unit
						for (int y = thisUnit.getCurrentY(); y < j; y++) {
							if ((thisUnit.getUnitType().equals("Mounted")) && (mapGUI.getMap().gameMap[i][y].tileName.equals("Forest"))) {
								terrainCost = terrainCost + 3;
							} else if (thisUnit.getUnitType().equals("Flier")){
								terrainCost = terrainCost + 1;
							} else {
								terrainCost = terrainCost + mapGUI.getMap().gameMap[i][y].moveCost;
							}
						}
						for (int x = thisUnit.getCurrentX(); x < i; x++) {
							if ((thisUnit.getUnitType().equals("Mounted")) && (mapGUI.getMap().gameMap[x][j].tileName.equals("Forest"))) {
								terrainCost = terrainCost + 3;
							} else if (thisUnit.getUnitType().equals("Flier")) {
								terrainCost = terrainCost + 1;
							} else {
								terrainCost = terrainCost + mapGUI.getMap().gameMap[x][j].moveCost;
							}
						}
						if (terrainCost <= thisUnit.getUnitStats(10)) {
							movetileCount = movetileCount + 1;
							moveableTiles[movetileCount] = new moveToken();
							moveableTiles[movetileCount].getToken().setLayoutX(i*40 + 45);
							moveableTiles[movetileCount].getToken().setLayoutY(j*40 + 45);
							moveableTiles[movetileCount].setPosX(i);
							moveableTiles[movetileCount].setPosY(j);
							
						}
					}else if ((thisUnit.getCurrentX() > i) && (thisUnit.getCurrentY() < j)) { // reference is to the down left of unit
						for (int y = thisUnit.getCurrentY(); y < j; y++) {
							if ((thisUnit.getUnitType().equals("Mounted")) && (mapGUI.getMap().gameMap[i][y].tileName.equals("Forest"))) {
								terrainCost = terrainCost + 3;
							} else if (thisUnit.getUnitType().equals("Flier")) {
								terrainCost = terrainCost + 1;
							} else {
								terrainCost = terrainCost + mapGUI.getMap().gameMap[i][y].moveCost;
							}
						}
						for (int x = i; x < thisUnit.getCurrentX(); x++) {
							if ((thisUnit.getUnitType().equals("Mounted")) && (mapGUI.getMap().gameMap[x][j].tileName.equals("Forest"))) {
								terrainCost = terrainCost + 3;
							} else if (thisUnit.getUnitType().equals("Flier")) {
								terrainCost = terrainCost + 1;
							} else {
								terrainCost = terrainCost + mapGUI.getMap().gameMap[x][j].moveCost;
							}
						}
						if (terrainCost <= thisUnit.getUnitStats(10)) {
							movetileCount = movetileCount + 1;
							moveableTiles[movetileCount] = new moveToken();
							moveableTiles[movetileCount].getToken().setLayoutX(i*40 + 45);
							moveableTiles[movetileCount].getToken().setLayoutY(j*40 + 45);
							moveableTiles[movetileCount].setPosX(i);
							moveableTiles[movetileCount].setPosY(j);
						
						}
					}else if ((thisUnit.getCurrentX() == i) && (thisUnit.getCurrentY() < j)) { // reference is directly below unit
						for (int y = thisUnit.getCurrentY(); y < j; y++) {
							if ((thisUnit.getUnitType().equals("Mounted")) && (mapGUI.getMap().gameMap[i][y].tileName.equals("Forest"))){
								terrainCost = terrainCost + 3;
							} else if (thisUnit.getUnitType().equals("Flier")) {
								terrainCost = terrainCost + 1;
							} else {
								terrainCost = terrainCost + mapGUI.getMap().gameMap[i][y].moveCost;
							}
						}
						
						if (terrainCost <= thisUnit.getUnitStats(10)) {
							movetileCount = movetileCount + 1;
							moveableTiles[movetileCount] = new moveToken();
							moveableTiles[movetileCount].getToken().setLayoutX(i*40 + 45);
							moveableTiles[movetileCount].getToken().setLayoutY(j*40 + 45);
							moveableTiles[movetileCount].setPosX(i);
							moveableTiles[movetileCount].setPosY(j);
							
						}
					}else if ((thisUnit.getCurrentX() == i) && (thisUnit.getCurrentY() > j)) { //reference is directly above unit
						for (int y = j; y < thisUnit.getCurrentY(); y++) {
							if ((thisUnit.getUnitType().equals("Mounted")) && (mapGUI.getMap().gameMap[i][y].tileName.equals("Forest"))) {
								terrainCost = terrainCost + 3;
							} else if (thisUnit.getUnitType().equals("Flier")) {
								terrainCost = terrainCost + 1;
							} else {
								terrainCost = terrainCost + mapGUI.getMap().gameMap[i][y].moveCost;
							}
					} 
					if (terrainCost <= thisUnit.getUnitStats(10)) {
						movetileCount = movetileCount + 1;
						moveableTiles[movetileCount] = new moveToken();
						moveableTiles[movetileCount].getToken().setLayoutX(i*40 + 45);
						moveableTiles[movetileCount].getToken().setLayoutY(j*40 + 45);
						moveableTiles[movetileCount].setPosX(i);
						moveableTiles[movetileCount].setPosY(j);
						
					}
					}else if ((thisUnit.getCurrentX() > i) && (thisUnit.getCurrentY() == j)) { //reference is to the left of unit
						for (int x = i; x < thisUnit.getCurrentX(); x++) {
								if ((thisUnit.getUnitType().equals("Mounted")) && (mapGUI.getMap().gameMap[x][j].tileName.equals("Forest"))) {
									terrainCost = terrainCost + 3;
								} else if (thisUnit.getUnitType().equals("Flier")) {
									terrainCost = terrainCost + 1;
								} else {
									terrainCost = terrainCost + mapGUI.getMap().gameMap[x][j].moveCost;
								}
						}
						if (terrainCost <= thisUnit.getUnitStats(10)) {
							movetileCount = movetileCount + 1;
							moveableTiles[movetileCount] = new moveToken();
							moveableTiles[movetileCount].getToken().setLayoutX(i*40 + 45);
							moveableTiles[movetileCount].getToken().setLayoutY(j*40 + 45);
							moveableTiles[movetileCount].setPosX(i);
							moveableTiles[movetileCount].setPosY(j);
						
						}
					}else if ((thisUnit.getCurrentX() < i) && (thisUnit.getCurrentY() == j)) { //reference is to the right of unit
						for (int x = thisUnit.getCurrentX(); x < i; x++) {
							if ((thisUnit.getUnitType().equals("Mounted")) && (mapGUI.getMap().gameMap[x][j].tileName.equals("Forest"))) {
								terrainCost = terrainCost + 3;
							} else if (thisUnit.getUnitType().equals("Flier")) {
								terrainCost = terrainCost + 1;
							} else {
								terrainCost = terrainCost + mapGUI.getMap().gameMap[x][j].moveCost;
							}
						}
						if (terrainCost <= thisUnit.getUnitStats(10)) {
							movetileCount = movetileCount + 1;
							moveableTiles[movetileCount] = new moveToken();
							moveableTiles[movetileCount].getToken().setLayoutX(i*40 + 45);
							moveableTiles[movetileCount].getToken().setLayoutY(j*40 + 45);
							moveableTiles[movetileCount].setPosX(i);
							moveableTiles[movetileCount].setPosY(j);
							
						}
					} else { // reference is on unit
						movetileCount = movetileCount + 1;
						moveableTiles[movetileCount] = new moveToken();
						moveableTiles[movetileCount].getToken().setLayoutX(i*40 + 45);
						moveableTiles[movetileCount].getToken().setLayoutY(j*40 + 45);
						moveableTiles[movetileCount].setPosX(i);
						moveableTiles[movetileCount].setPosY(j);
						
					}
				}
			}
		}
	}
	
	public void moveEnemies() { //moves enemies. The section in comments is having them attack units on their own. It does not work properly
		for (int q = 0; q < enemyNumber; q++) {
			if (UnitManager.enemyUnits[q].getAlive() == true) {
				legalTiles(UnitManager.enemyUnits[q]);
				 int moveRef = UnitManager.randomFrom(1,movetileCount+1);
				 UnitManager.enemyUnits[q].setCurrentX(moveableTiles[moveRef].getPosX());
				 UnitManager.enemyUnits[q].setCurrentY(moveableTiles[moveRef].getPosY());
				// if (detectPlayerUnits(UnitManager.enemyUnits[q].getCurrentX()+1,UnitManager.enemyUnits[q].getCurrentY()) == true){
					// Unit defender = findPlayerUnit(UnitManager.enemyUnits[q].getCurrentX()+1,UnitManager.enemyUnits[q].getCurrentY());
					 //combatMan.combat(UnitManager.enemyUnits[q], defender);
				 //} else if (detectPlayerUnits(UnitManager.enemyUnits[q].getCurrentX()-1,UnitManager.enemyUnits[q].getCurrentY()) == true){
					// Unit defender = findPlayerUnit(UnitManager.enemyUnits[q].getCurrentX()-1,UnitManager.enemyUnits[q].getCurrentY());
					 //combatMan.combat(UnitManager.enemyUnits[q], defender);
				 //} else if (detectPlayerUnits(UnitManager.enemyUnits[q].getCurrentX(),UnitManager.enemyUnits[q].getCurrentY()+1) == true){
					// Unit defender = findPlayerUnit(UnitManager.enemyUnits[q].getCurrentX(),UnitManager.enemyUnits[q].getCurrentY()+1);
					// combatMan.combat(UnitManager.enemyUnits[q], defender);
				// } else if (detectPlayerUnits(UnitManager.enemyUnits[q].getCurrentX(),UnitManager.enemyUnits[q].getCurrentY()-1) == true){
					// Unit defender = findPlayerUnit(UnitManager.enemyUnits[q].getCurrentX(),UnitManager.enemyUnits[q].getCurrentY()-1);
				//	 combatMan.combat(UnitManager.enemyUnits[q], defender);
				// } else {
					 
				// }
		//} else {
				
			}
		}
	}

	
	
}
			