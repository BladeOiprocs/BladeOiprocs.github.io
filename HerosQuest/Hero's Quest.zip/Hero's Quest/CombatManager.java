import javafx.scene.layout.Pane;

public class CombatManager extends Pane{
	
	private Pane pane = new Pane();
	private int attdmg, defdmg;
	
	public CombatManager() {
		
	}
	
	public int randomFrom (int low, int high) {
		int randNum = 0;

		// (int) is casting since Math.random() return a double and randNum is an int
		randNum = (int) (Math.random()*(high-low) + low);

		return randNum;
	}
	
	public void combat(Unit attacker, Unit defender){
		//first determine type and amount of damage dealt
		if ((attacker.getUnitWeapon().equals("Elemental")) || (attacker.getUnitWeapon().equals("Dark")) || (attacker.getUnitWeapon().equals("Light"))) {
			attdmg = attacker.getUnitStats(5) - defender.getUnitStats(9);
		}else {
			attdmg = attacker.getUnitStats(4) - defender.getUnitStats(8);
		}
		if ((defender.getUnitWeapon().equals("Elemental")) || (defender.getUnitWeapon().equals("Dark")) || (defender.getUnitWeapon().equals("Light"))) {
			defdmg = defender.getUnitStats(5) - attacker.getUnitStats(9);
		}else {
			defdmg = defender.getUnitStats(4) - attacker.getUnitStats(8);
		}
		
		//min 1 damage
		if(attdmg < 1) {
			attdmg = 1;
		}
		if(defdmg < 1) {
			defdmg = 1;
		}
		
		//combat sequence
		int hitRate = randomFrom(0,101);
		System.out.println(attacker.getUnitJob() + " attacks!");
		if (hitRate < (80 + attacker.getUnitStats(6)*4) - defender.getUnitStats(7)*2) {
			defender.setUnitStat(2, defender.getUnitStats(2) - attdmg);
			System.out.println(defender.getUnitJob() + " took " + attdmg + " damage!");
			if (defender.getUnitStats(2) < 0) {
				defender.setAlive(false);
			}
		} else {
			System.out.println(attacker.getUnitJob() + " missed!");
		}
		if (defender.getAlive() && attacker.getAlive()) {
			hitRate = randomFrom(0,101);
			System.out.println(defender.getUnitJob() + " counters!");
			if (hitRate < (80 + defender.getUnitStats(6)*4) - attacker.getUnitStats(7)*2) {
				attacker.setUnitStat(2, attacker.getUnitStats(2) - defdmg);
				System.out.println(attacker.getUnitJob() + " took " + defdmg + " damage!");
				if (attacker.getUnitStats(2) < 0) {
					attacker.setAlive(false);
				}
			} else {
				System.out.println(defender.getUnitJob() + " missed!");
			}
		}
		if (attacker.getUnitStats(7) > defender.getUnitStats(7)) {
			if (defender.getAlive() && attacker.getAlive()) {
			hitRate = randomFrom(0,101);
			System.out.println(attacker.getUnitJob() + " finishes!");
			if (hitRate < (80 + attacker.getUnitStats(6)*4) - defender.getUnitStats(7)*2) {
				defender.setUnitStat(2, defender.getUnitStats(2) - attdmg);
				System.out.println(defender.getUnitJob() + " took " + attdmg + " damage!");
				if (defender.getUnitStats(2) < 0) {
					defender.setAlive(false);
				}
			} else {
				System.out.println(attacker.getUnitJob() + " missed!");
			}
		}else if(attacker.getUnitStats(7) < defender.getUnitStats(7)) {
			if (defender.getAlive() && attacker.getAlive()) {
				hitRate = randomFrom(0,101);
				System.out.println(defender.getUnitJob() + " finishes!");
				if (hitRate < (80 + defender.getUnitStats(6)*4) - attacker.getUnitStats(7)*2) {
					attacker.setUnitStat(2, attacker.getUnitStats(2) - defdmg);
					System.out.println(attacker.getUnitJob() + " took " + defdmg + " damage!");
					if (attacker.getUnitStats(2) < 0) {
						attacker.setAlive(false);
					}
				} else {
					System.out.println(defender.getUnitJob() + " missed!");
				}
			}
		}
		}
		
		//give exp/kill units that lost
		if ((defender.getAlive() == false) && (attacker.getOwner().equals("Enemy"))) {
			defender.kill();
		} else if ((attacker.getAlive() == false) && (defender.getOwner().equals("Enemy"))) {
			attacker.kill();
		}
		
		if ((defender.getAlive() == false) && (attacker.getOwner().equals("Player"))) {
			attacker.setUnitStat(1, attacker.getUnitStats(1) + (30 + 5*(attacker.getUnitStats(0)-defender.getUnitStats(0))));
			defender.kill();
		} else if ((attacker.getAlive() == false) && (defender.getOwner().equals("Player"))) {
			defender.setUnitStat(1, defender.getUnitStats(1) + (30 + 5*(defender.getUnitStats(0)-attacker.getUnitStats(0))));
			attacker.kill();
		}
	}
	
	//healing function
	public void heal(Unit healer, Unit ally){
		ally.setUnitStat(2, ally.getUnitStats(2)+healer.getUnitStats(5)+5);
		System.out.println(ally.getUnitJob() + " has been healed!");
		if (ally.getUnitStats(2) > ally.getUnitStats(3)) {
			ally.setUnitStat(2, ally.getUnitStats(3));
		}
		healer.setUnitStat(1, healer.getUnitStats(1) + 30);
	}
	
}