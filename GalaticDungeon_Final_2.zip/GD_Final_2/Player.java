//data representation of player
public class Player extends Characters{
  private int direction; // 1 = Up, 2 = Right, 3 = Down, 4 = Left
  private int type = 1;
  //constructor
  public Player() {
    setX(3);
    setY(3);
    setHealth(10);
    setDirection(1);
  }

public int getDirection() {
	return direction;
}

public void setDirection(int direction) {
	this.direction = direction;
}

public int getType() {
	return type;
}

public void setType(int type) {
	this.type = type;
}
  
}
