public class Map {
	
	public Terrain[][] gameMap = new Terrain[20][20];
	
	public int randomFrom (int low, int high) {

		int randNum = 0;

		// (int) is casting since Math.random() return a double and randNum is an int
		randNum = (int) (Math.random()*(high-low) + low);

		return randNum;
	}
	
	public Map() { //conscructor. creates a random map. Decided that the random map displays the movement effectiveness well enough.
			for (int i = 0; i < 20; i++) {
				for (int j = 0; j < 20; j++) {
					gameMap[i][j] = new Terrain(randomFrom(0,7));
					gameMap[i][j].setTileX(i);
					gameMap[i][j].setTileY(j);
				}
			}
	}
	
	public void randomMap() {
		for (int i = 0; i < 20; i++) {
			for (int j = 0; j < 20; j++) {
				gameMap[i][j] = new Terrain(randomFrom(0,7));
				gameMap[i][j].setTileX(i);
				gameMap[i][j].setTileY(j);
			}
		}
	}
	
	public void generateMap() {
	
		
	}
}