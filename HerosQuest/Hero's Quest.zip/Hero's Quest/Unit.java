import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;

public class Unit {
	
	private String unitJob;
	private int[] unitStats = new int[12];
	private int[] unitGrowths = new int[12];
	private boolean hasMove;
	private boolean hasAttack;
	private Item[] inventory = new Item[5];
	private Circle token;
	private Label tokenLabel;// = new Label(unitJob);
	private MapGUI mapGUI;
	private Pane map;
	private int currentX;
	private int currentY;
	private boolean isAlive;
	private boolean isPlayer;
	private boolean isPromoted;
	private String weaponType1, weaponType2;
	private String unitType;
	private int AttackRange;
	private String UnitWeapon;
	private String owner;
	private boolean mounted = false;
	public Unit() {
		 token = new Circle(15);
		 unitJob = "";
	}
	
	public void kill() { //kills the unit
		setAlive(false);
		setCurrentX(1000);
		setCurrentY(1000);
	}

	public void move() {
		
	}
	
	public void attack() {
		
	}
	
	public void use() {
		
	}
	
	public void setUnitMove(boolean value) {
		setHasMove(value);
	}
	
	public void setUnitStat(int statPlace, int value) {
		unitStats[statPlace] = value;
	}
	
	public void setUnitGrowth(int statPlace, int value) {
		unitGrowths[statPlace] = value;
	}
	
	public void setUnitJob(String value) {
		unitJob = value;
	}
	
	
	public boolean setUnitMove() {
		return getHasMove();
	}
	
	public String getUnitJob() {
		return unitJob;
	}
	
	public int getUnitStats(int i) {
		return unitStats[i];
	}
	
	public int getUnitGrowths(int i) {
		return unitStats[i];
	}
	

	public Circle getToken() {
		return token;
	}

	public void setToken(Circle token) {
		this.token = token;
	}

	public Label getTokenLabel() {
		return tokenLabel;
	}

	public void setTokenLabel() {
		tokenLabel = new Label(unitJob);
	}


	public int getCurrentX() {
		return currentX;
	}


	public void setCurrentX(int currentX) {
		this.currentX = currentX;
	}


	public int getCurrentY() {
		return currentY;
	}


	public void setCurrentY(int currentY) {
		this.currentY = currentY;
	}


	public boolean getAlive() {
		return isAlive;
	}


	public void setAlive(boolean isAlive) {
		this.isAlive = isAlive;
	}


	public String getUnitType() {
		return unitType;
	}


	public void setUnitType(String unitType) {
		this.unitType = unitType;
	}


	public boolean getHasMove() {
		return hasMove;
	}


	public void setHasMove(boolean hasMove) {
		this.hasMove = hasMove;
	}


	public boolean getHasAttack() {
		return hasAttack;
	}


	public void setHasAttack(boolean hasAttack) {
		this.hasAttack = hasAttack;
	}


	public int getAttackRange() {
		return AttackRange;
	}


	public void setAttackRange(int range) {
		AttackRange = range;
	}


	public String getUnitWeapon() {
		return UnitWeapon;
	}


	public void setUnitWeapon(String unitWeapon) {
		UnitWeapon = unitWeapon;
	}


	public String getOwner() {
		return owner;
	}


	public void setOwner(String owner) {
		this.owner = owner;
	}

	public boolean getMounted() {
		return mounted;
	}

	public void setMounted(boolean mounted) {
		this.mounted = mounted;
	}

	public void mount() {
		
	}
	
	public void dismount() {
		
	}


}