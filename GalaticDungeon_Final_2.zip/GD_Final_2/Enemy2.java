public class Enemy2 extends Enemy{
	private int range = 7;
	public Enemy2() {
		  setX(100);
		  setY(100);
		  setHealth(12);
		  alive = false;
	}
	public void enemyAILoop(Player player1, Player player2, char[][] matrix) {
	  	Player target = player1;
	  	//projectile attack;
		switch (currentState) {
			case STATE0: //neutral state
				//new distance checking- first determines which is closest
				if (getDistance(player1) < getDistance(player2)) {
					target = player1;
				} else {
					target = player2;
				}
				//now checks for range
				if (getDistance(target) <= range) {
					//transition to state 1
					currentState = states.STATE1;
				} else {
					currentState = states.STATE0;
				}
				break;
			case STATE1: //ready to move
				//new transition code
				//compares absolute value of distance to target horizontally and vertically, selects closest
				if (Math.abs(getX()-target.getX()) < Math.abs(getY()-target.getY())) {
					if (target.getX() <= range) {
						//transition to state 4
						currentState = states.STATE4;
					} else {
						currentState = states.STATE0;
					}
				} else {
					if (target.getY() <= range) {
						//transition to state 5
						currentState = states.STATE5;
					} else {
						currentState = states.STATE0;
					}
				}
				break;
			case STATE2: //ready to fire
				if (((target.getX() == getX()) && (target.getY() == getY()))) { //check if same tile as player
					//transition to state 3
					currentState = states.STATE3;
				} else {
					currentState = states.STATE1;
				}
				break;
			case STATE3: //fire beam
				//actually fire the beam
				target.setHealth(getHealth()-2);
				//check if target is still in same column or row
				currentState = states.STATE1;
				break;
			case STATE4: //move one column closer
				//check which direction to move
				//origin should be at top left corner, so - movement is left and + is right
				if (getX() - target.getX() < 0) {
					if(matrix[getX()+1][getY()] == 'P') {
						setX(getX() + 1);
					}
				} else {
					if(matrix[getX()-1][getY()] == 'P') {
					setX(getX() - 1);
					}
				}
					currentState = states.STATE2;

				break;
			case STATE5: //move one row closer
				//check which direction to move
				//origin should be at top left corner, so - movement is up and + is down
				if (getY()-target.getY() < 0) {
					if(matrix[getX()][getY()+1] == 'P') {
						setY(getY() + 1);
					}
				} else {
					if(matrix[getX()][getY()-1] == 'P') {
						setY(getY() - 1);
					}
				}

					currentState = states.STATE2;

				break;
		}
  }
}

