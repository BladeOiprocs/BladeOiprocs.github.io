public class Mounted extends Unit {

	private boolean crossWater = false;
	private boolean crossMount = false;
	private boolean mounted = true;
	
	public Mounted() {
		super();
		
	}
	
	public void dismount() {
		setUnitStat(7, getUnitStats(7) + 2); //Speed  + 2
		setUnitStat(10, getUnitStats(10) - 2);// Movement - 2
		mounted = false;
	}
	
	public void mount() {
		setUnitStat(7, getUnitStats(7) - 2); //Speed  - 2
		setUnitStat(10, getUnitStats(10) + 2);// Movement + 2
		mounted = true;
	}
}