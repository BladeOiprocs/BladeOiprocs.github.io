public class puzzleLevels {

	int chooseBox;
	int count = 0;
	int x1 = 0; 
	int y1 = 0;
	private char[][] lvlMatrix = new char[22][22];
	
	puzzleLevels(char[][] matrix){
		lvlMatrix = matrix;
		puzzle();
	}
	
	
	public char[][] puzzle() {
		
		for(int i = 0; i < 22; i++) {
			for(int j = 0; j < 22; j++) {
				lvlMatrix[i][j] = 'P';
        		if((i == 0) || (j == 0)) {
        			lvlMatrix[i][j] = 'U';
        		}
        		if((i == 21) || (j == 21)) {
        			lvlMatrix[i][j] = 'U';
        		}
			}
		}

		char [][] puzzle1 =
				{
					{'P','P','P','W','W'},
					{'P','P','W','W','P'},
					{'W','P','W','P','W'},
					{'W','P','P','P','W'},
					{'W','W','P','W','W'}
				};
		char [][] puzzle2 =
				{
					{'W','W','P','W','W'},
					{'P','P','P','P','P'},
					{'W','P','W','P','W'},
					{'P','P','W','P','P'},
					{'P','W','W','W','P'}
				};
		char [][] puzzle3 =
				{
					{'W','W','W','P','P'},
					{'W','P','P','W','P'},
					{'P','P','P','P','P'},
					{'P','W','W','P','W'},
					{'W','W','W','P','W'}
				};
		char [][] puzzle4 =
				{
					{'W','W','W','W','P'},
					{'P','P','P','W','P'},
					{'W','W','P','W','P'},
					{'W','P','P','P','P'},
					{'W','P','W','W','W'}
				};
		char [][] puzzle5 =
				{
					{'W','W','P','W','P'},
					{'W','W','P','W','W'},
					{'W','P','P','P','P'},
					{'P','P','P','P','W'},
					{'W','W','P','W','W'}
				};
		char [][] puzzle6 =
				{
					{'P','W','P','W','P'},
					{'P','W','P','W','P'},
					{'P','W','P','W','P'},
					{'P','W','P','W','P'},
					{'P','W','P','W','P'}
				};
		char [][] puzzle7 =
				{
					{'W','W','W','P','W'},
					{'W','W','W','P','P'},
					{'P','P','W','P','P'},
					{'W','P','P','P','W'},
					{'W','W','W','P','P'}
				};
		char [][] puzzle8 =
				{
					{'W','P','W','W','W'},
					{'P','P','P','W','W'},
					{'W','W','P','P','P'},
					{'W','W','W','P','W'},
					{'W','W','P','P','W'}
				};
		char [][] puzzle9 =
				{
					{'W','P','W','P','W'},
					{'W','P','W','P','W'},
					{'W','P','W','P','W'},
					{'W','P','W','P','W'},
					{'W','P','W','P','W'}
				};
		char [][] puzzle10 =
				{
					{'W','P','W','P','W'},
					{'W','P','W','P','W'},
					{'W','P','W','P','W'},
					{'W','P','W','P','W'},
					{'W','P','W','P','W'}
				};
		char [][] puzzle11 =
				{
					{'W','P','P','P','W'},
					{'W','W','W','W','W'},
					{'P','P','W','P','P'},
					{'W','W','W','W','W'},
					{'W','P','P','P','W'}
				};
		char [][] puzzle12 =
				{
					{'W','W','W','W','W'},
					{'W','P','P','P','W'},
					{'W','P','P','P','W'},
					{'W','P','P','P','W'},
					{'W','W','W','W','W'}
				};
		char [][] puzzle13 =
				{
					{'W','W','P','W','W'},
					{'W','W','P','P','P'},
					{'W','W','P','W','W'},
					{'P','P','P','P','P'},
					{'P','W','W','W','W'}
				};
		char [][] puzzle14 =
				{
					{'P','W','P','P','P'},
					{'P','P','P','W','W'},
					{'W','P','W','P','P'},
					{'W','P','W','P','W'},
					{'W','P','P','P','W'}
				};
		char [][] puzzle15 =
				{
					{'W','W','W','W','P'},
					{'W','W','W','P','P'},
					{'W','W','W','W','P'},
					{'P','P','P','P','P'},
					{'P','W','W','W','P'}
				};
		char [][] puzzle16 =
				{
					{'P','P','P','P','P'},
					{'P','W','W','W','P'},
					{'P','W','W','W','P'},
					{'P','W','W','W','P'},
					{'P','P','P','P','P'}
				};

			for(int k = 0; k < 4; k++) {
				for(int j = 0; j < 4; j++) {
				chooseBox = (int)(Math.random()*((15-1)+1)+1);
				char[][] viewPuzzle;
				if (chooseBox == 1) {
					viewPuzzle = puzzle1;
				}else if (chooseBox == 2){
					viewPuzzle = puzzle2;
				}else if (chooseBox == 3){
					viewPuzzle = puzzle3;
				}else if (chooseBox == 4){
					viewPuzzle = puzzle4;
				}else if (chooseBox == 5){
					viewPuzzle = puzzle5;
				}else if (chooseBox == 6){
					viewPuzzle = puzzle6;
				}else if (chooseBox == 7){
					viewPuzzle = puzzle7;
				}else if (chooseBox == 8){
					viewPuzzle = puzzle8;
				}else if (chooseBox == 9){
					viewPuzzle = puzzle9;
				}else if (chooseBox == 10){
					viewPuzzle = puzzle10;
				}else if (chooseBox == 11){
					viewPuzzle = puzzle11;
				}else if (chooseBox == 12){
					viewPuzzle = puzzle12;
				}else if (chooseBox == 13){
					viewPuzzle = puzzle13;
				}else if (chooseBox == 14){
					viewPuzzle = puzzle14;
				}else if (chooseBox == 15){
					viewPuzzle = puzzle15;
				}else if (chooseBox == 16){
					viewPuzzle = puzzle16;
				}else {
					viewPuzzle = puzzle1;
				}
				for (int y = 0; y < 5; y++) {
					for (int x = 0; x < 5; x++) {
						lvlMatrix[1 + x + 5*k][1 + y+ 5*j] = viewPuzzle[x][y];
					}	
				}
			}
		}	
		return lvlMatrix;
	}

}