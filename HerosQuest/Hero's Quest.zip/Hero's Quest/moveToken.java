import com.sun.prism.paint.Color;

import javafx.scene.shape.Circle;

public class moveToken { //used to have circles with X and Y positions that arent layouts. this needs to exist for the pathing function to work.

	private int posX, posY;
	private Circle token = new Circle();
	private boolean moveUnitFlag;
	
	
	public moveToken() { //consctructor
		setToken(new Circle(10));
		token.setOnMouseClicked(e->{
			moveUnitFlag = true;
			token.setFill(javafx.scene.paint.Color.DARKSALMON);
		});
	}
	
	
	public int getPosX() {
		return posX;
	}
	public void setPosX(int posX) {
		this.posX = posX;
	}
	public int getPosY() {
		return posY;
	}
	public void setPosY(int posY) {
		this.posY = posY;
	}

	public Circle getToken() {
		return token;
	}

	public void setToken(Circle token) {
		this.token = token;
	}
	
	public boolean getMoveFlag() {
		return moveUnitFlag;
	}
	public void setMoveFlag(boolean flag) {
		this.moveUnitFlag = flag;
	}
}