import numpy as np


def envelope_sample(sample_array):
    # Sample to 100 Hz
    n = 320
    length = sample_array.size // n
    sampled = np.zeros((length*2), dtype=np.int8)
    # print(sampled.size)
    magnitudes = np.abs(sample_array)
    max_amplitude = np.max(magnitudes)//127
    # print(max_amplitude)
    for i in range(length):
        peak = np.max(magnitudes[i*n:(i+1)*n]) / max_amplitude
        sampled[2*i] = peak
        sampled[2*i+1] = -peak
    # print("Looped")
    return sampled, (length*2)
