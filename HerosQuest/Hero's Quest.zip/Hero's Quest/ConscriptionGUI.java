import java.io.IOException;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;

import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class ConscriptionGUI extends Pane {

	UnitManager UnitManager = new UnitManager();
	private Pane pane = new Pane();
	private Button option1 = new Button("Option 1");
	private Button option2 = new Button("Option 2");
	private Button option3 = new Button("Option 3");
	private TabPane tabPane;
	private Tab Tab;
	private Label name1Label = new Label("");
	private Label name2Label = new Label("");
	private Label name3Label = new Label("");
	private Label[] statLabel = new Label[30];
	private Label[] loopLabel = new Label[30];
	private int k = 0;
	private boolean buttonFlag = false;
	private int conscriptions = 1;
	
	public ConscriptionGUI(int gameLevel) throws IOException { //constructs GUI, and sets up the display
		UnitManager.conscript(gameLevel);
		pane.getChildren().add(option1);
		pane.getChildren().add(option2);
		pane.getChildren().add(option3);
		pane.getChildren().add(name1Label);
		pane.getChildren().add(name2Label);
		pane.getChildren().add(name3Label);
		option1.setLayoutX(95);
		option1.setLayoutY(50);
		option2.setLayoutX(285);
		option2.setLayoutY(50);
		option3.setLayoutX(475);
		option3.setLayoutY(50);
		name1Label.setLayoutX(100);
		name1Label.setLayoutY(120);
		name2Label.setLayoutX(290);
		name2Label.setLayoutY(120);
		name3Label.setLayoutX(480);
		name3Label.setLayoutY(120);
		
		int k = 0;
		for (int i = 0; i < 3; i++) {
			for (int j = 3; j < 11; j++) {
				loopLabel[k] = new Label("");
				pane.getChildren().add(loopLabel[k]);
				loopLabel[k].setLayoutX(-90+190*(i+1));
				loopLabel[k].setLayoutY(100+30*j);
				k = k + 1;
			}
		}
		
		statLabel = new Label[30];
		k = 0;
		for (int i = 0; i < 3; i++) {
			statLabel[k] = new Label("HP");
			pane.getChildren().add(statLabel[k]);
			statLabel[k].setLayoutX(-160+190*(i+1));
			statLabel[k].setLayoutY(190);
			k = k+1;
			
			statLabel[k] = new Label("Attack");
			pane.getChildren().add(statLabel[k]);
			statLabel[k].setLayoutX(-160+190*(i+1));
			statLabel[k].setLayoutY(220);
			k = k+1;
			
			statLabel[k] = new Label("M. Attack");
			pane.getChildren().add(statLabel[k]);
			statLabel[k].setLayoutX(-160+190*(i+1));
			statLabel[k].setLayoutY(250);
			k = k+1;
			
			statLabel[k] = new Label("Dexterity");
			pane.getChildren().add(statLabel[k]);
			statLabel[k].setLayoutX(-160+190*(i+1));
			statLabel[k].setLayoutY(280);
			k = k+1;
			
			statLabel[k] = new Label("Speed");
			pane.getChildren().add(statLabel[k]);
			statLabel[k].setLayoutX(-160+190*(i+1));
			statLabel[k].setLayoutY(310);
			k = k+1;
			
			statLabel[k] = new Label("Defense");
			pane.getChildren().add(statLabel[k]);
			statLabel[k].setLayoutX(-160+190*(i+1));
			statLabel[k].setLayoutY(340);
			k = k+1;
			
			statLabel[k] = new Label("M. Defense");
			pane.getChildren().add(statLabel[k]);
			statLabel[k].setLayoutX(-160+190*(i+1));
			statLabel[k].setLayoutY(370);
			k = k+1;
			
			statLabel[k] = new Label("Movement");
			pane.getChildren().add(statLabel[k]);
			statLabel[k].setLayoutX(-160+190*(i+1));
			statLabel[k].setLayoutY(400);
			k = k+1;
		}
		
		setDisplay();
	}
	
	public void setDisplay() {
		name1Label.setText(UnitManager.options[0].getUnitJob());
		name2Label.setText(UnitManager.options[1].getUnitJob());
		name3Label.setText(UnitManager.options[2].getUnitJob());
		k = 0;
			for (int i = 0; i < 3; i++) {
				for (int j = 3; j < 11; j++) {
					loopLabel[k].setText(Integer.toString(UnitManager.options[i].getUnitStats(j)));
					k = k + 1;
				}
			}
	}
		
	public void conscript(int Level) throws IOException { //prepares buttons for player
		UnitManager.conscript(Level);
		Tab = new Tab();
		tabPane = new TabPane();
			option1.setOnAction(e -> {
				UnitManager.playerUnits[getConscriptions()] = UnitManager.options[0];
				buttonFlag = true;
				setConscriptions(getConscriptions() + 1);
			});
			option2.setOnAction(e -> {
				UnitManager.playerUnits[getConscriptions()] = UnitManager.options[1];
				buttonFlag = true;
				setConscriptions(getConscriptions() + 1);
			});
			option3.setOnAction(e -> {
				UnitManager.playerUnits[getConscriptions()] = UnitManager.options[2];
				buttonFlag = true;
				setConscriptions(getConscriptions() + 1);
			});
	}
	
	public void conscriptPhase(int Level) throws IOException { //Conscripts Random Units for the player
		for (int i = 1; i < 9; i++) {
			UnitManager.conscript(Level);
			UnitManager.playerUnits[i] = UnitManager.options[1];
		}
	}
		
	public Pane getPane() {
		Pane thisPane = pane;
		return thisPane;
	}

	public boolean getButtonFlag() {
		return buttonFlag;
	}

	public void setButtonFlag(boolean buttonFlag) {
		this.buttonFlag = buttonFlag;
	}

	public UnitManager getUnitManager() {
		return UnitManager;
	}

	public int getConscriptions() {
		return conscriptions;
	}

	public void setConscriptions(int conscriptions) {
		this.conscriptions = conscriptions;
	}
	
}