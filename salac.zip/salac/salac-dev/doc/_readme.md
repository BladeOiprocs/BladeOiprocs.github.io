# Files in this `doc` folder

`salai-salac-basic-ideas-xxx.pdf`. Baasic descrition of the SaLAC project.
`SilentIntervalSRT.py`. Script to add `[Silence]` intervals in the SRT file.
`SrtToTextgridT.py`. Script to convert `[Silence]`-added SRT file to TextGrid file.
`FOIA_LC2_12Z-14Z_7-24-23-short.mp3`. A 16 kHz audio file with lots of silences. 
