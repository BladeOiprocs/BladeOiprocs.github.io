## Import from Python standard library
import re
from json import loads as json_load
from json import dumps as json_dump
from dataclasses import dataclass
from datetime import datetime, timezone

## Import from third-party library
import tomlkit

# Import from project modules
from salac.ldc_atc0 import process_ldc_atc0_transcripts


############################################################################
# The Cue class defines basic data structure of each cue in an annotation.
# A cue contains the labels of a segment (or interval) of speech.
@dataclass
class Cue:
    bgn_time: int
    end_time: int
    labels: list

    @property
    def length(self):
        return self.end_time - self.bgn_time

    def __str__(self):
        return "beg: " + str(self.bgn_time) + "\nend: " + \
            str(self.end_time) + "\ntxt: " + str(self.labels[0]) + \
            "\ndata: " + str(self.labels[1:])

    def offset_time(self, time_offset_in_ms: int):
        self.bgn_time += time_offset_in_ms
        self.end_time += time_offset_in_ms

    def expand_labels(self, mll_default: list = None):
        if mll_default is not None:
            # update default values of labels[1] to contain copies of labels[0]
            for key in mll_default[0].keys():
                mll_default[0][key] = self.labels[0]

            # put default values in labels list
            counter = 1
            for section in mll_default:
                section = section.copy()  # those annoying object handles >:/
                if len(self.labels) <= counter:
                    self.labels.append(section)
                else:
                    if (isinstance(self.labels[counter], dict)
                            and isinstance(section, dict)):
                        # neat trick to update labels without overwriting
                        section.update(self.labels[counter])
                        self.labels[counter] = section
                counter += 1


############################################################################
# The Annotation class defines the collection of cues of a single file.
# An annotation is a list of cues of an entire audio file.
class Annotation:
    cues: list[Cue] = []
    has_silence: bool = None
    default_ref_file = "labels.toml"

    def __init__(self, cues: list[Cue] = None, has_silence: bool = None):
        if cues is not None:
            self.cues = cues
            self.has_silence = has_silence

    # List of cues is sorted and the max time is at the end of cues
    @property
    def max_time(self):
        return self.cues[-1].end_time

    ########################################################################
    # Normal class methods

    # -----------------------------------------------------------------------
    # Add and remove silence

    def add_silence(self, silence: str = "[Silence]",
                    average_overlap: bool = False):
        # Check if silence is needed in the beginning
        if self.cues[0].bgn_time != 0:
            self.cues.insert(0, Cue(bgn_time=0,
                                    end_time=self.cues[0].bgn_time,
                                    labels=[silence, {}]))

        i = 1  # Index to insert a silence cue if needed
        # Check between each cue to see if end time and start time match up
        while i < len(self.cues):
            prev_end_time = self.cues[i - 1].end_time
            next_bgn_time = self.cues[i].bgn_time
            if prev_end_time < next_bgn_time:
                # If they don't match, add silence cue
                self.cues.insert(i, Cue(bgn_time=prev_end_time,
                                        end_time=next_bgn_time,
                                        labels=[silence, {}]))
                i += 1
            elif prev_end_time > next_bgn_time:
                if average_overlap:
                    avg_time = int((prev_end_time + next_bgn_time)/2)
                    self.cues[i - 1].end_time = avg_time
                    self.cues[i].bgn_time = avg_time
                else:
                    print("Error: overlapping times between: ")
                    print("Interval A:")
                    print(self.cues[i - 1])
                    print("Interval B:")
                    print(self.cues[i])
                    print("Address these issues manually in the original file")
            i += 1
        self.has_silence = True

    # this function needs fixing to work with multi-tier text
    # currently it just guesses based on the first tier - works for now
    def remove_silence(self):
        # Ref: https://stackoverflow.com/questions/1157106/remove-all-occurrences-of-a-value-from-a-list
        self.cues = [cue for cue in self.cues if cue.labels[0] != "[Silence]"]
        self.cues = [cue for cue in self.cues if cue.labels[0] != ""]
        self.has_silence = False

    # -----------------------------------------------------------------------
    # Address time issues

    def offset_time(self, time_offset_in_ms: int):
        for cue in self.cues:
            cue.offset_time(time_offset_in_ms)

    # this is if you want to adjust an interval for bordering cues
    def move_time_point(self, from_time: int, to_time: int):
        for cue in self.cues:
            if cue.bgn_time == from_time:
                cue.bgn_time = to_time
            if cue.end_time == from_time:
                cue.end_time = to_time

    # -----------------------------------------------------------------------
    # Address annotations

    def expand_labels(self, mll_format: dict = None):
        if mll_format is None:
            mll_format = self._mll_format()
        mll_default = Annotation._mll_default(mll_format)
        for cue in self.cues:
            cue.expand_labels(mll_default)

    def add_annotation(self, second_annotation, time_offset: int):
        if second_annotation is not None:
            second_annotation.offset_time(time_offset)
            self.cues.extend(second_annotation.cues)

    # -----------------------------------------------------------------------
    # handling cues in bulk

    def get_cues(self, begin_time: int = 0, end_time: int = max_time):
        if begin_time <= 0 and end_time >= self.max_time:
            result = self.cues.copy()
        else:
            result = []
            for cue in self.cues:
                if cue.bgn_time >= begin_time and cue.end_time <= end_time:
                    result.append(cue)
        return result

    #######################################################
    # Helper functions

    # -----------------------------------------------------------------------
    # Read and write text files

    @staticmethod
    def read_file_to_text(filename: str):
        with (open(filename, 'r') as file):
            file_text = file.read()
            file_text += " "  # textGrid parsing needs an extra whitespace
            file.close()
        return file_text

    @staticmethod
    def write_text_to_file(filename: str, file_text: str):
        with open(filename, 'w') as file:
            file.write(file_text)

    # -----------------------------------------------------------------------
    # Convert time formats

    # Convert ts (time string) to ms (milliseconds):
    #     from 00:05.160 to 5160 (robust)
    # Works for both VTT and SRT formats
    @staticmethod
    def _ts_to_ms(ts: str):
        ts = ts.replace(",", ".")
        hour_min_sec, milliseconds = ts.split(".")
        if len(hour_min_sec) == 5:
            hour_min_sec = f'00:{hour_min_sec}'
        time = datetime.strptime(hour_min_sec, "%H:%M:%S")
        time_in_sec = time.hour * 3600 + time.minute * 60 + time.second
        time_in_ms = time_in_sec * 1000 + int(f'{milliseconds:0<3}')
        return time_in_ms

    # Convert milliseconds to time string: from 5160 to 00:05.160
    @staticmethod
    def _ms_to_ts(milliseconds: int, delimiter: str = ".", hour: bool = True):
        time = datetime.fromtimestamp(milliseconds / 1000, tz=timezone.utc)
        if hour:
            time_text = f'{time:%H:%M:%S}'
        else:
            time_text = f'{time:%M:%S}'
        ms_only = milliseconds % 1000
        time_text += f'{delimiter}{ms_only:03}'
        return time_text

    ########################################################################
    # File IO for JSON

    @classmethod
    def from_json_text(cls, file_text: str):
        if file_text:
            json_obj = json_load(file_text)
            cues = []
            for cue in json_obj["cues"]:
                cues.append(Cue(bgn_time=cue.get("bgn_time", 0),
                                end_time=cue.get("end_time", 0),
                                labels=cue.get("labels", None)))
            return Annotation(cues=cues, has_silence=json_obj["has_silence"])
        else:
            return Annotation(cues=[], has_silence=False)

    # quick and easy way to export complex object to json
    def to_json_text(self):
        json_text = json_dump(self, default=lambda o: o.__dict__, indent=4)
        return json_text

    ########################################################################
    # File IO for LDC ATC0 transcripts

    @classmethod
    def from_ldc_atc0_text(cls, file_text: str,
                           filename: str = "",      # Used in the speaker field
                           need_proc: bool = False, # Need to process transcript?
                           compiled_mapping = None):
        MAX_SEGMENT_TIME = 30000                    # 30 seconds
        text_list = file_text.split("\n")
        cues = []
        end_of_text_list = False
        while True:
            # Find the SPEAKER first
            while ";;" in text_list[0] or "((FROM " not in text_list[0]:
                text_list.pop(0)
                if len(text_list) == 0:
                    end_of_text_list = True
                    break
            if end_of_text_list:
                break

            # Get the speaker info from the "((FROM ..." line
            # There code below can handle all the following situations
            # "((FROM SPEAKRE)"
            # "((FROM ** SPEAKRE)"
            # "((FROM **  SPEAKRE)  (Other contents)"
            speaker_line = text_list.pop(0).strip()
            speaker_line = re.sub(r' {2,}', ' ', speaker_line)
            speaker_list = speaker_line.split(')')
            speaker = speaker_list[0].split()[-1]
            speaker = '_'.join([filename.strip(), speaker.strip()], ).lower()

            # Remove the receipent line like `(TO COA360)`
            text_list.pop(0)

            # Address the issue that some transcripts have multiple lines
            cue_text_list = [text_list.pop(0).strip()]
            # Process the transcript before finding the timeline
            while "(TIMES " not in text_list[0]:
                cue_text_list.append(text_list.pop(0).strip())

            # Put the multiple lines of transcripts together
            txt = ' '.join(cue_text_list)
            text = txt.removeprefix("(TEXT ").removesuffix(")").lower().strip()

            if need_proc:  # If need formal processing of each transcript line
                p_text = process_ldc_atc0_transcripts(text, compiled_mapping)
                if p_text != text:
                    print("Changes made in processing:")
                    print(f"  Before change: {text}")
                    print(f"   After change: {p_text}")
                    text = p_text

            # A placeholder for transmissions of just "mike clicks" comments.
            if text == "":
                text = '<unk>'

            # Process the time line, which are not consistent across files.
            times = text_list.pop(0).strip()
            times = times.removeprefix('(TIMES ').removesuffix(')')\
                    .removesuffix(')').strip()
            times = re.sub(r'\t', ' ', times)
            times = re.sub(r' {2,}', ' ', times)

            bgn_time, end_time = times.split(" ")
            bgn_time = int(float(bgn_time) * 1000)
            end_time = int(float(end_time) * 1000)

            # Address the "complete interval overlap" problem like the one
            # at 4369.20 second in dca_lc_1.txt.
            if cues != []:
                if bgn_time == cues[-1].bgn_time:
                    cues = cues[:-1]
                    continue

            # Just want to ensure each utterance is no longer than 30 seconds.
            segment_time = end_time - bgn_time
            if segment_time >= MAX_SEGMENT_TIME:
                print(f"This segment has a length of {segment_time} ms.-----")
                print(f"{text = }")
                continue

            # Create the labels of the cue
            labels = [text, {}, {}]
            labels[2] = {"from": speaker}  # This following our prescription
            # Create the cue and add to the list
            cue = Cue(bgn_time=bgn_time, end_time=end_time, labels=labels)
            cues.append(cue)

        annotation = Annotation(cues=cues, has_silence=False)
        annotation.filename = filename
        return annotation

    ########################################################################
    # File IO for MLL

    @classmethod
    def from_mll_text(cls, file_text: str, mll_format: dict = None):
        if mll_format is None:
            # get default format iff not specified
            mll_format = cls._mll_format()
        sub_text_number = len(list(mll_format.values())[0])
        other_layer_number = len(mll_format) - 1

        text_list = file_text.split("\n")
        # neat trick to remove empty lines
        # ref : https://stackoverflow.com/questions/3711856/how-to-remove-empty-lines-with-or-without-whitespace
        text_list = [line for line in text_list if line.strip()]
        # similarly, remove comments
        text_list = [line for line in text_list if line[0] != "#"]
        cues = []
        while len(text_list) > 0:
            # if we see time, we know this is a cue
            if " --> " in text_list[0]:
                # grab time
                times = text_list.pop(0)
                bgn_time, end_time = times.split(" --> ")
                bgn_time = Annotation._ts_to_ms(bgn_time)
                end_time = Annotation._ts_to_ms(end_time)

                # grab primary text
                text = text_list.pop(0)
                text = text.split(" = ", 1)[1]
                text = text.strip('\"')
                labels = [text, {}]

                # grab sub-text layers
                for count in range(sub_text_number):
                    text = text_list.pop(0)
                    key, text = text.split(" = ", 1)
                    text = text.strip('\"')
                    labels[1].update({key: text})

                # grab all other-layers
                for count in range(other_layer_number):
                    text = text_list.pop(0)
                    text = text.split(" = ", 1)[1]
                    data_obj = json_load(text)
                    labels.append(data_obj)

                cue = Cue(bgn_time=bgn_time,
                          end_time=end_time,
                          labels=labels)
                cues.append(cue)
            else:
                # if we're not reading a cue, go to next line
                text_list = text_list[1:]

        return Annotation(cues=cues, has_silence=False)

    def to_mll_text(self, mll_format: dict = None):
        if mll_format is None:
            # get default format iff not specified
            mll_format = self._mll_format()

        # expand_labels() fills in all the default values
        # this makes things easier, so we don't have to check for it
        self.expand_labels(mll_format)

        # create some variables
        items_to_print = list(mll_format.keys())
        items_to_print = items_to_print[1:]
        use_hour = self.max_time > 3600000  # include hour if more than 1 hour
        file_text = 'Multi-layer label text file\n\n'

        for cue in self.cues:
            file_text += Annotation._ms_to_ts(cue.bgn_time,
                                              delimiter=".",
                                              hour=use_hour)
            file_text += ' --> '
            file_text += Annotation._ms_to_ts(cue.end_time,
                                              delimiter=".",
                                              hour=use_hour)
            file_text += '\n'
            file_text += 'asr = "' + cue.labels[0] + '"\n'

            # this could all break if labels.toml only has 1 value
            for key, value in cue.labels[1].items():
                file_text += key + ' = "' + value + '"\n'

            counter = 2
            for key in items_to_print:
                # using json format for dictionaries to make parsing easier
                json_text = json_dump(cue.labels[counter],
                                      default=lambda o: o.__dict__)
                file_text += key + ' = ' + json_text + '\n'
                counter += 1
            file_text += '\n'

        return file_text

    # -----------------------------------------------------------------------
    # Helper functions for MLL

    @classmethod
    def _mll_format(cls, ref_file: str = None):
        if ref_file is None:
            # get default file iff not specified
            ref_file = cls.default_ref_file
        ref_text = Annotation.read_file_to_text(ref_file)
        return tomlkit.parse(ref_text)

    # transforms mll_format data structure into default value for mll data
    @classmethod
    def _mll_default(cls, mll_format: dict = None):
        if mll_format is None:
            mll_format = cls._mll_format()  # get default if nothing specified
        mll_default = list(mll_format.values())

        # fill in default values on template
        for section in mll_default:
            if isinstance(section, dict):  # extra error checking
                for key, value in section.items():
                    if value == "str":
                        section[key] = ""
                    if value == "int":
                        section[key] = 0
                    if value == "float":
                        section[key] = 0.0
                    if isinstance(value, list) and len(value) > 0:
                        section[key] = value[0]
                    if value == "list of str":
                        section[key] = []
        return mll_default

    ########################################################################
    # File IO for STM

    def to_stm_text(self):
        if self.has_silence:
            print("Note: there will be silences in the STM file!")
            # Note that this is desired for some cases.
        file_text = ''
        for cue in self.cues:
            file_text += self.filename  # Assigned at end of from_ldc_atc0_text
            file_text += ' 1 '
            file_text += cue.labels[2]["from"]
            file_text += f' {cue.bgn_time / 1000:.3f}'
            file_text += f' {cue.end_time / 1000:.3f} '
            file_text += cue.labels[0] + '\n'
        return file_text

    ########################################################################
    # File IO for TextGrid

    @classmethod
    def from_textgrid_text(cls, file_text: str):
        # https://www.fon.hum.uva.nl/praat/manual/TextGrid_file_formats.html

        # regular expression to match all the fields related to cues.
        match_patten = '[ \t\n\r\f\v]("[^"]*"|[0-9.]+)[ \t\n\r\f\v]'
        fields = re.findall(match_patten, file_text)

        # file info
        fields = fields[2:]  # ignore header
        fields = fields[2:]  # ignore file length
        num_layers = int(fields.pop(0))
        # print("how many intervals : " + str(num_layers))

        cues = []

        # for every tier/layer
        while num_layers > 0:
            # interval info
            layer_class = fields.pop(0)
            # print("layer class : " + layer_class)
            layer_name = fields.pop(0).strip('"')
            # print("layer name : " + layer_name)
            fields = fields[2:]  # ignore tier/layer length
            layer_length = int(fields.pop(0))

            # Read in groups of 3 for the length specified
            # Inefficient implementation; ok with normal-sized files.
            for interval_num in range(layer_length):
                bgn_time = int(float(fields.pop(0)) * 1000)
                end_time = int(float(fields.pop(0)) * 1000)
                text = fields.pop(0).strip('"')
                if len(cues) > interval_num:
                    cues[interval_num].labels[1].update({layer_name: text})
                else:
                    cue = Cue(bgn_time=bgn_time, end_time=end_time,
                              labels=[text, {}])
                    cues.append(cue)
            num_layers -= 1

        return Annotation(cues=cues, has_silence=True)

    def to_textgrid_text(self):
        if not self.has_silence:
            print("Error: cannot create TextGrid without silences!")
            return ""

        file_text = 'File type = \"ooTextFile\"\n'
        file_text += 'Object class = \"TextGrid\"\n'
        file_text += '\nxmin = 0\n'
        file_text += f'xmax = {self.max_time / 1000.0:.3f}\n'
        file_text += 'tiers? <exists>\n'

        # this trick doesn't work if the first element is silent
        dict_sample = ["text"]
        if len(self.cues[0].labels) > 1:  # error checking
            dict_sample.extend(self.cues[0].labels[1].keys())

        i = 1
        file_text += f'size = {len(dict_sample)}\n'
        file_text += 'item []:\n'
        for layer in dict_sample:
            file_text += f'    item [{i}]:\n'
            file_text += '        class = \"IntervalTier\"\n'
            file_text += f'        name = \"{layer}\"\n'
            file_text += '        xmin = 0\n'
            file_text += f'        xmax = {self.max_time / 1000:.3f}\n'
            file_text += f'        intervals: size = {len(self.cues)}\n'

            i += 1
            j = 1
            for cue in self.cues:
                file_text += f'        intervals [{j}]:\n'
                file_text += f'            xmin = {cue.bgn_time / 1000:.3f}\n'
                file_text += f'            xmax = {cue.end_time / 1000:.3f}\n'
                if i == 2:
                    cue_text = cue.labels[0]
                else:
                    cue_text = cue.labels[1][layer]
                file_text += f'            text = \"{cue_text}\"\n'
                j += 1
        return file_text

    ########################################################################
    # File IO for VTT/SRT/Txt

    @classmethod
    def from_vtt_srt_text(cls, file_text: str):
        text_list = file_text.split("\n")
        cues = []
        end_of_text_list = False
        while True:
            # Find the timeline first
            while " --> " not in text_list[0]:
                text_list.pop(0)
                if len(text_list) == 0:
                    end_of_text_list = True
                    break
            if end_of_text_list:
                break

            times = text_list.pop(0)
            text = text_list.pop(0)
            bgn_time, end_time = times.split(" --> ")
            bgn_time = Annotation._ts_to_ms(bgn_time)
            end_time = Annotation._ts_to_ms(end_time)
            text = text.strip("- ")
            cue = Cue(bgn_time=bgn_time, end_time=end_time, labels=[text, {}])
            cues.append(cue)

        return Annotation(cues=cues, has_silence=False)

    def to_vtt_text(self):
        if self.has_silence:
            print("Note: there will be silences in the VTT file!")
            # Note that this is desired for some cases.

        use_hour = self.max_time > 3600000  # include hour if more than 1 hour
        file_text = 'WEBVTT\n\n'
        for cue in self.cues:
            file_text += Annotation._ms_to_ts(cue.bgn_time,
                                              delimiter=".",
                                              hour=use_hour)
            file_text += ' --> '
            file_text += Annotation._ms_to_ts(cue.end_time,
                                              delimiter=".",
                                              hour=use_hour)
            file_text += '\n'
            file_text += cue.labels[0] + '\n\n'
        return file_text

    def to_srt_text(self):
        if self.has_silence:
            print("Note: there will be silences in the SRT file!")
            # Note that this is desired for some cases.

        file_text = ''
        i = 1
        for cue in self.cues:
            file_text += str(i) + '\n'
            file_text += Annotation._ms_to_ts(cue.bgn_time,
                                              delimiter=",",
                                              hour=True)
            file_text += ' --> '
            file_text += Annotation._ms_to_ts(cue.end_time,
                                              delimiter=",",
                                              hour=True)
            file_text += '\n'
            file_text += cue.labels[0] + '\n\n'

        return file_text

    def to_transcript_text(self):
        if self.has_silence:
            print("Note: there will be silences in the transcript text file!")
            # Note that this is desired for some cases.

        file_text = ''
        for cue in self.cues:
            file_text += cue.labels[0] + '\n'
        return file_text
