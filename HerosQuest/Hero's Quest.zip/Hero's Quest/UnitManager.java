import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class UnitManager {
	public Unit[] playerUnits = new Unit[9];
	public Unit[] enemyUnits = new Unit[25];
	private XSSFSheet sheet;
	private XSSFWorkbook workbook;
	public Unit[] options = new Unit[3];
	
	public int randomFrom (int low, int high) {
		int randNum = 0;

		// (int) is casting since Math.random() return a double and randNum is an int
		randNum = (int) (Math.random()*(high-low) + low);

		return randNum;
	}
	
	public void generateMC() throws IOException {
		File classData = new File("C:/Users/Evan/eclipse-workspace/Hero's Quest/Excel Sheets/ClassData.xlsx");
		FileInputStream fis = new FileInputStream(classData);
		workbook = new XSSFWorkbook(fis);
		sheet = workbook.getSheetAt(0);
		Row row;
		Cell cell;
		int classReference = 2;
		playerUnits[0] = new Unit();
		// Adding values to the Unit
		//Unit Job
		CellReference cellRef;
		cellRef = new CellReference("A" + classReference); 
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		playerUnits[0].setUnitJob(cell.getStringCellValue());
		
		// HP
		cellRef = new CellReference("C" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		playerUnits[0].setUnitStat(2,(int) cell.getNumericCellValue());
		playerUnits[0].setUnitStat(3,(int) cell.getNumericCellValue());
		cellRef = new CellReference("O" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		playerUnits[0].setUnitGrowth(3,(int) cell.getNumericCellValue());
		// Attack
		cellRef = new CellReference("D" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		playerUnits[0].setUnitStat(4,(int) cell.getNumericCellValue());
		cellRef = new CellReference("P" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		playerUnits[0].setUnitGrowth(4,(int) cell.getNumericCellValue());
		// Magic Attack
		cellRef = new CellReference("E" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		playerUnits[0].setUnitStat(5,(int) cell.getNumericCellValue());
		cellRef = new CellReference("Q" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		playerUnits[0].setUnitGrowth(5,(int) cell.getNumericCellValue());
		// Dexterity
		cellRef = new CellReference("F" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		playerUnits[0].setUnitStat(6,(int) cell.getNumericCellValue());
		cellRef = new CellReference("R" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		playerUnits[0].setUnitGrowth(6,(int) cell.getNumericCellValue());
		// Speed
		cellRef = new CellReference("G" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		playerUnits[0].setUnitStat(7,(int) cell.getNumericCellValue());
		cellRef = new CellReference("S" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		playerUnits[0].setUnitGrowth(7,(int) cell.getNumericCellValue());
		// Defense
		cellRef = new CellReference("H" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		playerUnits[0].setUnitStat(8,(int) cell.getNumericCellValue());
		cellRef = new CellReference("T" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		playerUnits[0].setUnitGrowth(8,(int) cell.getNumericCellValue());
		// Magic Defense
		cellRef = new CellReference("I" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		playerUnits[0].setUnitStat(9,(int) cell.getNumericCellValue());
		cellRef = new CellReference("U" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		playerUnits[0].setUnitGrowth(9,(int) cell.getNumericCellValue());
		// Movement
		cellRef = new CellReference("J" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		playerUnits[0].setUnitStat(10,(int) cell.getNumericCellValue());
		
		playerUnits[0].setAlive(true);
		playerUnits[0].setOwner("Player");
		
		cellRef = new CellReference("K" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		playerUnits[0].setUnitWeapon(cell.getStringCellValue());
		
		cellRef = new CellReference("M" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		playerUnits[0].setUnitType(cell.getStringCellValue());
		
		cellRef = new CellReference("V" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		playerUnits[0].setAttackRange((int) cell.getNumericCellValue());
	}
	

	
	public void conscript(int Level) throws IOException {
		File classData = new File("C:/Users/Evan/eclipse-workspace/Hero's Quest/Excel Sheets/ClassData.xlsx");
		FileInputStream fis = new FileInputStream(classData);
		workbook = new XSSFWorkbook(fis);
		sheet = workbook.getSheetAt(0);
		
		
		Row row;
		Cell cell;
		for (int j = 0; j < 3; j++) {
			int classReference = (int) randomFrom(2,16)*2;
			
			CellReference cellRef;
			cellRef = new CellReference("M" + classReference);
			row = sheet.getRow(cellRef.getRow());
			cell = row.getCell(cellRef.getCol());
			
			if (cell.getStringCellValue().equals("Flier")) {
				options[j] = new Flier();
			} else if (cell.getStringCellValue().equals("Mounted")) {
				options[j] = new Mounted();
			} else {
			options[j] = new Unit();
			}
			options[j].setUnitType(cell.getStringCellValue());
			// Determine Job
			int refLevel = 0;

			if (Level > 2) {
				classReference = classReference + 1;
				refLevel = Level - 2;
				options[j].setUnitStat(0,((Level)*5)-2);
			} else {
				refLevel = Level - 1;
				options[j].setUnitStat(0,1);
			}
			// Adding values to the Unit
			//Unit Job
			cellRef = new CellReference("A" + classReference); 
			row = sheet.getRow(cellRef.getRow());
			cell = row.getCell(cellRef.getCol());
			options[j].setUnitJob(cell.getStringCellValue());
			// HP
			cellRef = new CellReference("C" + classReference);
			row = sheet.getRow(cellRef.getRow());
			cell = row.getCell(cellRef.getCol());
			options[j].setUnitStat(2,(int) cell.getNumericCellValue());
			options[j].setUnitStat(3,(int) cell.getNumericCellValue());
			cellRef = new CellReference("O" + classReference);
			row = sheet.getRow(cellRef.getRow());
			cell = row.getCell(cellRef.getCol());
			options[j].setUnitGrowth(3,(int) cell.getNumericCellValue());
			// Attack
			cellRef = new CellReference("D" + classReference);
			row = sheet.getRow(cellRef.getRow());
			cell = row.getCell(cellRef.getCol());
			options[j].setUnitStat(4,(int) cell.getNumericCellValue());
			cellRef = new CellReference("P" + classReference);
			row = sheet.getRow(cellRef.getRow());
			cell = row.getCell(cellRef.getCol());
			options[j].setUnitGrowth(4,(int) cell.getNumericCellValue());
			// Magic Attack
			cellRef = new CellReference("E" + classReference);
			row = sheet.getRow(cellRef.getRow());
			cell = row.getCell(cellRef.getCol());
			options[j].setUnitStat(5,(int) cell.getNumericCellValue());
			cellRef = new CellReference("Q" + classReference);
			row = sheet.getRow(cellRef.getRow());
			cell = row.getCell(cellRef.getCol());
			options[j].setUnitGrowth(5,(int) cell.getNumericCellValue());
			// Dexterity
			cellRef = new CellReference("F" + classReference);
			row = sheet.getRow(cellRef.getRow());
			cell = row.getCell(cellRef.getCol());
			options[j].setUnitStat(6,(int) cell.getNumericCellValue());
			cellRef = new CellReference("R" + classReference);
			row = sheet.getRow(cellRef.getRow());
			cell = row.getCell(cellRef.getCol());
			options[j].setUnitGrowth(6,(int) cell.getNumericCellValue());
			// Speed
			cellRef = new CellReference("G" + classReference);
			row = sheet.getRow(cellRef.getRow());
			cell = row.getCell(cellRef.getCol());
			options[j].setUnitStat(7,(int) cell.getNumericCellValue());
			cellRef = new CellReference("S" + classReference);
			row = sheet.getRow(cellRef.getRow());
			cell = row.getCell(cellRef.getCol());
			options[j].setUnitGrowth(7,(int) cell.getNumericCellValue());
			// Defense
			cellRef = new CellReference("H" + classReference);
			row = sheet.getRow(cellRef.getRow());
			cell = row.getCell(cellRef.getCol());
			options[j].setUnitStat(8,(int) cell.getNumericCellValue());
			cellRef = new CellReference("T" + classReference);
			row = sheet.getRow(cellRef.getRow());
			cell = row.getCell(cellRef.getCol());
			options[j].setUnitGrowth(8,(int) cell.getNumericCellValue());
			// Magic Defense
			cellRef = new CellReference("I" + classReference);
			row = sheet.getRow(cellRef.getRow());
			cell = row.getCell(cellRef.getCol());
			options[j].setUnitStat(9,(int) cell.getNumericCellValue());
			cellRef = new CellReference("U" + classReference);
			row = sheet.getRow(cellRef.getRow());
			cell = row.getCell(cellRef.getCol());
			options[j].setUnitGrowth(9,(int) cell.getNumericCellValue());
			// Movement
			cellRef = new CellReference("J" + classReference);
			row = sheet.getRow(cellRef.getRow());
			cell = row.getCell(cellRef.getCol());
			options[j].setUnitStat(10,(int) cell.getNumericCellValue());
			
			options[j].setAlive(true);
			options[j].setOwner("Player");
	
			
			cellRef = new CellReference("K" + classReference);
			row = sheet.getRow(cellRef.getRow());
			cell = row.getCell(cellRef.getCol());
			options[j].setUnitWeapon(cell.getStringCellValue());
			
			cellRef = new CellReference("V" + classReference);
			row = sheet.getRow(cellRef.getRow());
			cell = row.getCell(cellRef.getCol());
			options[j].setAttackRange((int) cell.getNumericCellValue());
			
			for (int k = 1; k < (refLevel*7); k++ ) {
				levelUp(options[j]);
			}
		}
	}
	
	public void generateEnemies(int x, int Level, int Map) throws IOException {
		File classData = new File("C:/Users/Evan/eclipse-workspace/Hero's Quest/Excel Sheets/ClassData.xlsx");
		FileInputStream fis = new FileInputStream(classData);
		workbook = new XSSFWorkbook(fis);
		sheet = workbook.getSheetAt(0);
		Row row;
		Cell cell;
		
		for (int k = 0; k < x; k++) {
			int refLevel;
			int classReference = (int) randomFrom(2,14)*2;
			enemyUnits[k] = new Unit();
			if (Level > 2) {
				classReference = classReference + 1;
				refLevel = Level - 2;
				enemyUnits[k].setUnitStat(0,8);
			} else {
				refLevel = Level - 1;
				enemyUnits[k].setUnitStat(0,2);
			}
		// Adding values to the Unit
		//Unit Job
		CellReference cellRef;
		cellRef = new CellReference("A" + classReference); 
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		enemyUnits[k].setUnitJob(cell.getStringCellValue());
		// HP
		cellRef = new CellReference("C" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		enemyUnits[k].setUnitStat(2,(int) cell.getNumericCellValue());
		enemyUnits[k].setUnitStat(3,(int) cell.getNumericCellValue());
		cellRef = new CellReference("O" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		enemyUnits[k].setUnitGrowth(3,(int) cell.getNumericCellValue());
		// Attack
		cellRef = new CellReference("D" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		enemyUnits[k].setUnitStat(4,(int) cell.getNumericCellValue());
		cellRef = new CellReference("P" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		enemyUnits[k].setUnitGrowth(4,(int) cell.getNumericCellValue());
		// Magic Attack
		cellRef = new CellReference("E" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		enemyUnits[k].setUnitStat(5,(int) cell.getNumericCellValue());
		cellRef = new CellReference("Q" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		enemyUnits[k].setUnitGrowth(5,(int) cell.getNumericCellValue());
		// Dexterity
		cellRef = new CellReference("F" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		enemyUnits[k].setUnitStat(6,(int) cell.getNumericCellValue());
		cellRef = new CellReference("R" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		enemyUnits[k].setUnitGrowth(6,(int) cell.getNumericCellValue());
		// Speed
		cellRef = new CellReference("G" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		enemyUnits[k].setUnitStat(7,(int) cell.getNumericCellValue());
		cellRef = new CellReference("S" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		enemyUnits[k].setUnitGrowth(7,(int) cell.getNumericCellValue());
		// Defense
		cellRef = new CellReference("H" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		enemyUnits[k].setUnitStat(8,(int) cell.getNumericCellValue());
		cellRef = new CellReference("T" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		enemyUnits[k].setUnitGrowth(8,(int) cell.getNumericCellValue());
		// Magic Defense
		cellRef = new CellReference("I" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		enemyUnits[k].setUnitStat(9,(int) cell.getNumericCellValue());
		cellRef = new CellReference("U" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		enemyUnits[k].setUnitGrowth(9,(int) cell.getNumericCellValue());
		// Movement
		cellRef = new CellReference("J" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		enemyUnits[k].setUnitStat(10,(int) cell.getNumericCellValue());
		
		enemyUnits[k].setAlive(true);
		enemyUnits[k].setOwner("Enemy");
		
		cellRef = new CellReference("K" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		enemyUnits[k].setUnitWeapon(cell.getStringCellValue());
		
		cellRef = new CellReference("M" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		enemyUnits[k].setUnitType(cell.getStringCellValue());
		
		cellRef = new CellReference("V" + classReference);
		row = sheet.getRow(cellRef.getRow());
		cell = row.getCell(cellRef.getCol());
		enemyUnits[k].setAttackRange((int) cell.getNumericCellValue());
		
		for (int r = 0; r < (4*(Level-1)+Map); r++) {
			levelUp(enemyUnits[k]);
			}
		}
	}
	

	
	
	public void levelUp(Unit refUnit) {
		int chance;
		refUnit.setUnitStat(0, refUnit.getUnitStats(0)+1);
		for (int i = 3; i < 9; i++) {
			chance = randomFrom(0,101);
			if (chance < refUnit.getUnitGrowths(i)) {
				refUnit.setUnitStat(i,refUnit.getUnitStats(i)+1);
			}
		}
	}
}