try:
    import tomllib
except ModuleNotFoundError:
    import tomli as tomllib

## Use one of the following approaches to get the value of version

# from importlib import resources
## Need to run in folder containg __init__.py on Linux:
##   ln -s ../../pyproject.toml ln_pypropect.toml
# _pyproj = tomllib.loads(resources.read_text("salac",
#                                             "ln_pyproject.toml"))

import os
current_dir = os.path.dirname(__file__)
file_path = os.path.join(current_dir, '..', '..', 'pyproject.toml')
file_path = os.path.abspath(file_path)
with open(file_path, 'r') as file:
    content = file.read()
_pyproj = tomllib.loads(content)

__version__ = _pyproj["tool"]["poetry"]["version"]
