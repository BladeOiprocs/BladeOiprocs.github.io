//data representation of player
public class Enemy extends Characters {
	
	boolean alive;
	private int range = 10;
  //constructor
  public Enemy() {
	  setX(100);
	  setY(100);
	  setHealth(10);
	  alive = false;
  }
  
  public void setAlive(boolean p) {
	  alive = p;
  }
  
  public boolean getAlive() {
	  return alive;
  }

  //this uses the manhattan distance formula (diagonals count as 2) so we can change it if needed
  int getDistance(Player player) { 
	  return Math.abs(getX() - player.getX()) + Math.abs(getY() - player.getY());
  }
  enum states {STATE0, STATE1, STATE2, STATE3, STATE4, STATE5};
  states currentState = states.STATE0;
  /* States:
   * State0 - Neutral State (enemy does nothing)
   * State1 - Enemy is ready to move
   * State2 - Enemy is ready to fire
   * State3 - Enemy fires a beam at the player
   * State4 - Enemy moves one column closer to the player
   * State5 - Enemy moves one row closer to the player
   */
  //state transitions and all that jazz, this should be run once every keyframe from all enemy objects
  // (may need to be slowed down)
  public void enemyAILoop(Player player1, Player player2, char[][] matrix) {
	  	Player target = player1;
	  	//projectile attack;
		switch (currentState) {
			case STATE0: //neutral state
				//new distance checking- first determines which is closest
				if (getDistance(player1) < getDistance(player2)) {
					target = player1;
				} else {
					target = player2;
				}
				//now checks for range
				if (getDistance(target) <= range) {
					//transition to state 1
					currentState = states.STATE1;
				} else {
					currentState = states.STATE0;
				}
				break;
			case STATE1: //ready to move
				//new transition code
				//compares absolute value of distance to target horizontally and vertically, selects closest
				if (Math.abs(getX()-target.getX()) < Math.abs(getY()-target.getY())) {
					if (target.getX() <= range) {
						//transition to state 4
						currentState = states.STATE4;
					} else {
						currentState = states.STATE0;
					}
				} else {
					if (target.getY() <= range) {
						//transition to state 5
						currentState = states.STATE5;
					} else {
						currentState = states.STATE0;
					}
				}
				break;
			case STATE2: //ready to fire
				if (((target.getX() == getX()) || (target.getY() == getY()))) { //check if same column or row
					//transition to state 3
					currentState = states.STATE3;
				} else {
					currentState = states.STATE1;
				}
				break;
			case STATE3: //fire beam
				//actually fire the beam
				target.setHealth(getHealth()-1);
				//check if target is still in same column or row
				currentState = states.STATE1;
				break;
			case STATE4: //move one column closer
				//check which direction to move
				//origin should be at top left corner, so - movement is left and + is right
				if (getX() - target.getX() < 0) {
					if(matrix[getX()+1][getY()] == 'P') {
						setX(getX() + 1);
					}
				} else {
					if(matrix[getX()-1][getY()] == 'P') {
					setX(getX() - 1);
					}
				}
					currentState = states.STATE2;

				break;
			case STATE5: //move one row closer
				//check which direction to move
				//origin should be at top left corner, so - movement is up and + is down
				if (getY()-target.getY() < 0) {
					if(matrix[getX()][getY()+1] == 'P') {
						setY(getY() + 1);
					}
				} else {
					if(matrix[getX()][getY()-1] == 'P') {
						setY(getY() - 1);
					}
				}

					currentState = states.STATE2;

				break;
		}
  }
}



  


