import pytest

from salac.ldc_atc0 import (preprocess_ldc_atc0_text,
                            postprocess_ldc_atc0_text,
                            link_acronyms,
                            creat_mapping_table,
                            map_transcripts,
                            )

# Test function in the order they are called in process_ldc_atc0_transcripts(),
# which is not tested as it is just a sequential running of the component
# functions.


text_to_preprocess = \
"this   is unknown(unintelligible)followed by a (laughter) i (quote ve) heard"
expected_preproc_text = \
"this is unknown <unk> followed by a  <laughter>  i 've heard"

def test_preprocess_ldc_atc0_text():
    processed_text = preprocess_ldc_atc0_text(text=text_to_preprocess)
    assert processed_text == expected_preproc_text


raw_acronyms = \
"u s s i l s l v f r a b c d u s i b m "
expected_acronyms = "u_s s i_l_s l v_f_r a_b_c_d u_s i_b_m"

def test_link_acronyms():
    processed_acronyms = link_acronyms(text=raw_acronyms)
    assert processed_acronyms == expected_acronyms


raw_transcript = \
"a: call sign b: gruezi c: aero mexico d: a_a_r airlines"
expected_transcript = \
"a: callsign b: gruezi_(greet) c: aeromexico d: a_a_r_airlines"

def test_map_transcripts():
    compiled_mapping = creat_mapping_table()
    mapped_acronyms = map_transcripts(raw_transcript, compiled_mapping)
    assert mapped_acronyms == expected_transcript


text_to_postprocess = \
"8'll be three kil0 from here / 0h how about y0u // 123a /// what  "
expected_postproc_text = \
"i'll be three kilo from here / oh how about you <unk> what"

def test_postprocess_ldc_atc0_text():
    processed_text = postprocess_ldc_atc0_text(text=text_to_postprocess)
    assert processed_text == expected_postproc_text

